<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<!--
 HTML Presentation Solution
 The simple, open source way to make publicly accessible presentations.
 by The Analysis and Solutions Company
 http://www.analysisandsolutions.com/software/presentation/
-->

<head>

 <title>
  Portability: Error Mapping </title>

 <meta name="description" content="" />
 <meta name="keywords" content="" />
 
 <style type="text/css">

 /* ====================================================
  * FOOTER PLACEMENT
  *   + bottom of screen on short pages
  *   + bottom of text on long pages
  * MASSIVE thanks to
  *   http://scott.sauyet.name/CSS/Demo/FooterDemo1.html
  */

 html, body, div.contents {
	min-height: 100%;
	width: 100%;
	height: 100%;
	margin: 0;   /* margin keeps Mozilla 1* from adding scrollbars */
 }

 /*
  * The "height" above is a hack for IE5+/Win.  Below we adjust
  * it using the child selector to hide from IE5+/Win
  */

 html>body, html>body div.contents {
	height: auto;
 }

 div.contents {
	position: absolute;
	top: 0;
	left: 0;
 }

 div.header {
	position: absolute;
	width: 100%;
 }

 div.main {
	margin-top: 1em;
	margin-bottom: 2em;
	height: auto;
    padding-left: 0.5em;
    padding-right: 0.5em;
 }

 div.footer {
    position: absolute;
    bottom: 0;
    width: 100%;
 }


/* ====================================================
 * TEXT FORMATTING
 */

 body {
    font-family: arial, sans-serif;
    color: #000000;
    background-color: #FFFFFF;
 }

 h1 {font-size: 25pt}
 p, li, dd {font-size: 1em}
 dt {font-size: 2em; font-weight: bold; margin-top: 0.5em}
 p.main {font-size: 1.8em}
 li.main {font-size: 1.8em; margin-top: 0.8em}
 pre {font-family: "courier new", courier, monospace}

 a:link    {color: #0000FF; background-color: #FFFFFF}
 a:visited {color: #9999FF; background-color: #FFFFFF}
 a:hover   {color: #00FF00; background-color: #FFFFFF}

 a.header:link, a.header:visited {color: #999999; background-color: #FFFFFF}
 a.header:hover                  {color: #000000; background-color: #FFFFFF}

 td.prev, td.toc, td.next {
    font-size: 8pt;
    color: #999999;
    background-color: #FFFFFF;
    white-space: nowrap;
 }

 td.footer {
    font-size: 7pt;
    color: #999999;
    background-color: #FFFFFF;
    white-space: nowrap;
 }

 .red, a:link.red, a:visited.red          {color: #FF0000; background-color: #FFFFFF}
 .orange, a:link.orange, a:visited.orange {color: #FF9900; background-color: #FFFFFF}
 .green, a:link.green, a:visited.green    {color: #009966; background-color: #FFFFFF}
 .blue, a:link.blue, a:visited.blue       {color: #0099FF; background-color: #FFFFFF}
 .violet, a:link.violet, a:visited.violet {color: #CC00FF; background-color: #FFFFFF}
 .pink, a:link.pink, a:visited.pink       {color: #FF99CC; background-color: #FFFFFF}
 .maroon, a:link.maroon, a:visited.maroon {color: #CC3399; background-color: #FFFFFF}
 .black, a:link.black, a:visited.black    {color: #000000; background-color: #FFFFFF}
 
 a:hover.red, a:hover.green, a:hover.orange,
 a:hover.blue, a:hover.violet, a:hover.pink,
 a:hover.maroon, a:hover.black            {color: #00FF00; background-color: #FFFFFF}

 table.results {margin-bottom: 1em}
 th.results {font-family: "courier new", courier, monospace; white-space: pre}
 td.results {white-space: pre}
 td.resultsgood {white-space: pre; background-color: #CCFF99}
 td.resultsbad {white-space: pre; background-color: #FFCCFF}
 td.resultsbadnopre {background-color: #FFCCFF}


/* ====================================================
 * PAGE SPECIFIC FORMATTING, IF ANY
 */


 samp {font-size: 80%}
 </style>

</head>
<body text="#000000" bgcolor="#FFFFFF" link="#0000FF" alink="#FF0000" vlink="#990099">

<div class="contents">

 <div class="header">
  <table border="0" width="100%" class="header" align="center">
   <tr class="header">
    <td class="prev" width="40%" align="left">

    &lt; <a href="null.php" class="header" accesskey="r">Portability: Null to Empty</a> &nbsp; (P<u>r</u>evious)
    </td>
    <td class="toc" width="20%" align="center">
     <a href="toc.php" class="header">Table of Contents</a>
    </td>
    <td class="next" width="40%" align="right">

    (Ne<u>x</u>t) &nbsp; <a href="errorportex.php" class="header" accesskey="x" tabindex="1">Portability: Error Mapping Example</a> &gt;
    </td>
   </tr>
  </table>
 </div>  <!-- this closes header -->
 <div class="main">
  <h1 align="center">Portability: Error Mapping</h1>

<ul>

<li class="main">
MySQL unique/primary key violations:<br />
<samp>already exists</samp> -&gt; <samp>constraint violation</samp>
</li>

<li class="main">
<p>MySQL not-null violations:<br />
<samp>constraint violation</samp> -&gt;
<samp>null value violates not-null constraint</samp>
</li>

<li class="main">
MS Access ODBC bogus field:<br />
<samp>mismatch</samp> -&gt; <samp>no such field</samp>
</li>

<li class="main">In 1.6.0 this must be set during connect().</li>

<li class="main">1.6.1 will allow configuration via setOption().</li>

</ul>


 </div>  <!-- this closes main -->

 <div class="footer">
  <table border="0" width="100%" class="footer">
   <tr class="footer">
    <td class="footer" align="left">
     <a href="http://www.nyphp.org/content/presentations/db160/"
      class="header">PEAR DB: What's New In 1.6.0</a>
    </td>
    <td class="footer" align="center">
     <a href="http://www.nyphp.org/"
      class="header">New York PHP</a>
     2004-02-24    </td>
    <td class="footer" align="right">
     &copy; <a href="http://www.analysisandsolutions.com/"
      class="header">The Analysis and Solutions Company</a>
    </td>
   </tr>
  </table>
 </div>  <!-- this closes footer -->
</div>  <!-- this closes contents -->

</body>
</html>
