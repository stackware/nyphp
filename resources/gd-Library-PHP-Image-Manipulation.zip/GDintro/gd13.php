<?PHP
$slide_title = 'Using Existing Images';
session_start();
$_SESSION['png'] = 'tree3.png' ;
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>
	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>As you can see, creating images from scratch can be very tedious. It is often best to modify an existing image if you want anything but the simplest graphics. In addition to <?=phpfun('imageCreate()')?>&nbsp;there are many <?=phpfun('imageCreateFrom')?>... functions. The only thing differentiating most of them is the particular graphics file format they read. 
						<ol>
							
						</ol>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageCreateFromPNG"></a>int <?=phpfun('imageCreateFromPNG')?>&nbsp;( string filename )<br />
						<a name="imageCreateFromJPEG"></a> int <?=phpfun('imageCreateFromJPEG')?>&nbsp;( string filename )<br />
						<a name="imageCreateFromWBMP"></a> int <?=phpfun('imageCreateFromWBMP')?>&nbsp;( string filename )<br />
						<a name="imageCreateFromGIF"></a> int <?=phpfun('imageCreateFromGIF')?>&nbsp;( string filename )<br />
						<a name="imageCreateFromGD"></a>int <?=phpfun('imageCreateFromGD')?>&nbsp;( string filename )<br />
						<a name="imageCreateFromGD2"></a> int <?=phpfun('imageCreateFromGD2')?>&nbsp;( string filename )<br />
						<a name="imageCreateFromXBM"></a> int <?=phpfun('imageCreateFromXBM')?>&nbsp;( string filename )<br />
						<a name="imageCreateFromXPM"></a> 	int <?=phpfun('imageCreateFromXPM')?>&nbsp;( string filename )<br />
						<p>Returns an image identifier representing the image obtained from the given filename or URL.</p>
						<hr>
						<p><a name="imageCreateFromString"></a> int <?=phpfun('imageCreateFromString')?>&nbsp;( string image )</p>
						<p>Returns an image identifier representing the image obtained from the given string.</p>
						<hr>
						<p><a name="imageCreateFromGD2Part"></a>int <?=phpfun('imageCreateFromGD2Part')?>&nbsp;( string filename, int srcX, int srcY, int width, int height )</p>
						<p>Create a new image from a given part of GD2 file or URL.</p>
					</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td class="source"><? show_source('tree.php')?></td>
				</tr>
				<tr>
					<td align="center"><img onclick='this.src = "tree.php";' src="tree.php" alt="(c) FreeFoto.com " height="480" width="720" border="0"></td>
				</tr>
				<tr>
					<td align="center"><font size="-7">Image Supplied by FreeFoto.com </font></td>
				</tr>
			</table>
			<p><? navtable(''); ?></p>
		</div>
	</body>
</html>
