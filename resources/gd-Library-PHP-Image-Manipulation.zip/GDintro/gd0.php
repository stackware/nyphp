<?PHP
$slide_title = 'Index of Functions';
require ('presfun.php');
// require ('fundex.php');
require ('funfile.inc');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
	<div align='center'>
		<? navtable($slide_title); ?>
		<div align='left'>
		<dl align='left'>
		<?php
		foreach ($fundex as $key => $value) {
			if ($fundex[$key]['page']) {
			echo "<dt><a href='gd{$value['page']}.php#$key'>$key</a>: {$value['def']}<br />\n";
			} else {
			echo "<dt>$key: {$value['def']}<br />\n";
			}
		}
		?>
		</dl>
		</div>
		<? navtable(''); ?></div>
	</div>
	<pre>
</body>

</html>
