<?PHP
$slide_title = 'Copying, Resizing and Rotating functions';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--
		function iCopy(data) {
			document.iCsrc.src = data.src_im.value + data.src_fmt.value
			document.iCdst.src = data.dst_im.value + data.dst_fmt.value
			document.iCrst.src =  "iCopyFuns.php?fun=imageCopy"
									+ "&dst=" + data.dst_im.value + data.dst_fmt.value
									+ "&src=" + data.src_im.value + data.src_fmt.value
									+ "&dst_x=" + data.dst_x.value
									+ "&dst_y=" + data.dst_y.value
									+ "&src_x=" + data.src_x.value
									+ "&src_y=" + data.src_y.value
									+ "&src_w=" + data.src_w.value
									+ "&src_h=" + data.src_h.value ;
		}
		function iCMerge(data) {
			document.iCMsrc.src = data.src_im.value + data.src_fmt.value
			document.iCMdst.src = data.dst_im.value + data.dst_fmt.value
			document.iCMrst.src =  "iCopyFuns.php?fun=imageCopyMerge"
									+ "&dst=" + data.dst_im.value + data.dst_fmt.value
									+ "&src=" + data.src_im.value + data.src_fmt.value
									+ "&dst_x=" + data.dst_x.value
									+ "&dst_y=" + data.dst_y.value
									+ "&src_x=" + data.src_x.value
									+ "&src_y=" + data.src_y.value
									+ "&src_w=" + data.src_w.value
									+ "&src_h=" + data.src_h.value 
									+ "&pct=" + data.pct.value ;
		}
		
		function iCMGray(data) {
			document.iCMGsrc.src = data.src_im.value + data.src_fmt.value
			document.iCMGdst.src = data.dst_im.value + data.dst_fmt.value
			document.iCMGrst.src =  "iCopyFuns.php?fun=imageCopyMergeGray"
									+ "&dst=" + data.dst_im.value + data.dst_fmt.value
									+ "&src=" + data.src_im.value + data.src_fmt.value
									+ "&dst_x=" + data.dst_x.value
									+ "&dst_y=" + data.dst_y.value
									+ "&src_x=" + data.src_x.value
									+ "&src_y=" + data.src_y.value
									+ "&src_w=" + data.src_w.value
									+ "&src_h=" + data.src_h.value 
									+ "&pct=" + data.pct.value ;
		}
		
		function iCResized(data) {
			document.iCRZsrc.src = data.src_im.value + data.src_fmt.value
			document.iCRZdst.src = data.dst_im.value + data.dst_fmt.value
			document.iCRZrst.src =  "iCopyFuns.php?fun=imageCopyResized"
									+ "&dst=" + data.dst_im.value + data.dst_fmt.value
									+ "&src=" + data.src_im.value + data.src_fmt.value
									+ "&dst_x=" + data.dst_x.value
									+ "&dst_y=" + data.dst_y.value
									+ "&src_x=" + data.src_x.value
									+ "&src_y=" + data.src_y.value
									+ "&src_w=" + data.src_w.value
									+ "&src_h=" + data.src_h.value 
									+ "&dst_w=" + data.dst_w.value
									+ "&dst_h=" + data.dst_h.value ;
		}
		
		function iCResampled(data) {
			document.iCRDsrc.src = data.src_im.value + data.src_fmt.value
			document.iCRDdst.src = data.dst_im.value + data.dst_fmt.value
			document.iCRDrst.src =  "iCopyFuns.php?fun=imageCopyResampled"
									+ "&dst=" + data.dst_im.value + data.dst_fmt.value
									+ "&src=" + data.src_im.value + data.src_fmt.value
									+ "&dst_x=" + data.dst_x.value
									+ "&dst_y=" + data.dst_y.value
									+ "&src_x=" + data.src_x.value
									+ "&src_y=" + data.src_y.value
									+ "&src_w=" + data.src_w.value
									+ "&src_h=" + data.src_h.value 
									+ "&dst_w=" + data.dst_w.value
									+ "&dst_h=" + data.dst_h.value ;
		}
		
		function iCMatch(data) {
			document.iMsrc.src = data.src_im.value + data.src_fmt.value
			document.iMdst.src = data.dst_im.value + data.dst_fmt.value
			document.iMrst.src =  "iCopyFuns.php?fun=imageColorMatch"
									+ "&dst=" + data.dst_im.value + data.dst_fmt.value
									+ "&src=" + data.src_im.value + data.src_fmt.value ;
		}

		function iPCopy(data) {
			document.iPCsrc.src = data.src_im.value + data.src_fmt.value
			document.iPCdst.src = data.dst_im.value + data.dst_fmt.value
			document.iPCrst.src =  "iCopyFuns.php?fun=imagePaletteCopy"
									+ "&dst=" + data.dst_im.value + data.dst_fmt.value
									+ "&src=" + data.src_im.value + data.src_fmt.value ;
		}

		function iRotate(data) {
			document.iROTsrc.src = data.src_im.value + data.src_fmt.value
			document.iROTrst.src = "iCopyFuns.php?fun=imageRotate"
									+ "&src=" + data.src_im.value + data.src_fmt.value
									+ "&a=" + data.a.value
									+ "&c=" + data.c.value  ;
		}
		-->
		</script>
	</head>
<?php
function imageList() {
return "<option value='white'>white</option>
		<option value='blackbox'>black</option>
		<option value='bandw'>b&amp;w</option>
		<option value='apples'>apples</option>
		<option value='monkey'>monkey</option>
		<option value='robots'>robots</option>";
}
?>
	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td colspan="5">Transformations on an image like resizing and rotating are achieved indirectly by applying the transformation while copying a source image to a destination. </td>
				</tr>
				<tr>
					<td class="phpnet" colspan="5"><a name="imageCopy"></a>int <?=phpfun('imageCopy')?>&nbsp; ( resource dst_im, resource src_im, int dst_x, int dst_y, int src_x, int src_y, int src_w, int src_h)<br />
						Copies a part of <i>src_im</i> onto <i>dst_im</i> starting at the x, y coordinates <i>src_x</i>, <i>src_y</i> with a width of <i>src_w</i> and a height of <i>src_h</i>. The portion defined will be copied onto the x, y coordinates, <i>dst_x</i> and <i>dst_y</i>.</td>
				</tr>
				<tr>
					<td class="controller" colspan="5">
						<form method="post" name="copyForm">
							<?=phpfun('imageCopy')?>&nbsp;(<select name="dst_im" size="1">
								<?=imageList();?>
							</select><select name="dst_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <select name="src_im" size="1">
								<?=imageList();?>
							</select><select name="src_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <input type="text" name="dst_x" value="$dx" size="4" maxlength="3">, <input type="text" name="dst_y" value="$dy" size="4" maxlength="3">, <input type="text" name="src_x" value="$sx" size="4" maxlength="3">, <input type="text" name="src_y" value="$sy" size="4" maxlength="3">, <input type="text" name="src_w" value="$sw" size="4" maxlength="3">, <input type="text" name="src_h" value="$sh" size="4" maxlength="3">&nbsp;)&nbsp;;
							<p><input onclick="iCopy(this.form);" type="button" name="iCrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"><img src="blackbox.png" alt="" name="iCdst" height="100" width="100" border="0"></td>
					<td align="center">+</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCsrc" height="100" width="100" border="0"></td>
					<td align="center">=&gt;</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCrst" height="100" width="100" border="0"></td>
				</tr>
				<tr>
					<td class="phpnet" colspan="5"><a name="imageCopyMerge"></a>int <?=phpfun('imageCopyMerge')?>&nbsp; ( resource dst_im, resource src_im, int dst_x, int dst_y, int src_x, int src_y, int src_w, int src_h, int pct)<br />
						Copies a part of <i>src_im</i> onto <i>dst_im</i> starting at the x, y coordinates <i>src_x</i>, <i>src_y</i> with a width of <i>src_w</i> and a height of <i>src_h</i>. The portion defined will be copied onto the x, y coordinates, <i>dst_x</i> and <i>dst_y</i>. The two images will be merged according to <i>pct</i> which can range from 0 to 100. When <i>pct</i> = 0, no action is taken, when 100 this function behaves identically to <?=phpfun('imageCopy()')?>.</td>
				</tr>
				<tr>
					<td class="controller" colspan="5">
						<form method="post" name="copyMergeForm">
							<?=phpfun('imageCopyMerge')?>&nbsp;(<select name="dst_im" size="1">
								<?=imageList();?>
							</select><select name="dst_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <select name="src_im" size="1">
								<?=imageList();?>
							</select><select name="src_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <input type="text" name="dst_x" value="$dx" size="4" maxlength="3">, <input type="text" name="dst_y" value="$dy" size="4" maxlength="3">, <input type="text" name="src_x" value="$sx" size="4" maxlength="3">, <input type="text" name="src_y" value="$sy" size="4" maxlength="3">, <input type="text" name="src_w" value="$sw" size="4" maxlength="3">, <input type="text" name="src_h" value="$sh" size="4" maxlength="3">, <input type="text" name="pct" value="$pct" size="5" maxlength="4">&nbsp;)&nbsp;;
							<p><input onclick="iCMerge(this.form);" type="button" name="iCMrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"><img src="blackbox.png" alt="" name="iCMdst" height="100" width="100" border="0"></td>
					<td align="center">+</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCMsrc" height="100" width="100" border="0"></td>
					<td align="center">=&gt;</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCMrst" height="100" width="100" border="0"></td>
				</tr>
				<tr>
					<td class="phpnet" colspan="5"><a name="imageCopyMergeGray"></a>int <?=phpfun('imageCopyMergeGray')?>&nbsp; ( resource dst_im, resource src_im, int dst_x, int dst_y, int src_x, int src_y, int src_w, int src_h, int pct)<br />
						Copies a part of <i>src_im</i> onto <i>dst_im</i> starting at the x, y coordinates <i>src_x</i>, <i>src_y</i> with a width of <i>src_w</i> and a height of <i>src_h</i>. The portion defined will be copied onto the x, y coordinates, <i>dst_x</i> and <i>dst_y</i>. The two images will be merged according to <i>pct</i> which can range from 0 to 100. When <i>pct</i> = 0, no action is taken, when 100 this function behaves identically to <?=phpfun('imageCopy()')?>. This function is identical to <?=phpfun('imageCopyMerge()')?>&nbsp; except that when merging it preserves the hue of the source by converting the destination pixels to gray scale before the copy operation.</td>
				</tr>
				<tr>
					<td class="controller" colspan="5">
						<form method="post" name="copyMergeGreyForm">
							<?=phpfun('imageCopyMergeGray')?>&nbsp;(<select name="dst_im" size="1">
								<?=imageList();?>
							</select><select name="dst_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <select name="src_im" size="1">
								<?=imageList();?>
							</select><select name="src_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <input type="text" name="dst_x" value="$dx" size="4" maxlength="3">, <input type="text" name="dst_y" value="$dy" size="4" maxlength="3">, <input type="text" name="src_x" value="$sx" size="4" maxlength="3">, <input type="text" name="src_y" value="$sy" size="4" maxlength="3">, <input type="text" name="src_w" value="$sw" size="4" maxlength="3">, <input type="text" name="src_h" value="$sh" size="4" maxlength="3">, <input type="text" name="pct" value="$pct" size="5" maxlength="4">&nbsp;)&nbsp;;
							<p><input onclick="iCMGray(this.form);" type="button" name="iCMGrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"><img src="blackbox.png" alt="" name="iCMGdst" height="100" width="100" border="0"></td>
					<td align="center">+</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCMGsrc" height="100" width="100" border="0"></td>
					<td align="center">=&gt;</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCMGrst" height="100" width="100" border="0"></td>
				</tr>
				<tr>
					<td class="phpnet" colspan="5"><a name="imageCopyResized"></a>int <?=phpfun('imageCopyResized')?>&nbsp; ( resource dst_im, resource src_im, int dstX, int dstY, int srcX, int srcY, int dstW, int dstH, int srcW, int srcH)<br />
						Copies a rectangular portion of one image to another image. <i>dst_im</i> is the destination image, <i>src_im</i> is the source image identifier. If the source and destination coordinates and width and heights differ, appropriate stretching or shrinking of the image fragment will be performed. The coordinates refer to the upper left corner. This function can be used to copy regions within the same image (if <i>dst_im</i> is the same as <i>src_im</i>) but if the regions overlap the results will be unpredictable.</td>
				</tr>
				<tr>
					<td class="controller" colspan="5">
						<form method="post" name="copyResizedForm">
							<?=phpfun('imageCopyResized')?>&nbsp;(<select name="dst_im" size="1">
								<?=imageList();?>
							</select><select name="dst_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <select name="src_im" size="1">
								<?=imageList();?>
							</select><select name="src_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <input type="text" name="dst_x" value="$dx" size="4" maxlength="3">, <input type="text" name="dst_y" value="$dy" size="4" maxlength="3">, <input type="text" name="src_x" value="$sx" size="4" maxlength="3">, <input type="text" name="src_y" value="$sy" size="4" maxlength="3">, <input type="text" name="dst_w" value="$dw" size="4" maxlength="3">, <input type="text" name="dst_h" value="$dh" size="4" maxlength="3">, <input type="text" name="src_w" value="$sw" size="4" maxlength="3">, <input type="text" name="src_h" value="$sh" size="4" maxlength="3">&nbsp;)&nbsp;;
							<p><input onclick="iCResized(this.form);" type="button" name="iCRSZrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"><img src="blackbox.png" alt="" name="iCRZdst" height="100" width="100" border="0"></td>
					<td align="center">+</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCRZsrc" height="100" width="100" border="0"></td>
					<td align="center">=&gt;</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCRZrst" height="100" width="100" border="0"></td>
				</tr>
				<tr>
					<td class="phpnet" colspan="5"><a name="imageCopyResampled"></a>int <?=phpfun('imageCopyResampled')?>&nbsp; ( resource dst_im, resource src_im, int dstX, int dstY, int srcX, int srcY, int dstW, int dstH, int srcW, int srcH)<br />
						Copies a rectangular portion of one image to another image, smoothly interpolating pixel values so that, in particular, reducing the size of an image still retains a great deal of clarity. <i>dst_im</i> is the destination image, <i>src_im</i> is the source image identifier. If the source and destination coordinates and width and heights differ, appropriate stretching or shrinking of the image fragment will be performed. The coordinates refer to the upper left corner. This function can be used to copy regions within the same image (if <i>dst_im</i> is the same as <i>src_im</i>) but if the regions overlap the results will be unpredictable.</td>
				</tr>
				<tr>
					<td class="controller" colspan="5">
						<form method="post" name="copyResampledForm">
							<?=phpfun('imageCopyResampled')?>&nbsp;(<select name="dst_im" size="1">
								<?=imageList();?>
							</select><select name="dst_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <select name="src_im" size="1">
								<?=imageList();?>
							</select><select name="src_fmt" size="1">
								<option value=".png">.png</option>
								<option selected value=".jpg">.jpg</option>
							</select>, <input type="text" name="dst_x" value="$dx" size="4" maxlength="3">, <input type="text" name="dst_y" value="$dy" size="4" maxlength="3">, <input type="text" name="src_x" value="$sx" size="4" maxlength="3">, <input type="text" name="src_y" value="$sy" size="4" maxlength="3">, <input type="text" name="dst_w" value="$dW" size="4" maxlength="3">, <input type="text" name="dst_h" value="$dH" size="4" maxlength="3">, <input type="text" name="src_w" value="$sH" size="4" maxlength="3">, <input type="text" name="src_h" value="$sH" size="4" maxlength="3">&nbsp;)&nbsp;;
							<p><input onclick="iCResampled(this.form);" type="button" name="iCRSPrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"><img src="blackbox.png" alt="" name="iCRDdst" height="100" width="100" border="0"></td>
					<td align="center">+</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCRDsrc" height="100" width="100" border="0"></td>
					<td align="center">=&gt;</td>
					<td align="center"><img src="blackbox.png" alt="" name="iCRDrst" height="100" width="100" border="0"></td>
				</tr>
				<tr>
					<td class="phpnet" colspan="5"><a name="imageColorMatch"></a>bool <?=phpfun('imageColorMatch')?>&nbsp; ( resource image1, resource image2)<br />
						Makes the colors of the palette version of an image more closely match the true color version. <i>image1</i> must be Truecolor, <i>image2</i> must be Palette, and both <i>image1</i> and <i>image2</i> must be the same size.</td>
				</tr>
				<tr>
					<td class="controller" colspan="5">
						<form method="post" name="colorMatchForm">
							<?=phpfun('imageColorMatch')?>&nbsp;(<select name="dst_im" size="1">
								<?=imageList();?>
							</select><select name="dst_fmt" size="1">
								<option selected value=".jpg">.jpg</option>
							</select>, <select name="src_im" size="1">
								<?=imageList();?>
							</select><select name="src_fmt" size="1">
								<option value=".png">.png</option>
							</select>) ;
							<p><input onclick="iCMatch(this.form);" type="button" name="iCMrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"><img src="blackbox.png" alt="" name="iMdst" height="100" width="100" border="0"></td>
					<td align="center">+</td>
					<td align="center"><img src="blackbox.png" alt="" name="iMsrc" height="100" width="100" border="0"></td>
					<td align="center">=&gt;</td>
					<td align="center"><img src="blackbox.png" alt="" name="iMrst" height="100" width="100" border="0"></td>
				</tr>
				<tr>
					<td class="phpnet" colspan="5"><a name="imagePaletteCopy"></a>int <?=phpfun('imagePaletteCopy')?>&nbsp; ( resource destination, resource source)<br />
						Copies the palette from the <i>source</i> image to the <i>destination</i> image.</td>
				</tr>
				<tr>
					<td class="controller" colspan="5">
						<form method="post" name="imagePaletteCopyForm">
							<?=phpfun('imagePaletteCopy')?>&nbsp;(<select name="dst_im" size="1">
								<?=imageList();?>
							</select><select name="dst_fmt" size="1">
								<option selected value=".png">.png</option>
							</select>, <select name="src_im" size="1">
								<?=imageList();?>
							</select><select name="src_fmt" size="1">
								<option value=".png">.png</option>
							</select> ) ;
							<p><input onclick="iPCopy(this.form);" type="button" name="iPCrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"><img src="blackbox.png" alt="" name="iPCdst" height="100" width="100" border="0"></td>
					<td align="center">+</td>
					<td align="center"><img src="blackbox.png" alt="" name="iPCsrc" height="100" width="100" border="0"></td>
					<td align="center">=&gt;</td>
					<td align="center"><img src="blackbox.png" alt="" name="iPCrst" height="100" width="100" border="0"></td>
				</tr>
				<tr>
					<td class="phpnet" colspan="5"><a name="imageRotate"></a>resource <?=phpfun('imageRotate ')?>&nbsp; ( resource src_im, float angle, int bgd_color )<br />
						Rotates the <i>src_im</i> image using a given <i>angle</i> in degree. <i>bgd_color</i> specifies the color of the uncovered zone after the rotation. </td>
				</tr>
				<tr>
					<td class="controller" colspan="5">
						<form method="post" name="imagePaletteCopyForm">
							<?=phpfun('imageRotate')?>&nbsp;(<select name="src_im" size="1">
								<?=imageList();?>
							</select><select name="src_fmt" size="1">
								<option selected value=".jpg">.jpg</option>
							</select>, <input type="text" name="a" value="$angle" size="8" maxlength="6">, <select name="c" size="1">
								<option value="FFFFFF">$white</option>
								<option value="FF0000">$red</option>
								<option value="00FF00">$green</option>
								<option value="0000FF">$blue</option>
								<option value="7FFF00">$lime</option>
								<option value="FF7F00">$orange</option>
								<option value="7F00FF">$purple</option>
								<option selected value="000000">$black</option>
							</select> ) ;
							<p><input onclick="iRotate(this.form);" type="button" name="iROTrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"></td>
					<td align="center"></td>
					<td align="center"><img src="blackbox.png" alt="" name="iROTsrc" height="100" width="100" border="0"></td>
					<td align="center">=&gt;</td>
					<td align="center"><img src="blackbox.png" alt="" name="iROTrst" height="100" width="100" border="0"></td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>
