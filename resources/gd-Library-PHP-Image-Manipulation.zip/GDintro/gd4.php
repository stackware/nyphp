<?PHP
$slide_title = 'What About GIF?';
require ('presfun.php');
$gExp = mktime(0,0,0,7,7,2004) - time(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<? navtable($slide_title); ?>
		<div align='center'>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>From the <a href="http://www.boutell.com/gd/manual2.0.15.html">GD Manual</a> &amp; <a href="http://www.boutell.com/gd/faq.html" target="_blank">GD Library FAQ</a></td>
				</tr>
				<tr>
					<td><b>Update: I do expect to reintroduce GIF support after July 7th, 2004, however due to a family emergency this may not be immediate. Thanks for your patience.</b>
						<p>[author's note: I'll update this site as soon as support makes its way into the bundled version, but since I'm not involved in any of those efforts, I can't give a realistic estimate of when that might be.]</p>
						<p>GD 2 creates PNG, JPEG and WBMP images, not GIF images. This is a good thing. Please do not ask us to send you the old GIF version of gd. Unisys holds a patent on the LZW compression algorithm, which is used in fully compressed GIF images. The best solution is to move to legally unencumbered, well-compressed, modern image formats such as PNG and JPEG as soon as possible.
</p>
						<p>Many have asked whether GD will support creating GIF files again, since we have passed June 20th, 2003, when the well-known Unisys LZW patent expired in the US. Although this patent has expired in the United States, this patent does not expire for another year in the rest of the world. GIF creation will not reappear in GD until the patent expires <b>world-wide</b> on July 7th, <b>2004</b>.</p>
					</td>
				</tr>
				<tr>
					<td class="heading">Now...</td>
				</tr>
				<tr>
					<td>The legal issue with GIF files is the LZW compression algorithm, not the file structure itself. Toshio Kuratomi wrote libungif, a modified version Eric S. Raymond's libgif GIF encoder that saves GIFs uncompressed, thus completely avoiding any licensing issues. The obvious problem is that the uncompressed GIF images will be larger than those encoded using the LZW algorithm. 
						<p><a href="http://prtr-13.ucsc.edu/%7ebadger/software/libungif.shtml">http://prtr-13.ucsc.edu/~badger/software/libungif.shtml</a></p>
					</td>
				</tr>
			</table>
			<p><? navtable(''); ?></p>
		</div>
	</body>

</html>
