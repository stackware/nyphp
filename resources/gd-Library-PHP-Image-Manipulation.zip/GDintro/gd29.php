<?PHP
$slide_title = 'Bibliography/Reference';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" target="_blank">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen" target="_blank">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td colspan="3">
						<p>
							<a href="http://www.php.net/manual/en/ref.image.php" target="_blank">PHP.net Manual<a>
						</p>
						<p>
							<a href="http://www.boutell.com/gd/" target="_blank">GD Graphics Library<a><br />
							<a href="http://www.onlamp.com/pub/a/php/2003/03/27/php_gd.html" target="_blank">Compiling and Enabling GD in PHP 4.3 by Marco Tabini<a><br />
							<a href="http://codewalkers.com/tutorials.php?show=3" target="_blank">An intro to using the GD image library with PHP by Matt Wade<a><br />
						</p>
						<p>
							<a href="http://netghost.narod.ru/gff/graphics/main.htm" target="_blank">Encyclopedia of Graphics File Formats<a><br />
							<a href="http://www.libpng.org/pub/png/" target="_blank">PNG (Portable Network Graphics) Home Site<a><br />
							<a href="http://cloanto.com/users/mcb/19950127giflzw.html" target="_blank">The GIF Controversy: A Software Developer's Perspective<a><br />
							<a href="http://www.htmlhelp.com/design/imageuse.htm" target="_blank">Web Design Group - Image Use on the Web<a><br />
							<a href="http://www.rgbworld.com/color.html" target="_blank">RGB World: RGB Color Info<a><br />
							<a href="http://www.cs.princeton.edu/courses/archive/fall00/cs426/papers/smith95c.pdf" target="_blank">Alpha and the History of Digital Compositing by Alvy Ray Smity<a>
						</p>
						<p>
							<a href="http://partners.adobe.com/asn/tech/type/ftypes.jsp" target="_blank">Adobe Solutions Network: Font Formats, File Types and Q&amp;A<a>
						</p>
					</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>