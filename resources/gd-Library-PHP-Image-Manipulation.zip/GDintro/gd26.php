<?PHP
$slide_title = 'Button Example';
require ('presfun.php');
$btbg = 'B0C4DE';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<style type="text/css" media="screen"><!--
		.btneg  { background-color: #<?=$btbg?> }
		--></style>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--
		function showBG() {
			alert(document.styleSheets[0].cssRules[0].style.getPropertyValue('background-color') ); 
		}
		
		function updateButtons(data) {

			if (document.styleSheets[0].cssRules) {
	                document.styleSheets[0].cssRules[0].style.setProperty('background-color','#'+data.bg.value,null);
	       	} else if (document.styleSheets[0].rules) {
	                document.styleSheets[0].rules[0].style.bgcolor == '#'+data.bg.value ;
	        }
			data.btn1.src = "btn.php"
				+ "?string=" + data.s1.value
				+ "&fg=" + data.c1.value
				+ "&bg=" + data.bg.value ;
			data.btn2.src = "btn.php"
				+ "?string=" + data.s2.value
				+ "&fg=" + data.c2.value
				+ "&bg=" + data.bg.value ;
			data.btn3.src = "btn.php"
				+ "?string=" + data.s3.value
				+ "&fg=" + data.c3.value
				+ "&bg=" + data.bg.value ;
			data.btn4.src = "btn.php"
				+ "?string=" + data.s4.value
				+ "&fg=" + data.c4.value
				+ "&bg=" + data.bg.value ;
		}

		function setDown(btn) {
			btn.src = btn.src + "&state=down" ;
		}
		function setUp(btn) {
			btn.src = btn.src.replace("&state=down","") ;
		}
		-->
		</script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td align="center">
						<form method="get" name="buttonForm">
							<div align="center">
								<table border="0" cellspacing="0" cellpadding="0">
									<tr>
										<td class="btneg" width="200"><img src="btn.php?string=A&bg=<?=$btbg?>" alt="" name="btn1" border="0" hspace="10" onmouseover="setDown(this);" onmouseout="setUp(this);" vspace="4"></td>
										<td width="10">&nbsp;</td>
										<td class="controller">&nbsp;<input type="text" name="s1" value="A" size="24"> <input type="text" name="c1" value="000000" size="8" maxlength="6"></td>
									</tr>
									<tr>
										<td class="btneg" width="200"><img src="btn.php?string=Long&bg=<?=$btbg?>" alt="" name="btn2" border="0" hspace="10" onmouseover="setDown(this);" onmouseout="setUp(this);" vspace="4"></td>
										<td width="10"></td>
										<td class="controller">&nbsp;<input type="text" name="s2" value="Long" size="24"> <input type="text" name="c2" value="000000" size="8" maxlength="6"></td>
									</tr>
									<tr>
										<td class="btneg" width="200"><img src="btn.php?string=Button&bg=<?=$btbg?>" alt="" name="btn3" border="0" hspace="10" onmouseover="setDown(this);" onmouseout="setUp(this);" vspace="4"></td>
										<td width="10"></td>
										<td class="controller">&nbsp;<input type="text" name="s3" value="Button" size="24"> <input type="text" name="c3" value="000000" size="8" maxlength="6"></td>
									</tr>
									<tr>
										<td class="btneg" width="200"><img src="btn.php?string=Example&bg=<?=$btbg?>" alt="" name="btn4" border="0" hspace="10" onmouseover="setDown(this);" onmouseout="setUp(this);" vspace="4"></td>
										<td width="10"></td>
										<td class="controller">&nbsp;<input type="text" name="s4" value="Example" size="24"> <input type="text" name="c4" value="000000" size="8" maxlength="6"></td>
									</tr>
									<tr>
										<td class="btneg" width="200">&nbsp;</td>
										<td width="10"></td>
										<td class="controller" align="center"><input onclick="updateButtons(this.form);" type="button" name="rd" value="redraw">&nbsp;&nbsp;<input type="text" name="bg" value="B0C4DE" size="8" maxlength="6"></td>
									</tr>
								</table>
							</div>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center">
						<table border="0" cellspacing="0" cellpadding="4">
							<tr>
								<td align="center" valign="middle" bgcolor="#7f7f7f"><img src="btn_shadow.png" alt="" width="58" height="32" border="0"></td>
								<td align="center" valign="middle" bgcolor="#7f7f7f"><img src="btn_body.png" alt="" width="58" height="32" border="0"></td>
								<td align="center" valign="middle" bgcolor="#7f7f7f"><img src="btn_highlight.png" alt="" width="58" height="32" border="0"></td>
							</tr>
							<tr>
								<td align="center" valign="middle"><font size="-4">btn_shadow.png</font></td>
								<td align="center" valign="middle"><font size="-4">btn_body.png</font></td>
								<td align="center" valign="middle"><font size="-4">btn_highlight.png</font></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="source"><? show_source('btn.php')?></td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>