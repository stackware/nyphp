<?PHP
/*
$hostname = "localhost";
$usernamedb = "readonly";
$passworddb = "readonly";
$dbName = "presentation";

$link = mysql_connect($hostname, $usernamedb, $passworddb)  or die ("ERROR: Could not connect");
mysql_select_db ($dbName) or die ("ERROR: Could not select database");

$query  = 'SELECT SUM((quantity01 * price01)) as orders, state ';
$query .= 'FROM `sales` GROUP BY state ORDER BY state ';
$result = mysql_query ($query); 
while ($row = mysql_fetch_assoc($result))
	$states[$row['state']] = $row['orders'] ;
*/

$states = array ('AL' => 16, 'AR' => 17, 'AZ' => 53, 'CA' => 57, 
					 'CO' => 52, 'CT' => 37, 'DC' => 40, 'DE' => 38, 
					 'FL' => 11, 'GA' => 10, 'IA' => 15, 'ID' =>  1, 
					 'IL' => 13, 'IN' => 27, 'KS' =>  3, 'KY' => 26, 
					 'LA' => 22, 'MA' => 35, 'MD' => 33, 'ME' => 28, 
					 'MI' => 12, 'MN' =>  2, 'MO' =>  8, 'MS' => 21, 
					 'MT' => 56, 'NC' => 18, 'ND' =>  7, 'NE' =>  4, 
					 'NH' => 32, 'NJ' => 34, 'NM' => 55, 'NV' => 54, 
					 'NY' => 19, 'OH' => 23, 'OK' =>  9, 'OR' => 51, 
					 'PA' => 20, 'RI' => 39, 'SC' => 29, 'SD' =>  5, 
					 'TN' => 24, 'TX' => 58, 'UT' => 63, 'VA' => 25, 
					 'VT' => 31, 'WA' =>  6, 'WI' => 14, 'WV' => 30, 
					 'WY' => 50 );


foreach ($states as $key => $value) $states[$key] = rand(0,1000) ;
$states['NY'] *= 1.5 ;

?>