<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?PHP
$slide_title = ' ';
require ('./presfun.php');
?>

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<table width="100%" border="0" cellspacing="2" cellpadding="2"><tr><td class="navlink" align="left"  valign="top">LAST</td><td class="title" align="center" valign="top"> </td><td class="navlink" align="right" valign="top"><a href='gd2.php'>NEXT</a></td></tr></table><p>&nbsp;</p>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td></td>
				<td align='center'>
					<p>&nbsp;</p>
					<p class='maintitle'>Introduction to PHP Image Functions</p>
					<p class='byline'>
					   by Jeff Knight of New York PHP<br/>
					</p>
               <p style="margin: 55px; ">
                  More <a href="/content/presentations/">presentations</a> and <br /><a href="/phundamentals/">PHundamentals Articles</a> are available.
                  <br /><br />
                  <a href="/"><img border="0" src="http://www.nyphp.org/img/nyphp.logo.sm.black.gif"></a>
               </p>
 				</td>
				<td></td>
			</tr>
		</table>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<div align='right'>
<!-- Creative Commons License -->
<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.0/"><img alt="Creative Commons License" border="0" src="http://creativecommons.org/images/public/somerights20.gif" /></a><br />
This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.0/">Creative Commons License</a>.
<!-- /Creative Commons License -->


<!--

<rdf:RDF xmlns="http://web.resource.org/cc/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
<Work rdf:about="">
   <dc:title>Introduction to PHP Image Functions</dc:title>
   <dc:description>An overview  of the PHP image functions from the gd library with interactive examples.</dc:description>
   <dc:creator><Agent>
      <dc:title>Jeff Knight</dc:title>
   </Agent></dc:creator>
   <dc:rights><Agent>
      <dc:title>Jeff Knight</dc:title>
   </Agent></dc:rights>
   <dc:type rdf:resource="http://purl.org/dc/dcmitype/Interactive" />
   <license rdf:resource="http://creativecommons.org/licenses/by-nc-sa/2.0/" />
</Work>

<License rdf:about="http://creativecommons.org/licenses/by-nc-sa/2.0/">
   <permits rdf:resource="http://web.resource.org/cc/Reproduction" />
   <permits rdf:resource="http://web.resource.org/cc/Distribution" />
   <requires rdf:resource="http://web.resource.org/cc/Notice" />
   <requires rdf:resource="http://web.resource.org/cc/Attribution" />
   <prohibits rdf:resource="http://web.resource.org/cc/CommercialUse" />
   <permits rdf:resource="http://web.resource.org/cc/DerivativeWorks" />
   <requires rdf:resource="http://web.resource.org/cc/ShareAlike" />
</License>

</rdf:RDF>

-->
		</div>
	</body>

</html>
