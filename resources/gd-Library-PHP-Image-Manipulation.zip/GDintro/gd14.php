<?PHP
$slide_title = 'Styles, Tiles & Brushes';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--

		function iSetThickness(data) {
			document.SetThickness.src = 'iDrawFuns.php?iFun=imageSetThickness&t=' + data.t.value  ;
			document.RectangleImage.src = 'iDrawFuns.php?iFun=imageRectangle&ht=100&filled=filled'  ;
			document.Fill2BorderImage.src = 'iDrawFuns.php?iFun=imageFillToBorder'  ;
		}
		
		function iSetTile(data) {
			document.setTile.src = 'iDrawFuns.php?ht=150&iFun=' + data.iFun.value
						+ '&tile=1&stylefile=' + data.tile.value ;
		}
		
		function iSetBrush(data) {
			document.setBrush.src = 'iDrawFuns.php?ht=150&iFun=' + data.iFun.value
						+ '&brush=1&stylefile=' + data.brush.value ;
		}
		
		function iSetStyle(data) {
			document.SetStyle.src =  'iDrawFuns.php?ht=200&iFun=' + data.iFun.value
						+ '&sts[0]=' + data.elements[0].value 
						+ '&sts[1]=' + data.elements[1].value 
						+ '&sts[2]=' + data.elements[2].value
						+ '&sts[3]=' + data.elements[3].value
						+ '&sts[4]=' + data.elements[4].value
						+ '&sts[5]=' + data.elements[5].value
						+ '&sts[6]=' + data.elements[6].value
						+ '&sts[7]=' + data.elements[7].value
						+ '&sts[8]=' + data.elements[8].value
						+ '&sts[9]=' + data.elements[9].value ;
		}

		--></script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td colspan="4">You aren't limited to drawing shapes with a single pixel line, or filling areas with one flat color; the GD library provides several functions that can alter the default behavior of the drawing and filling functions.</td>
				</tr>
				<tr>
					<td class="phpnet" colspan="4" bgcolor="#aaaaaa"><a name="imageSetThickness"></a>void <?=phpFun('imageSetThickness')?>&nbsp;( resource image, int thickness)<br />
						Sets the thickness of the lines drawn when drawing rectangles, polygons, ellipses etc. etc. to <i>thickness</i> pixels.</td>
				</tr>
				<tr>
					<td align="center"><img src="iDrawFuns.php?iFun=imageSetThickness" alt="" name="SetThickness" height="100" width="150" border="0"></td>
					<td class="controller" valign="middle">
						<form method="post" name="setThicknessForm">
							<select name="imageThickness" size="1">
								<option value="imageFill">imageThickness</option>
							</select> ($im, <input type="text" name="t" value="$t" size="3" maxlength="2">&nbsp;) ;
							<p><input onclick="iSetThickness(this.form);" type="button" name="istrd" value="redraw"></p>
						</form>
					</td>
					<td align="center" valign="middle"><img src="iDrawFuns.php?iFun=imageRectangle&ht=100&filled=filled" alt="" name="RectangleImage" height="100" width="150" border="0"></td>
					<td align="center" valign="middle"><img src="iDrawFuns.php?iFun=imageFillToBorder" alt="" name="Fill2BorderImage" height="100" width="150" border="0"></td>
				</tr>
				<td colspan="4">Unlike the following functions that are only applied in conjunction with the use of special color constants, <?=phpFun('imageSetThickness()')?>&nbsp; is a global property and effects every drawing function after it is called.</td>
				<tr>
					<td class="phpnet" colspan="4" valign="middle" bgcolor="#aaaaaa"><a name="imageSetStyle"></a>int <?=phpFun('imageSetStyle')?>&nbsp;( resource image, array style)<br />
						Sets the style to be used by all line drawing functions when drawing with the special color IMG_COLOR_STYLED. The <i>style</i> parameter is an array of pixels.</td>
				</tr>
				<tr>
					<td><img src="iDrawFuns.php?iFun=imageSetStyle&ht=200" alt="" name="SetStyle" height="200" width="150" border="0"></td>
					<td class="controller" colspan="3" align="left" nowrap>
						<form method="post" name="setStyleForm">
							$style = array ( <?PHP for ($n=0;$n<10;++$n) { 
											if ($n>0) echo ','; ?><select name="style[<?=$n?>]" size="1">
								<option value="w">$wh</option>
								<option value="r">$rd</option>
								<option value="g">$gr</option>
								<option value="b">$bl</option>
								<option value="l">$li</option>
								<option value="o">$or</option>
								<option value="p">$pu</option>
								<option value="k">$bk</option>
								<option value="na">n/a</option>
							</select><?PHP } ?> );
							<p>imageSetStyle($im, $style) ;</p>
							<p><select name="iFun" size="1">
									<option value="imageLine">imageLine($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imageRectangle">imageRectangle($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imageRectangle&filled=filled">imageFilledRectangle($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imagePolygon">imagePolygon($im,$im,$points,$num_points,IMG_COLOR_STYLED)</option>
									<option value="imagePolygon&filled=filled">imageFilledPolygon($im,$im,$points,$num_points,IMG_COLOR_STYLED)</option>
									<option value="imageEllipse">imageEllipse($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imageEllipse&filled=filled">imageFilledEllipse($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imageArc">imageArc($im,$cx,$cy,$w,$h, $s, $e,IMG_COLOR_STYLED)</option>
									<option value="imageArc&filled=filled">imageFilledArc($im,$cx,$cy,$w,$h, $s, $e,IMG_COLOR_STYLED, IMG_ARC_PIE)</option>
								</select></p>
							<p><input onclick="iSetStyle(this.form);" type="button" name="issrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<td colspan="4">The next two functions load existing images and use them to create styles. These are the original images  provided as options in the examples:

					<div align="center">
						<table border="0" cellspacing="0" cellpadding="4">
							<tr>
								<td align="center" valign="middle" bgcolor="#7f7f7f"><img src="cbrd.png" alt="" width="16" height="16" border="0"></td>
								<td align="center" valign="middle" bgcolor="#7f7f7f"><img src="reddot.png" alt="" width="7" height="7" border="0"></td>
								<td align="center" valign="middle" bgcolor="#7f7f7f"><img src="rbow.png" alt="" width="12" height="2" border="0"></td>
								<td align="center" valign="middle" bgcolor="#7f7f7f"><img src="nyphp.png" alt="" width="36" height="36" border="0"></td>
							</tr>
							<tr>
								<td align="center" valign="middle"><font size="-4">checkerboard</font></td>
								<td align="center" valign="middle"><font size="-4">red dot</font></td>
								<td align="center" valign="middle"><font size="-4">rainbow</font></td>
								<td align="center" valign="middle"><font size="-4">NYPHP</font></td>
							</tr>
						</table>
					</div>
				</td>
				<tr>
					<td class="phpnet" colspan="4"><a name="imageSetTile"></a>int <?=phpfun('imageSetTile')?>&nbsp; ( resource image, resource tile )<br />
						Sets the tile image to be used by all region filling functions when filling with the special color IMG_COLOR_TILED. A tile is an image used to fill an area with a repeated pattern. Any GD image can be used as a tile.</td>
				</tr>
				<tr>
					<td><img src="iDrawFuns.php?iFun=imageSetStyle&ht=150" alt="" name="setTile" height="150" width="150" border="0"></td>
					<td class="controller" colspan="3">
						<form method="post" name="setTileForm">
							<?=phpfun('imageSetTile')?>&nbsp;( $im, <select name="tile" size="1">
								<option value="cbrd">checkerboard</option>
								<option value="reddot">red dot</option>
								<option value="rbow">rainbow</option>
								<option value="nyphp">NYPHP</option>
							</select> )&nbsp;;
							<p><select name="iFun" size="1">
									<option value="imageLine">imageLine($im,$x1,$y1,$x2,$y2,IMG_COLOR_TILED)</option>
									<option value="imageRectangle">imageRectangle($im,$x1,$y1,$x2,$y2,IMG_COLOR_TILED)</option>
									<option value="imageRectangle&filled=filled">imageFilledRectangle($im,$x1,$y1,$x2,$y2,IMG_COLOR_TILED)</option>
									<option value="imagePolygon">imagePolygon($im,$im,$points,$num_points,IMG_COLOR_TILED)</option>
									<option value="imagePolygon&filled=filled">imageFilledPolygon($im,$im,$points,$num_points,IMG_COLOR_TILED)</option>
									<option value="imageEllipse">imageEllipse($im,$x1,$y1,$x2,$y2,IMG_COLOR_TILED)</option>
									<option value="imageEllipse&filled=filled">imageFilledEllipse($im,$x1,$y1,$x2,$y2,IMG_COLOR_TILED)</option>
									<option value="imageArc">imageArc($im,$cx,$cy,$w,$h, $s, $e,IMG_COLOR_TILED)</option>
									<option value="imageArc&filled=filled">imageFilledArc($im,$cx,$cy,$w,$h, $s, $e,IMG_COLOR_TILED, IMG_ARC_PIE)</option>
								</select></p>
							<p><input onclick="iSetTile(this.form);" type="button" name="iSTrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td class="phpnet" colspan="4"><a name="imageSetBrush"></a>int <?=phpfun('imageSetBrush')?>&nbsp; ( resource image, resource brush )<br />
						Sets the brush image to be used by all line drawing functions when drawing with the special colors IMG_COLOR_BRUSHED or IMG_COLOR_STYLEDBRUSHED.</td>
				</tr>
				<tr>
					<td><img src="iDrawFuns.php?iFun=imageSetStyle&ht=150" alt="" name="setBrush" height="150" width="150" border="0"></td>
					<td class="controller" colspan="3">
						<form method="post" name="setBrushForm">
							<?=phpfun('imageSetBrush')?>&nbsp;( $im, <select name="brush" size="1">
								<option value="cbrd">checkerboard</option>
								<option value="reddot">red dot</option>
								<option value="rbow">rainbow</option>
								<option value="nyphp">NYPHP</option>
							</select> )&nbsp;;
							<p><select name="iFun" size="1">
									<option value="imageLine">imageLine($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imageRectangle">imageRectangle($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imageRectangle&filled=filled">imageFilledRectangle($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imagePolygon">imagePolygon($im,$im,$points,$num_points,IMG_COLOR_STYLED)</option>
									<option value="imagePolygon&filled=filled">imageFilledPolygon($im,$im,$points,$num_points,IMG_COLOR_STYLED)</option>
									<option value="imageEllipse">imageEllipse($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imageEllipse&filled=filled">imageFilledEllipse($im,$x1,$y1,$x2,$y2,IMG_COLOR_STYLED)</option>
									<option value="imageArc">imageArc($im,$cx,$cy,$w,$h, $s, $e,IMG_COLOR_STYLED)</option>
									<option value="imageArc&filled=filled">imageFilledArc($im,$cx,$cy,$w,$h, $s, $e,IMG_COLOR_STYLED, IMG_ARC_PIE)</option>
								</select></p>
							<p><input onclick="iSetBrush(this.form);" type="button" name="iSBrd" value="redraw"></p>
						</form>
					</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>
