<?PHP
$slide_title = 'Drop Shadow Example';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--
		function doGradient(data) {
			document.gradientExample.src = "gradient.php"
						+ "?foreground=" + data.f.value
						+ "&background=" + data.b.value
						+ "&shadow=" + data.s.value  ;
		}
		-->
		</script>
	</head>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td colspan="2">A practical use of the image functions is to generate a series of permutations from a single set of images. You could, for instance, design all the basic elements of a website in grayscale and use PHP to colorize them to match different color schemes for various subsections or based upon user preferences. The code below demonstrates an example of how to alter the foreground, background and shadow colors of such an image.</td>
				</tr>
				<tr>
					<td class="controller" align="center">
						<form method="get" name="gradientForm">
							<div align="center">
								<table border="0" cellspacing="2" cellpadding="2">
									<tr>
										<td align="right">Foreground:</td>
										<td><input type="text" name="f" value="000000" size="8" maxlength="6"></td>
									</tr>
									<tr>
										<td align="right">Background:</td>
										<td><input type="text" name="b" value="FFFFFF" size="8" maxlength="6"></td>
									</tr>
									<tr>
										<td align="right">Shadow:</td>
										<td><input type="text" name="s" size="8" maxlength="6"></td>
									</tr>
									<tr>
										<td colspan="2" align="center"><input onclick="doGradient(this.form);" type="button" name="udrgb" value="redraw"></td>
									</tr>
								</table>
							</div>
						</form>
					</td>
					<td width="360"><img src="gradient.php" alt="" name="gradientExample" height="240" width="360" border="0"></td>
				</tr>
				<tr>
					<td class="source" colspan="2"><? show_source('gradient.php')?></td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>
