<?PHP
$slide_title = 'The Interactive Example Source';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--
		var RGB = new Array(256);
		var k = 0;
		var hex = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F");
		
		for (i = 0; i < 16; i++) {	
			for (j = 0; j < 16; j++) {		
				RGB[k] = hex[i] + hex[j];
				k++;
			}
		}
		function updatergb(data) {
			if (data.hex.value) {
				data.red.value   = HexToR(data.hex.value) ;
				data.green.value = HexToG(data.hex.value) ;
				data.blue.value  = HexToB(data.hex.value) ;
				document.rgbex.src = 'rgb.php?hex=' + data.hex.value ;
			} else {
				data.red.value   = min(data.red.value,255) ;
				data.green.value = min(data.green.value,255) ;
				data.blue.value  = min(data.blue.value,255) ;
				
				document.rgbex.src = 'rgb.php?red=' + data.red.value 
								+ '&green=' + data.green.value
								+  '&blue=' + data.blue.value ;
				data.hex.value = RGB[data.red.value] 
									+ RGB[data.green.value] 
									+ RGB[data.blue.value]
			}
		}
			
		function clearHex() { document.rgber.hex.value = "" }
			
		function min(x, y) {
			if (x < y)
				return x; 
			else
				return y;
		}
		function HexToR(h) { return parseInt((cutHex(h)).substring(0,2),16) }
		function HexToG(h) { return parseInt((cutHex(h)).substring(2,4),16) }
		function HexToB(h) { return parseInt((cutHex(h)).substring(4,6),16) }
		function cutHex(h) { return (h.charAt(0)==" #") ? h.substring(1,7) : h} 
		-->
		</script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td align="center">
						<form class="controller" method="post" name="rgber">
							<p>&nbsp;</p>
							<table border="0" cellspacing="3" cellpadding="2">
								<tr>
									<td align="right">
										<div align="right">
											red:</div>
									</td>
									<td align="left"><input type="text" name="red" value="0" size="5" maxlength="3" onfocus="clearHex();"></td>
								</tr>
								<tr>
									<td align="right">
										<div align="right">
											&nbsp;green:</div>
									</td>
									<td align="left"><input type="text" name="green" value="0" size="5" maxlength="3" onfocus="clearHex();"></td>
								</tr>
								<tr>
									<td align="right">
										<div align="right">
											blue:</div>
									</td>
									<td align="left"><input type="text" name="blue" value="0" size="5" maxlength="3" onfocus="clearHex();"></td>
								</tr>
								<tr>
									<td colspan="2" align="center">or</td>
								</tr>
								<tr>
									<td colspan="2" align="center" nowrap>&nbsp;hex: <input type="text" name="hex" size="8" maxlength="6"></td>
								</tr>
								<tr>
									<td colspan="2" align="center"><input onclick="updatergb(this.form);" type="button" name="udrgb" value="redraw"></td>
								</tr>
							</table>
							<p>&nbsp;&nbsp;</p>
						</form>
					</td>
					<td align="center" bgcolor="#dddddd"><img src="rgb.php" alt="" name="rgbex" height="229" width="245" border="0">
						<p><font color="#000000">rgb.php</font></p>
					</td>
					<td align="center" bgcolor="#dddddd"><img src="rgb.png" alt="" name="origi" height="229" width="245" border="0">
						<p><font color="#000000">rgb.png</font></p>
					</td>
				</tr>
				<tr>
					<td align="center"></td>
					<td align="center" valign="top"></td>
					<td align="center" valign="top"></td>
				</tr>
				<tr>
					<td class="source" colspan="3"><? show_source('rgb.php')?></td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>