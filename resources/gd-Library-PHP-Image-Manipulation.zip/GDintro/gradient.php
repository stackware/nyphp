<?PHP


error_reporting(E_ALL ^ E_NOTICE);

/*
gradient.php
*/

// convert guaranteed valid hex values to arrays of integers
$foreground = hex2int(validHexColor($_REQUEST['foreground'],'000000'));
$background = hex2int(validHexColor($_REQUEST['background'],'FFFFFF'));
if (isset($_REQUEST['shadow'])) {
	// use a middle grey if color is not valid
	$shadow = hex2int(validHexColor($_REQUEST['shadow'],'666666'));
} else {
	// use a 60% tint of the foreground color if shadow not specified
	$shadow = tintOf($foreground,0.6) ;
}

$im = imageCreateFromPNG('gradient.png');

// Get the indicies of Black & White (the 1st & last values in the table)
$black = imageColorResolve($im,0x00,0x00,0x00) ;
$white = imageColorResolve($im,0xFF,0xFF,0xFF) ;

// from the number of colors, calculate distance between each color step
$colorSteps = imageColorsTotal($im) - 1  ;
$step['r'] = ($shadow['r'] - $background['r']) / $colorSteps ;
$step['g'] = ($shadow['g'] - $background['g']) / $colorSteps ;
$step['b'] = ($shadow['b'] - $background['b']) / $colorSteps ;

// for each index in the palette starting with white,
// set color to new calculated value
for ($n=$white;$n<$black;++$n) 
	imageColorSet($im,$n, 
					round(($n * $step['r']) + $background['r']),
					round(($n * $step['g']) + $background['g']),
					round(($n * $step['b']) + $background['b'])
					) ;
// then set black to the new foreground color
imageColorSet($im,$black,$foreground['r'],$foreground['g'],$foreground['b']);

header("Content-type: image/png");
imagePNG($im);
imageDestroy($im);


/**
 * @param	$hex string		6-digit hexadecimal color
 * @return	array			3 elements 'r', 'g', & 'b' = int color values
 * @desc Converts a 6 digit hexadecimal number into an array of
 *       3 integer values ('r'  => red value, 'g'  => green, 'b'  => blue)
 */
function hex2int($hex) {
        return array(
        			'r' => hexdec(substr($hex, 0, 2)), // 1st pair of digits
        			'g' => hexdec(substr($hex, 2, 2)), // 2nd pair
        			'b' => hexdec(substr($hex, 4, 2))  // 3rd pair
        		);
}

/**
 * @param $input string     6-digit hexadecimal string to be validated
 * @param $default string   default color to be returned if $input isn't valid
 * @return string           the validated 6-digit hexadecimal color
 * @desc returns $input if it is a valid hexadecimal color, 
 *       otherwise returns $default (which defaults to black)
 */
function validHexColor($input = '000000', $default = '000000') {
	// A valid Hexadecimal color is exactly 6 characters long
	// and eigher a digit or letter from a to f
	return (eregi('^[0-9a-f]{6}$', $input)) ? $input : $default ;
}

/**
 * @param $color array  3 elements 'r', 'g', & 'b' = int color values
 * @param $tint float   fraction of color $color to return
 * @return array        new color tinted to $tint of $color
 * @desc returns a new color that is a tint of the original
 *       e.g. (255,127,0) w/ a tint of 0.5 will return (127,63,0)
 */
function tintOf($color,$tint) {
	return array ( 'r' => round(((255-$color['r']) * (1-$tint)) + $color['r']), 
				   'g' => round(((255-$color['g']) * (1-$tint)) + $color['g']),
				   'b' => round(((255-$color['b']) * (1-$tint)) + $color['b']) );
}

?>
