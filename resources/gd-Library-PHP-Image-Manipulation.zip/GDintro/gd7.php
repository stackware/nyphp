<?PHP
$slide_title = 'True Color Vs. Indexed Color';
session_start();
$_SESSION['png'] = 'tree3.png' ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

<?PHP
require ('presfun.php');
for ($n=0;$n<5;++$n) {
	$colors[$n]['r'] = rand(0,255) ;
	$colors[$n]['g'] = rand(0,255) ;
	$colors[$n]['b'] = rand(0,255) ;
	$colors[$n]['hex'] = sprintf("%02X%02X%02X",$colors[$n]['r'],$colors[$n]['g'],$colors[$n]['b']); 
	$colors[$n]['bin'] = sprintf('%08d%08d%08d',decbin($colors[$n]['r']),decbin($colors[$n]['g']),decbin($colors[$n]['b'])) ;	
}

$square[1] = 0 ;
$square[2] = 1 ;
$square[3] = 0 ;
$square[4] = 2 ;
$square[5] = 3 ;
$square[6] = 2 ;
$square[7] = 0 ;
$square[8] = 4 ;
$square[9] = 0 ;
?>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td class="heading">True Color</td>
				</tr>
				<tr>
					<td>Color models with small bit-depths have gaps of missing colors that can't be represented within their coarse data structure. Models that can represent a large number of colors are known as &quot;true color&quot; or &quot;continuous tone&quot; because they can display images without obvious gaps. The most common true color model is 8-bit RGB, which can be used to represent 2^8 x 2^8 x 2^8, or 16,777,216, colors. When storing color information in a file, each pixel is assigned a byte of color information for each channel, so a 150 x 150 pixel true color image would require 67,500 bytes or about 66k in color data alone. Thus, uncompressed true color image file sizes tend to be quite large.</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="heading">Specifying Color With Palettes</td>
				</tr>
				<tr>
					<td><br />
						In order to reduce file sizes, an image with an index color palette uses a 1-dimensional array of color values called a palette, also called a <i>color map</i>, <i>index map</i>, <i>color table</i>, or <i>look-up table (LUT)</i>. The color data in the file is stored as a series of small index values which is known as indirect, or pseudo-color storage. Instead of assigning a 3 byte value to each pixel, the index of the color table is used instead. Thus, an 8 bit paletted color file will be 1/3 the size of a true color file (although it can only display a limited 256 colors). Files can be made even smaller by chosing to use fewer colors than 256. Two colors would require only 1 bit per pixel, four 2/px, and eight 3/px, as seen in the example below.</td>
				</tr>
				<tr>
					<td align="center"><img src="LUT.png" alt="" height="200" width="640" border="0"></td>
				</tr>
				<tr>
					
				</tr>
				<tr>
					<td align="center">
						<table border="0" cellspacing="4" cellpadding="4">
							<tr>
								<td colspan="2" align="center" valign="top">True Color Example:</td>
							</tr>
							<tr>
								<td valign="top">
									<table width="150" border="0" cellspacing="2" cellpadding="2" height="150">
										<tr height="50">
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[1]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[2]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[3]]['hex']?>" alt="" height="50" width="50" border="0"></td>
										</tr>
										<tr height="50">
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[4]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[5]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[6]]['hex']?>" alt="" height="50" width="50" border="0"></td>
										</tr>
										<tr height="50">
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[7]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[8]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[9]]['hex']?>" alt="" height="50" width="50" border="0"></td>
										</tr>
									</table>
								</td>
								<td valign="top" width="440"><code><?PHP foreach ($square as $index) echo spaceout($colors[$index]['bin']) ; ?></code></td>
							</tr>
							<tr>
								<td colspan="2" align="center" valign="top">Index Color Example:</td>
							</tr>
							<tr>
								<td>
									<table width="150" border="0" cellspacing="2" cellpadding="2" height="150">
										<tr height="50">
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[1]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[2]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[3]]['hex']?>" alt="" height="50" width="50" border="0"></td>
										</tr>
										<tr height="50">
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[4]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[5]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[6]]['hex']?>" alt="" height="50" width="50" border="0"></td>
										</tr>
										<tr height="50">
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[7]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[8]]['hex']?>" alt="" height="50" width="50" border="0"></td>
											<td width="50" height="50"><img src="simplepng.php?color=<?=$colors[$square[9]]['hex']?>" alt="" height="50" width="50" border="0"></td>
										</tr>
									</table>
								</td>
								<td valign="top" nowrap width="440"><code><?PHP foreach ($colors as $index => $junk) echo sprintf('%03d',decbin($index)) . ' =&gt; '. spaceout($colors[$index]['bin']) . '<br />'; ?>
										<hr>
										<?PHP foreach ($square as $index) echo spaceout(sprintf('%03d',decbin($index))) ; ?></code></td>
							</tr>
						</table>
					</td>
				</tr>
				</tr>
				<tr>
					<td class="heading">Which to Use?</td>
				</tr>
				<tr>
					<td>
						<p><img onclick='this.src = "tree.php";' src="tree.php" alt="(c) FreeFoto.com " height="320" width="480" align="right" border="0" hspace="5">The choice has a dramatic impact on file size and image quality. Click on the image at right to cycle through a 2x magnified sample in true color and indexed to 256 and 32 colors. As a general rule of thumb, you'll want to use true color for photorealistic images and index color for simple graphics like charts &amp; graphs.
</p>
						<p>Your choice of image file format also has an impact, since JPEG images are always true color, but PNGs can be any one of fifteen color formats including 8 &amp; 16 bit RGB (true color) as well as 1, 2, 4 and 8 bit palettes (indexed).</p>
						<div align="right">
							<p><font size="-7">Image Supplied by FreeFoto.com</font></p>
						</div>
					</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>

<?PHP
function spaceout($input) {
	return str_replace('0','0 ',str_replace('1','1 ',$input)) ;
}
?>