<?PHP
$slide_title = 'Simple Transparency';
require ('presfun.php');

$bg = randomHTMLcolor() ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script language="JavaScript">
			function popClock() {
				var popWindow = window.open("clock2.php","clock1.php","titlebar=0,menubar=0,height=125,width=124,scrollbars=no")
				popWindow.focus()
				}
		</script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td class="heading">Improving the Clock</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellspacing="0" cellpadding="0">
							<tr height="111" >
								<td height="111">The clock would look a lot better if we got rid of the white box around it, leaving just the circle. This is accomplished by setting one of our indexed colors the special color &quot;transparent&quot;. Any pixels in the image colored with this index will appear transparent in the final image, allowing the background to show through.</td>
								<td height="111">&nbsp;</td>
								<td align="center" valign="middle" bgcolor="#dddddd" width="111" height="111" background="http://www.nyphp.org/img/nyphpICONg.gif"><a href="javascript:popClock();"><img src="clock2.php" alt="" height="101" width="101" border="0"></a></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageColorTransparent"></a>int <?=phpfun('imageColorTransparent')?>&nbsp;( resource image [, int color])<br />
						Sets the transparent color in the image <i>image</i> to <i>color</i>. <i>image</i> is the image identifier returned by <?=phpfun('imageCreate()')?>&nbsp;and color is a color identifier returned by <?=phpfun('imageColorAllocate()')?>. The identifier of the new (or current, if none is specified) transparent color is returned.</td>
				</tr>
				<tr>
					<td class="source"><? show_source('clock2.php')?></td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>