<?PHP
$slide_title = 'The Color Functions';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--
		function alterLogo(data) {
			document.PHPlogo.src = 'colorSetPHP.php?color=' + data.color.value ;
		}
		-->
		</script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>In addition to drawing objects on an existing image, the PHP image functions can also perform transformations on its colors. The main advantage of using index color images with the PHP image functions is that you can globally manipulate colors and color ranges in a predictable manner by altering the index table. This isn't always the case with true color images.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageColorSet"></a>bool <?=phpFun('imageColorSet')?>&nbsp;( resource image, int index, int red, int green, int blue)<br />
						Sets the specified index in the palette to the specified color. This is useful for creating flood-fill-like effects in paletted images without the overhead of performing the actual flood-fill.</td>
				</tr>
				<tr>
					<td>This function basically reassigns the color value of an index in the table. Any pixel in the image set to that index will now display the new color.</td>
				</tr>
				<tr>
					<td align="center">
						<table>
							<tr>
								<td align="center" bgcolor="#9999cc" width="34%"><img src="php.png" alt="PHP Logo" border="0" width="130" height="67" hspace="3"></td>
								<td class="controller" align="center" valign="middle" width="34%">
									<form>
										
										&nbsp;<br />
										<input type="text" name="color" size="8" maxlength="6">
										<p><input onclick="alterLogo(this.form);"  type='button' name="doit" value="imageColorSet"></p>
									</form>
								</td>
								<td align="center" bgcolor="#9999cc" width="34%"><img src="colorSetPHP.php" alt="PHP Logo Altered" name="PHPlogo" border="0" width="130" height="67" hspace="3"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>There are several functions provided to determine the index of a color within an image by position or color:</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageColorAt"></a>int <?=phpFun('imageColorAt')?>&nbsp;( resource image, int x, int y)<br />
						Returns the index of the color of the pixel at the specified location in the image specified by <i>image</i>.
						<p><a name="imageColorClosest"></a>int <?=phpFun('imageColorClosest')?>&nbsp;( resource image, int red, int green, int blue)<br />
							Returns the index of the color in the palette of the image which is &quot;closest&quot; to the specified RGB value. The &quot;distance&quot; between the desired color and each color in the palette is calculated as if the RGB values represented points in three-dimensional space.</p>
						<p><a name="imageColorClosestHWB"></a>int <?=phpFun('imageColorClosestHWB')?>&nbsp;( resource image, int x, int y, int color)<br />
							Returns the index of the color which has the hue, white and blackness nearest to the given color.</p>
						<p><a name="imageColorExact"></a>int <?=phpFun('imageColorExact')?>&nbsp;( resource image, int red, int green, int blue)<br />
							Returns the index of the specified color in the palette of the image. If the color does not exist in the image's palette, -1 is returned.</p>
						<p><a name="imageColorResolve"></a>int <?=phpFun('imageColorResolve')?>&nbsp;( resource image, int red, int green, int blue)<br />
							This function is guaranteed to return a color index for a requested color, either the exact color or the closest possible alternative.</p>
					</td>
				</tr>
				<tr>
					<td align="left">Note that the colors in an image you might think are 'exact' and 'closest' aren't always the ones that these functions are going to pick. Using these functions with your images may require some trial and erorr.
</td>
				</tr>
				<tr>
					<td class="source" align="left"><? show_source('colorSetPHP.php')?></td>
				</tr>
				<tr>
					<td align="left">A few more useful color functions:</td>
				</tr>
				<tr>
					<td class="phpnet" align="left"><a name="imageColorsTotal"></a>int <?=phpFun('imageColorsTotal')?>&nbsp;( resource image)<br />
						
						Returns the number of colors in the specified image's palette.

						<p><a name="imageColorDeallocate"></a>int <?=phpFun('imageColorDeallocate')?>&nbsp;( resource image, int color)<br />
							This function de-allocates a color.</p>
						<p><a name="imageColorsForIndex"></a>array <?=phpFun('imageColorsForIndex')?>&nbsp;( resource image, int index)<br />
							This returns an associative array with red, green, blue and alpha keys that contain the appropriate values for the specified color index.</p>
						<p><a name="imageTrueColorToPalette"></a>void <?=phpfun('imageTrueColorToPalette')?>&nbsp; ( resource image, bool dither, int ncolors)<br />
							Converts a truecolor image to a palette image. If <i>dither</i> is TRUE then dithering will be used which will result in a more speckled image but with better color approximation. <i>ncolors</i> sets the maximum number of colors that should be retained in the palette. It is usually best to simply produce a truecolor output image instead.</p>
						<p><a name="imageGammaCorrect"></a>int <?=phpfun('imageGammaCorrect')?> ( resource image, float inputgamma, float outputgamma)<br />
							Applies gamma correction to a GD image stream (<i>image</i>) given an input gamma, <i>inputgamma</i> and an output gamma, <i>outputgamma</i>. </p>
					</td>
				</tr>
				<tr>
					<td align="left">Gamma correction is the ability to correct for differences in how computer systems interpret color values. Macintosh-generated images tend to look too dark on PCs, and PC-generated images tend to look too light on Macs. </td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>
