<?PHP
$slide_title = 'Alpha Channels';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>
						<p>There are times when an all-or-nothing approach to transparency isn't sufficient, like when you need the background to show through part or all of your image. In the 70's at New York Tech Catmull &amp; Smith invented an approach to this problem called an alpha channel. Basically, a fourth channel is added to the image containing the values for the transparency of each pixel. Typically, this channel is of the same bit-depth as the others, but GD's alpha channel only supports values from 0 to 127. Alpha Channels are only supported in true color images.</p>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageColorAllocateAlpha"></a>int <?=phpfun('imageColorAllocateAlpha')?>&nbsp; ( resource image, int red, int green, int blue, int alpha )<br />Behaves identically to <?=phpfun('imageColorAllocate')?>with the addition of the transparency parameter alpha which may have a value between 0 and 127. 0 indicates completely opaque while 127 indicates completely transparent.</td>
				</tr>
				<tr>
					<td align="left">The color information functions have also been extended to support alpha channels.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageColorClosestAlpha"></a>int <?=phpFun('imageColorClosestAlpha')?>&nbsp;( resource image, int red, int green, int blue, int alpha )<br />Returns the index of the color in the palette of the image which is &quot;closest&quot; to the specified RGB value and <i>alpha</i> level. 
						<p><a name="imageColorExactAlpha"></a>int <?=phpFun('imageColorExactAlpha')?>&nbsp;( resource image, int red, int green, int blue, int alpha )<br />Returns the index of the specified color+alpha in the palette of the image. If the color does not exist in the image's palette, -1 is returned.</p>
						<p><a name="imageColorResolveAlpha"></a>int <?=phpFun('imageColorResolveAlpha')?>&nbsp;( resource image, int red, int green, int blue, int alpha )<br />This function is guaranteed to return a color index for a requested color, either the exact color or the closest possible alternative.</p>
					</td>
				</tr>
				<tr>
					<td>There are two different ways GD draws within truecolor images. In <b>blending mode</b>, the alpha channel component of the color supplied to all drawing functions determines how much of the underlying color should be allowed to shine through. As a result, GD automatically blends the existing color at that point with the drawing color, and stores the result in the image. The resulting pixel is opaque. In <b>non-blending mode</b>, the drawing color is copied literally with its alpha channel information, replacing the destination pixel.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageAlphaBlending"></a>int <?=phpfun('imageAlphaBlending')?>&nbsp; ( resource image, bool blendmode )<br />
						Sets the blending mode for an image, allowing for two different modes of drawing on truecolor images. If blendmode is TRUE, then blending mode is enabled, otherwise disabled. Notice that AlphaBlending is ON by default. So, only use this function if you don't want to use AlphaBlending.</td>
				</tr>
				<tr>
					<td>While this function is useful for manipulating layers of images within GD, it is not supported within any of the output file formats except for true color (not indexed) PNGs, and you must specify you want the PNG saved in a manner that supports it (i.e. PNG-24 vs. the standard PNG-8). Note also that not all browsers support PNG-24.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageSaveAlpha"></a>int <?=phpfun('imageSaveAlpha')?>&nbsp; ( resource image, bool saveflag )<br />
						Sets the flag to attempt to save full alpha channel information (as opposed to single-color transparency) when saving PNG images. You have to unset alpha blending (<?=phpfun('imageAlphaBlending($im,FALSE)')?>), to use it.</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>

</html>
