<?PHP
/*
tree.php
Cycles through the 3 abstract pngs with each refresh
*/

session_start(); // use sessions to remember state

switch ($_SESSION['png']) {
	case 'tree1.png': // if 1, cycle to 2
		$_SESSION['png'] = 'tree2.png' ;
		break;
	case 'tree2.png': // if 2, cycle to 3
		$_SESSION['png'] = 'tree3.png' ;
		break;
	default:          // otherwise cycle to 1
		$_SESSION['png'] = 'tree1.png' ;
		break;
}

// create, send headers, output & destroy
$im = imageCreateFromPNG($_SESSION['png']) ;
header('Content-type: image/png');
imagePNG($im);
imageDestroy($im);
?>

