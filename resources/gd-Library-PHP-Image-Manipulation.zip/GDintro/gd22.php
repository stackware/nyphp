<?PHP
$slide_title = 'Utility Functions';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>
						<p>
						</p>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imagesx"></a>int <?=phpfun('imagesx')?>&nbsp; ( resource image )<br />
						Returns the width of the image identified by <i>image</i>.
						<p><a name="imagesy"></a>int <?=phpfun('imagesy')?>&nbsp; ( resource image )<br />
							Returns the height of the image identified by <i>image</i>.</p>
						<p><a name="imageIsTrueColor"></a>bool <?=phpfun('imageIsTrueColor')?>&nbsp; ( resource image )<br />
							Returns TRUE if the image <i>image</i> is a truecolor image.</p>
					</td>
				</tr>
				<tr>
					<td></td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageInterlace"></a>int <?=phpfun('imageInterlace')?>&nbsp; ( resource image [, int interlace] )<br />
						Turns the interlace bit on or off. If interlace is 1 the image will be interlaced, and if interlace is 0 the interlace bit is turned off. If the image is used as a JPEG image, the image is created as a progressive JPEG.<br />
						
						This function returns whether the interlace bit is set for the image.</td>
				</tr>
				<tr>
					<td align="left">Interlaced images have their rows stored in some order that is more or less uniformly distributed throughout the image, rather than sequentially.  Web browsers make use of this by displaying a crude representation of the image which gets finer over time as the image finishes loading.  This is sometimes convenient because it allows the user to see a general impression of the whole image without having to wait for all of it to load.</td>
				</tr>

				<tr>
					<td class="phpnet"><a name="imageAntialias"></a>bool <?=phpfun('imageAntialias')?>&nbsp; ( int im, bool on )<br />
						Should antialias functions be used or not. This function is currently not documented; only the argument list is available.</td>
				</tr>
				<tr>
					<td></td>
				</tr>
				<tr>
					<td align="center">
						<table border="0" cellspacing="0" cellpadding="0">
							<tr height="110">
								<td rowspan="2" align="left" valign="top">This term aliasing is originally from signal processing where it refers to  an undersampled function yielding unwanted results. In imaging an example is a diagonal line drawn on a low-resolution raster display, yielding an undesirable &quot;staircase&quot; look. Antialiasing smooths out this discretization of an image by padding pixels with intermediate colors.</td>
								<td align="center" valign="middle" width="110" height="110"><img src="aliased.png" alt="" width="100" height="100" border="0" hspace="5" vspace="5"></td>
								<td align="center" valign="middle" width="110" height="110"><img src="antialiased.png" alt="" width="100" height="100" border="0" hspace="5" vspace="5"></td>
							</tr>
							<tr>
								<td align="center" valign="top" width="110"><font size="-4">aliased</font></td>
								<td align="center" valign="top" width="110"><font size="-4">antialiased</font></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>
