<?PHP

error_reporting(E_ALL ^ E_NOTICE);

session_start(); // use sessions to remember thickness

if (isset($_REQUEST['t'])) {
	$_SESSION['thickness'] = (is_numeric($_REQUEST['t']))?$_REQUEST['t']:1;
} elseif (!isset($_SESSION['thickness'])) {	
	$_SESSION['thickness'] = 1 ;
}

$wd = (is_numeric($_REQUEST['wd']) && ($_REQUEST['wd'] >= 50))?$_REQUEST['wd']:150;
$ht = (is_numeric($_REQUEST['ht']) && ($_REQUEST['ht'] >= 50))?$_REQUEST['ht']:100;

$im = imageCreateTrueColor($wd,$ht);

$white  = imageColorAllocate($im, 0xFF, 0xFF, 0xFF); 
imageFill($im,1,1,$white);
$grey   = imageColorAllocate($im, 150, 150, 150); 
$cyan   = imageColorAllocate($im, 0, 200, 255); 
$orange = imageColorAllocate($im, 255, 127, 0);
$purple = imageColorAllocate($im, 127, 0, 255);
$lime   = imageColorAllocate($im, 127, 255, 0);
$red    = imageColorAllocate($im, 255, 0, 0); 
$green  = imageColorAllocate($im, 0, 255, 0); 
$blue   = imageColorAllocate($im, 0, 0, 255); 
$black  = imageColorAllocate($im, 0, 0, 0); 

bigPixel(0,0,$grey) ;
imageString($im,1,4,0,'(0,0)',$grey);

$c = (eregi('^[0-9a-f]{6}$',$_REQUEST['c']))?hex2int($_REQUEST['c']):hex2int('000000');
$color = imageColorAllocate($im, $c['r'], $c['g'], $c['b']); 
$filled = ($_REQUEST['filled'] === 'filled')?TRUE:FALSE ;

if (is_array($_REQUEST['sts'])) {
	$instyle = array (); 
	foreach ($_REQUEST['sts'] as $pxl) {
		switch ($pxl) {
			case 'w':
				$instyle[] = $white ;
				break;
			case 'r':
				$instyle[] = $red ;
				break;
			case 'g':
				$instyle[] = $green ;
				break;
			case 'b':
				$instyle[] = $blue ;
				break;
			case 'l':
				$instyle[] = $lime ;
				break;
			case 'o':
				$instyle[] = $orange ;
				break;
			case 'p':
				$instyle[] = $purple ;
				break;
			case 'k':
				$instyle[] = $black ;
				break;
		}
	}
	imageSetstyle ($im, $instyle); 
	$color = IMG_COLOR_STYLED ;
}

switch ($_REQUEST['stylefile']) {
	case 'rbow':
		$stylefile = 'rbow.png' ;
		break;
	case 'reddot':
		$stylefile = 'reddot.png' ;
		break;
	case 'nyphp':
		$stylefile = 'nyphp.png' ;
		break;
	default:
		$stylefile = 'cbrd.png' ;
		break;
}

if ($_REQUEST['tile']) {

	$tile = imageCreateFromPNG($stylefile);
	imagesettile ($im, $tile) ;
	$color = IMG_COLOR_TILED ;
}

if ($_REQUEST['brush']) {
	$brush = imageCreateFromPNG($stylefile);
	imagesetbrush ($im, $brush) ;
	$color = IMG_COLOR_BRUSHED ;
}

if ($_REQUEST['iFun'] === 'imagePolygon') {
	if ($_REQUEST['pointlist']) {
		$points = explode(', ',$_REQUEST['pointlist']) ;
	} else {
		$points = array ( 13, 61, 60, 61, 75, 16, 90, 61, 137, 61, 99, 89, 113, 134, 75, 106, 37, 134, 51, 89 ) ;
	}
} else {
	$x =  (is_numeric($_REQUEST['x']))  ? max(min($_REQUEST['x'], $wd),0):round($wd/2);
	$y =  (is_numeric($_REQUEST['y']))  ? max(min($_REQUEST['y'], $ht),0):round($ht/2);
	$x1 = (is_numeric($_REQUEST['x1'])) ? max(min($_REQUEST['x1'],$wd),0):round($wd/6);
	$x2 = (is_numeric($_REQUEST['x2'])) ? max(min($_REQUEST['x2'],$wd),0):round(5*$wd/6);
	$y1 = (is_numeric($_REQUEST['y1'])) ? max(min($_REQUEST['y1'],$wd),0):round($ht/5);
	$y2 = (is_numeric($_REQUEST['y2'])) ? max(min($_REQUEST['y2'],$wd),0):round(4*$ht/5);
	$w =  (is_numeric($_REQUEST['w']))  ? max(min($_REQUEST['w'], $wd),0):round(9*$wd/10);
	$h =  (is_numeric($_REQUEST['h']))  ? max(min($_REQUEST['w'], $ht),0):round(4*$ht/5);
}

imageSetThickness($im,$_SESSION['thickness']);
switch ($_REQUEST['iFun']) {
	case 'imageSetThickness':
		imageLine($im,0,38,150,38,$color);
		break;
	case 'imageSetPixel':
		// bigPixel($x,$y,$color) ;
		imageSetPixel($im,$x,$y,$color);
		$tl = setTextLoc($x,$y) ;
		imageString($im,3,$tl['x'],$tl['y'],"($x,$y)",$cyan);
		break;
	case 'imageLine':
		bigPixel($x1,$y1,$cyan) ;
		bigPixel($x2,$y2,$cyan) ;
		$tl = setTextLoc($x1,$y1) ;
		imageString($im,3,$tl['x'],$tl['y'],"($x1,$y1)",$cyan);
		$tl = setTextLoc($x2,$y2) ;
		imageString($im,3,$tl['x'],$tl['y'],"($x2,$y2)",$cyan);
		imageLine($im,$x1,$y1,$x2,$y2,$color);
		break;
	case 'imageFillToBorder':
		$border = ($_REQUEST['border'] == 'purple')?$purple:$orange ;
		$border = ($_REQUEST['border'] == 'lime')?$lime:$border ;
		imageEllipse($im, 75,63,73,73,$lime);
		imageEllipse($im, 75,78,30,30,$lime);
		imageEllipse($im, 37,37,73,73,$orange);
		imageEllipse($im,111,37,73,73,$purple);
		if (isset($_REQUEST['border'])) {
			imageFillToBorder($im,$x,$y,$border,$color);
			bigPixel($x,$y,$cyan) ;
			$tl = setTextLoc($x,$y) ;
			imageString($im,3,$tl['x'],$tl['y'],"($x,$y)",$cyan);
		}
		break;
	case 'imageFill':
		$tl = setTextLoc($x,$y) ;
		imageLine($im,50,0,50,$ht,$orange);
		imageLine($im,100,0,100,$ht,$purple);
		if (isset($_REQUEST['c'])) {
			imageFill($im,$x,$y,$color);
			bigPixel($x,$y,$cyan) ;
			imageString($im,3,$tl['x'],$tl['y'],"($x,$y)",$cyan);
		}
		break;
	case 'imageRectangle':
		if ($filled) imageFilledRectangle($im,$x1,$y1,$x2,$y2,$color);
		bigPixel($x1,$y1,$cyan) ;
		bigPixel($x2,$y2,$cyan) ;
		$tl = setTextLoc($x1,$y1) ;
		imageString($im,3,$tl['x'],$tl['y']+6,"($x1,$y1)",$cyan);
		$tl = setTextLoc($x2,$y2) ;
		imageString($im,3,$tl['x']+10,$tl['y']+6,"($x2,$y2)",$cyan);
		imageRectangle($im,$x1,$y1,$x2,$y2,$color);
		break;
	case 'imageEllipse':
		if ($filled) imageFilledEllipse($im,$x,$y,$w,$h,$color);
		imageSetThickness($im,1);
		$woff = $x - round($w/2) ;
		$hoff = $y - round($h/2) ;
		imageLine($im, $woff+round(.15*$w), $hoff, $woff+round(.15*$w), $hoff+$h, $cyan);
		imageString($im,3,$woff+round(.15*$w)+3,max(min($hoff+$h-10,$ht-15),2),$h,$cyan);
		imageLine($im,$woff, $hoff+round(.15*$h), $woff+$w, $hoff+round(.15*$h), $cyan);
		imageString($im,3,$woff+$w-20,$hoff+round(.15*$h)-15,$w,$cyan);
		imageSetThickness($im,$_SESSION['thickness']);
		bigPixel($x,$y,$cyan) ;
		$tl = setTextLoc($x,$y) ;
		imageString($im,3,$tl['x'],$tl['y'],"($x,$y)",$cyan);
		imageEllipse($im,$x,$y,$w,$h,$color);
		break;
	case 'imageArc':
		imageSetThickness($im,1);
		$s =  (is_numeric($_REQUEST['s']))  ? max(min($_REQUEST['s'], 360),0):315;
		$e =  (is_numeric($_REQUEST['e']))  ? max(min($_REQUEST['e'], 360),0):45;	

		$arcstyle  = ($_REQUEST['arcstyle'])?$_REQUEST['arcstyle']:0 ;
		
		$style = array ($grey,$grey,$grey,$grey,$grey,$grey,$grey,$grey,$white,$white,$white,$white,$white,$white,$white,$white); 
		imageSetstyle ($im, $style); 
		imageArc($im,$x,$y,$w,$h,$e,$s,IMG_COLOR_STYLED) ;
		$style = array ($cyan,$cyan,$cyan,$cyan,$cyan,$white,$white,$white,$white,$white); 
		imageSetstyle ($im, $style); 
		imageFilledArc($im,$x,$y,$w*10,$h*10,$s,$s,IMG_COLOR_STYLED,IMG_ARC_CHORD) ;
		imageFilledArc($im,$x,$y,$w*10,$h*10,$e,$e,IMG_COLOR_STYLED,IMG_ARC_CHORD) ;
		
		$woff = $x - round($w/2) ;
		$hoff = $y - round($h/2) ;
		imageLine($im, $woff+round(.15*$w), $hoff, $woff+round(.15*$w), $hoff+$h, $cyan);
		imageString($im,3,$woff+round(.15*$w)+3,max(min($hoff+$h-10,$ht-15),2),$h,$cyan);
		imageLine($im,$woff, $hoff+round(.15*$h), $woff+$w, $hoff+round(.15*$h), $cyan);
		imageString($im,3,$woff+$w-20,$hoff+round(.15*$h)-15,$w,$cyan);
		imageSetThickness($im,$_SESSION['thickness']);	
		if (isset($instyle)) imageSetstyle ($im, $instyle); 	
		if ($filled) {
			imageFilledArc($im,$x,$y,$w,$h,$s,$e,$color,$arcstyle) ;
		} else {
			imageArc($im,$x,$y,$w,$h,$s,$e,$color) ;
		}
		bigPixel($x,$y,$cyan) ;
		$tl = setTextLoc($x,$y) ;
		imageString($im,3,$tl['x'],$tl['y'],"($x,$y)",$cyan);

		break;
	case 'imagePolygon':
		if ($filled) {
			imageFilledPolygon($im,$points,count($points)/2,$color);
		} else {
			imagePolygon($im,$points,count($points)/2,$color);
		}	
		for ($n=0,$count=count($points);$n<$count;$n += 2) {
			bigPixel($points[$n],$points[$n+1],$cyan) ;
			imageString($im,1,$points[$n]+2,$points[$n+1]-2,"({$points[$n]},{$points[$n+1]})",$cyan);
		}
		imagePolygon($im,$points,count($points)/2,$color);
		break;
}

header('Content-type: image/png');
imagePNG($im);
imageDestroy($im); 

if ($color === IMG_COLOR_TILED) imageDestroy($tile);
if ($color === IMG_COLOR_BRUSHED) imageDestroy($brush);


function bigPixel($x,$y,$color) {
	global $im;
	imageSetPixel($im,$x-1,$y+1,$color);
	imageSetPixel($im,$x-1,$y,$color);
	imageSetPixel($im,$x,$y-1,$color);
	imageSetPixel($im,$x-1,$y-1,$color);
	imageSetPixel($im,$x,$y,$color);
	imageSetPixel($im,$x+1,$y,$color);
	imageSetPixel($im,$x,$y+1,$color);
	imageSetPixel($im,$x+1,$y+1,$color);
	imageSetPixel($im,$x+1,$y-1,$color);
}

function setTextLoc($x,$y) {
	global $ht ;
	global $wd ;
	if ($x <= $wd - 60 ) { 
		$stl['x'] =  $x+5 ;
	} else {
		$stl['x'] = $x-65 ;
	}
	if ($y <= $ht - 10 ) { 
		$stl['y'] =  $y-5 ;
	} else {
		$stl['y'] = $y - 13 ;
	}
	return $stl ;
}

/**
 * @return array
 * @param $hex string
 * @desc Converts a 6 digit hexadecim  al number into an array of
 *       3 integer values (red, green, & blue)
 */
function hex2int($hex) {
        return array(
                'r' => hexdec(substr($hex, 0, 2)), // 1st pair of digits
                'g' => hexdec(substr($hex, 2, 2)), // 2nd pair
                'b' => hexdec(substr($hex, 4, 2)), // 3rd pair
        );
}


?>
