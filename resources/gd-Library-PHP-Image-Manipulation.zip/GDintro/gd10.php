<?PHP
$slide_title = 'The Draw Functions';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--
		function iSetPixel(data) {
			document.SetPixelImage.src = 'iDrawFuns.php?iFun=imageSetPixel&x=' + data.x.value + '&y=' + data.y.value + '&c=' + data.c.value  ;
		}

		function iLine(data) {
			document.LineImage.src = 'iDrawFuns.php?iFun=imageLine&x1=' + data.x1.value + '&y1=' + data.y1.value 
									+ '&x2=' + data.x2.value + '&y2=' + data.y2.value + '&c=' + data.c.value ;
		}
		
		function iFill(data) {
			document.FillImage.src = 'iDrawFuns.php?iFun=imageFill&x=' + data.x.value + '&y=' + data.y.value + '&c=' + data.c.value ;
		}

		function iFillToBorder(data) {
			document.Fill2BorderImage.src = 'iDrawFuns.php?iFun=imageFillToBorder&x=' + data.x.value + '&y=' + data.y.value + '&c=' + data.c.value + '&border=' + data.border.value ;
		}

		function iRectangle(data) {
			if (data.filled.checked) {
				filled = 1
			} else {
				filled = 0
			}
			document.RectangleImage.src = 'iDrawFuns.php?iFun=imageRectangle&x1=' + data.x1.value + '&y1=' + data.y1.value 
									+ '&x2=' + data.x2.value + '&y2=' + data.y2.value + '&c=' + data.c.value + '&filled=' + data.filled.value ;
		}

		function iPolygon(data) {
			if (data.filled.checked) {
				filled = 1
			} else {
				filled = 0
			}
			document.PolygonImage.src = 'iDrawFuns.php?iFun=imagePolygon&ht=175&c=' + data.c.value 
									+ '&pointlist=' + escape(data.points.value) + '&filled=' + data.filled.value ;
		}


		function iEllipse(data) {
			if (data.filled.checked) {
				filled = 1
			} else {
				filled = 0
			}
			document.EllipseImage.src = 'iDrawFuns.php?iFun=imageEllipse&ht=150&x=' + data.x.value + '&y=' + data.y.value 
									+ '&w=' + data.w.value + '&h=' + data.h.value + '&c=' + data.c.value + '&filled=' + data.filled.value ;
		}

		function iArc(data) {
			var sumstyles = 0 ;
			for (i = 0; i < data.arcstyle.options.length; i++) {
				if (data.arcstyle.options[i].selected) {
					sumstyles = sumstyles + parseInt(data.arcstyle.options[i].value) ;
				}
			}
			document.ArcImage.src = 'iDrawFuns.php?iFun=imageArc&ht=200&x=' + data.x.value + '&y=' + data.y.value 
					 + '&w=' + data.w.value + '&h=' + data.h.value  + '&s=' + data.s.value + '&e=' + data.e.value 
					 + '&c=' + data.c.value + '&filled=' + data.filled.value + '&arcstyle=' + sumstyles ;
		}
		
		-->
		</script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>In order to make a more interesting image you'll use the drawing functions to make lines and shapes. For all functions, the top left is 0,0.</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellspacing="5" cellpadding="0">
							<tr>
								<td class="phpnet" colspan="2"><a name="imageSetPixel"></a>int <?=phpFun('imageSetPixel')?>&nbsp;( resource image, int x, int y, int color)<br />
									Draws a pixel at<i> x</i>,<i> y</i> in image <i>image</i> of color <i>color</i>.</td>
							</tr>
							<tr>
								<td align="right" valign="top" width="150"><img src="iDrawFuns.php?iFun=imageSetPixel" alt="" name="SetPixelImage" height="100" width="150" border="0"></td>
								<td class="controller"  valign="middle" nowrap>
									<form method="post" name="setpixel">
										<select name="imageSetPixel" size="1">
											<option value="1">imageSetPixel</option>
										</select> ($im, <input type="text" name="x" value="$x" size="4" maxlength="3">,&nbsp;&nbsp;<input type="text" name="y" value="$y" size="4" maxlength="3">, <select name="c" size="1">
											<option value="FFFFFF">$white</option>
											<option value="FF0000">$red</option>
											<option value="00FF00">$green</option>
											<option value="0000FF">$blue</option>
											<option value="7FFF00">$lime</option>
											<option value="FF7F00">$orange</option>
											<option value="7F00FF">$purple</option>
											<option selected value="000000">$black</option>
										</select> ) ;
										<p><input onclick="iSetPixel(this.form);" type="button" name="isprd" value="redraw"></p>
									</form>
								</td>
							</tr>
							<tr>
								<td class="phpnet" colspan="2"><a name="imageLine"></a>int <?=phpFun('imageLine')?>&nbsp;( resource image, int x1, int y1, int x2, int y2, int color)<br />
									Draws a line from <i>x1</i>, <i>y1</i> to <i>x2</i>, <i>y2</i> in image <i>im</i> of color <i>color</i>.</td>
							</tr>
							<tr>
								<td align="right" valign="top" width="150"><img src="iDrawFuns.php?iFun=imageLine" alt="" name="LineImage" height="100" width="150" border="0"></td>
								<td class="controller"  valign="middle">
									<form method="post" name="line">
										<select name="imageLine" size="1">
											<option value="1">imageLine</option>
										</select> ($im, <input type="text" name="x1" value="$x1" size="4" maxlength="3">,&nbsp;<input type="text" name="y1" value="$y1" size="4" maxlength="3">,&nbsp;<input type="text" name="x2" value="$x2" size="4" maxlength="3">,&nbsp;<input type="text" name="y2" value="$y2" size="4" maxlength="3">,&nbsp; <select name="c" size="1">
											<option value="FFFFFF">$white</option>
											<option value="FF0000">$red</option>
											<option value="00FF00">$green</option>
											<option value="0000FF">$blue</option>
											<option value="7FFF00">$lime</option>
											<option value="FF7F00">$orange</option>
											<option value="7F00FF">$purple</option>
											<option selected value="000000">$black</option>
										</select> );
										<p><input onclick="iLine(this.form);" type="button" name="ilrd" value="redraw"></p>
									</form>
								</td>
							</tr>
							<tr>
								<td class="phpnet" colspan="2"><a name="imageRectangle"></a>int <?=phpFun('imageRectangle')?>&nbsp;( resource image, int x1, int y1, int x2, int y2, int col)<br />
									<a name="imageFilledRectangle"></a>
									int <?=phpFun('imageFilledRectangle')?>&nbsp;( resource image, int x1, int y1, int x2, int y2, int color)<br />
									Creates a rectangle of color <i>col</i> in image <i>image</i> starting at upper left coordinate <i>x1</i>, <i>y1</i> and ending at bottom right coordinate <i>x2</i>, <i>y2</i>.</td>
							</tr>
							<tr>
								<td align="right" valign="top" width="150"><img src="iDrawFuns.php?iFun=imageRectangle&ht=100" alt="" name="RectangleImage" height="100" width="150" border="0"></td>
								<td class="controller"  valign="middle" nowrap>
									<form method="post" name="rectangle">
										<select name="filled" size="1">
											<option value="0">imageRectangle</option>
											<option value="filled">imageFilledRectangle</option>
										</select> ($im <input type="text" name="x1" value="$x1" size="4" maxlength="3">&nbsp;&nbsp;<input type="text" name="y1" value="$y1" size="4" maxlength="3">, <input type="text" name="x2" value="$x2" size="4" maxlength="3">, <input type="text" name="y2" value="$y2" size="4" maxlength="3">, <select name="c" size="1">
											<option value="FFFFFF">$white</option>
											<option value="FF0000">$red</option>
											<option value="00FF00">$green</option>
											<option value="0000FF">$blue</option>
											<option value="7FFF00">$lime</option>
											<option value="FF7F00">$orange</option>
											<option value="7F00FF">$purple</option>
											<option selected value="000000">$black</option>
										</select> ) ;
										<p><input onclick="iRectangle(this.form);" type="button" name="irrd" value="redraw"></p>
									</form>
								</td>
							</tr>
							<tr>
								<td class="phpnet" colspan="2"><a name="imagePolygon"></a>int <?=phpFun('imagePolygon')?>&nbsp;( resource image, array points, int num_points, int color)<br />
									<a name="imageFilledPolygon"></a>
									int <?=phpFun('imageFilledPolygon')?>&nbsp;( resource image, array points, int num_points, int color)<br />
									Creates a polygon in image <i>image</i>. <i>points</i> is a PHP array containing the polygon's vertices, ie. points[0] = x0, points[1] = y0, points[2] = x1, points[3] = y1, etc. <i>num_points</i> is the total number of points (vertices).</td>
							</tr>
							<tr>
								<td align="right" valign="top" width="150"><img src="iDrawFuns.php?iFun=imagePolygon&ht=175" alt="" name="PolygonImage" height="175" width="150" border="0"></td>
								<td class="controller"  valign="middle" nowrap>
									<form method="post" name="pollygonform">
										$points = array ( <textarea name="points" rows="2" cols="44">13, 61, 60, 61, 75, 16, 90, 61, 137, 61, 99, 89, 113, 134, 75, 106, 37, 134, 51, 89</textarea> ) ;
										<p><select name="filled" size="1">
												<option value="0">imagePolygon</option>
												<option value="filled">imageFilledPolygon</option>
											</select> ($im, $points, (count($points)/2) , <select name="c" size="1">
												<option value="FFFFFF">$white</option>
												<option value="FF0000">$red</option>
												<option value="00FF00">$green</option>
												<option value="0000FF">$blue</option>
												<option value="7FFF00">$lime</option>
												<option value="FF7F00">$orange</option>
												<option value="7F00FF">$purple</option>
												<option selected value="000000">$black</option>
											</select> ) ;</p>
										<p><input onclick="iPolygon(this.form);" type="button" name="isprd" value="redraw"></p>
									</form>
								</td>
							</tr>
							<tr>
								<td class="phpnet" colspan="2"><a name="imageEllipse"></a>int <?=phpFun('imageEllipse')?>&nbsp;( resource image, int cx, int cy, int w, int h, int color)<br />
									<a name="imageFilledEllipse"></a>
									int <?=phpFun('imageFilledEllipse')?>&nbsp;( resource image, int cx, int cy, int w, int h, int color)<br />
									Draws an ellipse centered at <i>cx</i>, <i>cy</i> in the image represented by <i>image</i>. <i>W</i> and <i>h</i> specifies the ellipse's width and height respectively. The color of the ellipse is specified by <i>color</i>.</td>
							</tr>
							<tr>
								<td align="right" valign="top" width="150"><img src="iDrawFuns.php?iFun=imageEllipse&ht=150" alt="" name="EllipseImage" height="150" width="150" border="0"></td>
								<td class="controller"  valign="middle">
									<form method="post" name="ellipse">
										<select name="filled" size="1">
											<option value="0">imageEllipse</option>
											<option value="filled">imageFilledEllipse</option>
										</select> ($im, <input type="text" name="x" value="cx" size="4" maxlength="3">, <input type="text" name="y" value="cy" size="4" maxlength="3">, <input type="text" name="w" value="w" size="4" maxlength="3">, <input type="text" name="h" value="h" size="4" maxlength="3">, <select name="c" size="1">
											<option value="FFFFFF">$white</option>
											<option value="FF0000">$red</option>
											<option value="00FF00">$green</option>
											<option value="0000FF">$blue</option>
											<option value="7FFF00">$lime</option>
											<option value="FF7F00">$orange</option>
											<option value="7F00FF">$purple</option>
											<option selected value="000000">$black</option>
										</select> ) ;
										<p><input onclick="iEllipse(this.form);" type="button" name="ierd" value="redraw"></p>
									</form>
								</td>
							</tr>
							<tr>
								<td class="phpnet" colspan="2"><a name="imageArc"></a>int <?=phpFun('imageArc')?>&nbsp;( resource image, int cx, int cy, int w, int h, int s, int e, int color)<br />
									<a name="imageFilledArc"></a>
									int <?=phpFun('imageFilledArc')?>&nbsp;( resource image, int cx, int cy, int w, int h, int s, int e, int color, int style)<br />
									Draws a partial ellipse centered at <i>cx</i>, <i>cy</i> in the image represented by image. <i>W</i> and <i>h</i> specifies the ellipse's width and height respectively while the start and end points are specified in degrees indicated by the <i>s</i> and <i>e</i> arguments. 0&deg; is located at the three-o'clock position, and the arc is drawn counter-clockwise. <i>style</i> is a bitwise OR of the following possibilities: <b>IMG_ARC_CHORD</b> just connects the starting and ending angles with a straight line, while <b>IMG_ARC_PIE</b> produces a rounded edge. <b>IMG_ARC_NOFILL</b> indicates that the arc or chord should be outlined, not filled. <b>IMG_ARC_EDGED</b>, used together with <b>IMG_ARC_NOFILL</b>, indicates that the beginning and ending angles should be connected to the center - this is a good way to outline (rather than fill) a 'pie slice'.</td>
							</tr>
							<tr>
								<td align="right" valign="top" width="150"><img src="iDrawFuns.php?iFun=imageArc&ht=200" alt="" name="ArcImage" height="200" width="150" border="0"></td>
								<td class="controller"  valign="middle" nowrap>
									<form method="post" name="arcform">
										<select name="filled" size="1">
											<option value="0">imageArc</option>
											<option value="filled">imageFilledArc</option>
										</select> ($im, <input type="text" name="x" value="$cx" size="4" maxlength="3">, <input type="text" name="y" value="$cy" size="4" maxlength="3">, <input type="text" name="w" value="$w" size="4" maxlength="3">, <input type="text" name="h" value="$h" size="4" maxlength="3">, <input type="text" name="s" value="$s" size="4" maxlength="3">, <input type="text" name="e" value="$e" size="4" maxlength="3">, <select name="c" size="1">
											<option value="FFFFFF">$white</option>
											<option value="FF0000">$red</option>
											<option value="00FF00">$green</option>
											<option value="0000FF">$blue</option>
											<option value="7FFF00">$lime</option>
											<option value="FF7F00">$orange</option>
											<option value="7F00FF">$purple</option>
											<option selected value="000000">$black</option>
										</select>, <select name="arcstyle" size="4" multiple>
											<option selected value="0">IMG_ARC_PIE</option>
											<option value="1">IMG_ARC_CHORD</option>
											<option value="4">IMG_ARC_EDGED</option>
											<option value="2">IMG_ARC_NOFILL</option>
										</select> ) ;
										<p><input onclick="iArc(this.form);" type="button" name="iard" value="redraw"></p>
									</form>
								</td>
							</tr>
							<tr>
								<td class="phpnet" colspan="2"><a name="imageFill"></a>int <?=phpFun('imageFill')?>&nbsp;( resource image, int x, int y, int color)<br />
									Performs a flood fill starting at coordinate <i>x</i>, <i>y</i> with color <i>color</i> in the image <i>image</i>.</td>
							</tr>
							<tr>
								<td align="right" valign="top" width="150"><img src="iDrawFuns.php?iFun=imageFill" alt="" name="FillImage" height="100" width="150" border="0"></td>
								<td class="controller"  valign="middle">
									<form method="post" name="imfillForm">
										<select name="imageFill" size="1">
											<option value="imageFill">imageFill</option>
										</select> ($im, <input type="text" name="x" value="$x" size="4" maxlength="3">, <input type="text" name="y" value="$y" size="4" maxlength="3">,&nbsp;<select name="c" size="1">
											<option value="FFFFFF">$white</option>
											<option value="FF0000">$red</option>
											<option value="00FF00">$green</option>
											<option value="0000FF">$blue</option>
											<option value="7FFF00">$lime</option>
											<option value="FF7F00">$orange</option>
											<option value="7F00FF">$purple</option>
											<option selected value="000000">$black</option>
										</select> ) ;
										<p><input onclick="iFill(this.form);" type="button" name="ifrd" value="redraw"></p>
									</form>
								</td>
							</tr>
							<tr>
								<td class="phpnet" colspan="2"><a name="imageFillToBorder"></a>int <?=phpFun('imageFillToBorder')?>&nbsp;( resource image, int x, int y, int border, int color)<br />
									Performs a flood fill of color <i>color</i> to the border color defined by <i>border</i> starting at coordinate <i>x</i>, <i>y</i> with color <i>color</i>.</td>
							</tr>
							<tr>
								<td align="right" valign="top" width="150"><img src="iDrawFuns.php?iFun=imageFillToBorder" alt="" name="Fill2BorderImage" height="100" width="150" border="0"></td>
								<td class="controller"  valign="middle">
									<form method="post" name="fill2bForm">
										<div align="left">
											<select name="imageFillToBorder" size="1">
												<option value="1">imageFillToBorder</option>
											</select> ($im, <input type="text" name="x" value="$x" size="4" maxlength="3">, <input type="text" name="y" value="$y" size="4" maxlength="3">,&nbsp;<select name="border" size="1">
												<option value="orange">$orange</option>
												<option value="purple">$purple</option>
												<option value="lime">$lime</option>
											</select>,&nbsp;<select name="c" size="1">
												<option value="FFFFFF">$white</option>
												<option value="FF0000">$red</option>
												<option value="00FF00">$green</option>
												<option value="0000FF">$blue</option>
												<option value="7FFF00">$lime</option>
												<option value="FF7F00">$orange</option>
												<option value="7F00FF">$purple</option>
												<option selected value="000000">$black</option>
											</select> ) ;
											<p><input onclick="iFillToBorder(this.form);" type="button" name="if2brd" value="redraw"></p>
										</div>
									</form>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>