<?PHP
$slide_title = 'The Basics';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>
	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td class="heading">Let's Get to Some PHP Already!</td>
				</tr>
				<tr>
					<td>Image creation in PHP is handled in 5 basic steps:
						<ol>
							<li type="1">Create a blank image of a specified size in memory.
							<li type="1">Add content to the blank image.
							<li type="1">Send the headers.
							<li type="1">Output the image in the chosen file format.
							<li type="1">Delete the image from memory.	
						</ol>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="heading">1. Create the Image:</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageCreate"></a>resource <?=phpfun('imageCreate')?>&nbsp;( int x_size, int y_size)<br />
						<a name="imageCreateTrueColor"></a>
						resource <?=phpfun('imageCreateTrueColor')?>&nbsp;( int x_size, int y_size)<br />
						
						Returns an image identifier representing a blank image of size <i>x_size</i> by <i>y_size</i>.
						</td>
				</tr>
				<tr>
					<td>Image creation is done with one of two functions <?=phpfun( 'imageCreate()')?>&nbsp;and <?=phpfun( 'imageCreateTrueColor()')?>. 
					The latter creates a true color image and the former creates an index color image. Both functions return an integer image identifier and require 2 parameters representing the width and height of the image in pixels. The PHP online manual recommends the use of <?=phpfun( 'imageCreateTrueColor()')?>, but if you understand its limitations, <?=phpfun( 'imageCreate()')?>&nbsp;can often be a more appropriate choice.</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="heading">2. Add content:</td>
				</tr>
				<tr>
					<td>Once you have a blank image in memory, there are many copy, transform, draw, and text/font functions to create your masterpiece. These will be covered later in the presentation.</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="heading">3. Send the Headers:</td>
				</tr>
				<tr>
					<td class="phpnet">int <?=phpfun('header')?>&nbsp;( string string [, bool replace [, int http_response_code]])<br />
						Used to send raw HTTP headers. See the <a href="http://www.w3.org/Protocols/rfc2616/rfc2616" target="_blank">HTTP/1.1 specification</a> for more   information. </td>
				</tr>
				<tr>
					<td>Since you're going to be sending image data to the browser instead of HTML, you need to use the header function to send the appropriate content type: image/png, image/jpeg, etc.</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="heading">4. Output the Image</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imagePNG"></a>int <?=phpfun('imagePNG')?>&nbsp;( resource image [, string filename])<br />
						Outputs a GD image stream ( <i>image</i> ) in PNG format to standard output (usually the browser) or, if a filename is given by the filename it outputs the image to the file.
						<hr>
						<p><a name="imageJPEG"></a>int <?=phpfun('imageJPEG')?>&nbsp;( resource image [, string filename [, int quality]])<br />
							Creates the JPEG file in filename from the <i>image</i> image. The <i>filename</i> argument is optional, and if left off, the raw image stream will be output directly. <i>quality</i> is optional, and ranges from 0 (worst quality, smaller file) to 100 (best quality, biggest file). The default is the default IJG quality value (about 75). </p>
						<hr>
						<p><a name="imageWBMP"></a>int <?=phpfun('imageWBMP')?>&nbsp;( resource image [, string filename [, int foreground]])<br />
							<a name="imageGIF"></a>
							int <?=phpfun('imageGIF')?>&nbsp;( resource image [, string filename])<br />
							<a name="imageGD"></a>
							int <?=phpfun('imageGD')?>&nbsp;( resource image [, string filename])<br />
							<a name="imageGD2"></a>
							int <?=phpfun('imageGD2')?>&nbsp;( resource image [, string filename [, int chunk_size [, int type]]])<br />
						</p>
					</td>
				</tr>
				<tr>
					<td>In PHP you manipulate images within memory in GD's native format. The functions listed above are for outputting your image in whatever format you need to use. Like true color vs. indexed, what format you choose will depend upon the particular situation. In general JPEGs are good for true color, photographic images and PNGs are good for indexed color graphics. WBMP, the Wireless Bitmap format, is used for two-color images for WML pages. GIF is similar to PNG, but inferior in every way and has patent trouble, so is best avoided. The GD &amp; GD2 formats are, according to the <a href="http://www.boutell.com/gd/manual2.0.15.html#gdformat" target="_blank">GD FAQ page</a> &quot;<i>not</i> intended for general purpose use and should never be used to distribute images. It is not a compressed format. Its purpose is solely to allow very fast loading of images your program needs often in order to build other images for output.&quot;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="heading">5. Delete the Image</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageDestroy"></a>int <?=phpfun('imageDestroy')?>&nbsp;( resource image)<br />
						Frees any memory associated with image <i>image</i>. <i>image</i> is the image identifier returned by the <?=phpfun('imageCreate()')?>&nbsp;function.</td>
				</tr>
				<tr>
					<td>Whether you output the image to a browser, save it to a file, or just give up it will remain in the server's memory until it is destroyed. If you continue to build images without destroying them, the server will crash. Never create an image without destroying it by the end of your script.</td>
				</tr>
			</table>
			<? navtable(''); ?>
		</div>
	</body>
</html>
