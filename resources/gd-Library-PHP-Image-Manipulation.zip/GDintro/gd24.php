<?PHP
$slide_title = 'Fonts: TrueType';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>Unlike bitmap fonts that are basically collections of pixel-based images of each character drawn one specific size, vector (or outline) fonts describe each character mathematically as points and lines, and a single font file is used to generate text at any size.					<p>Vector fonts come in a potentially confusing array of types, but the PHP image functions (if you have the appropriate libraries) use the two most common: <a href="http://www.truetype.demon.co.uk/" target="_blank">TrueType</a> and <a href="http://partners.adobe.com/asn/tech/type/ftypes.jsp" target="_blank">PostScript</a> (Type1). <a href="http://www.truetype.demon.co.uk/" target="_blank">TrueType</a> fonts require the <a href="http://freetype.sourceforge.net/" target="_blank">FreeType</a> libraries, and <a href="http://partners.adobe.com/asn/tech/type/ftypes.jsp" target="_blank">PostScript</a> fonts require the currently orphaned T1Lib library. You can find an excellent guide to getting these libraries compiled and working with PHP &amp; GD (including the version bundled in 4.3) in a *NIX environment <a href="http://www.onlamp.com/pub/a/php/2003/03/27/php_gd.html" target="_blank">here</a>.</p>
						<p>In addition to the required libraries, you'll also need the actual font files. PostScript fonts are most often require licensing, you can find some free fonts online and included with X. There are many more free TrueType fonts available, and while they are of generally lower quality, for most graphic purposes are fine.</p>
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr>
					<td class="heading">TrueType</td>
				</tr>
				<tr>
					<td>In order to convert a string of characters using a <a href="http://www.truetype.demon.co.uk/" target="_blank">TrueType</a> font into a pixelated image (a process called rendering), the gd library requires either (or both) the <a href="http://freetype.sourceforge.net/freetype1/index.html" target="_blank">FreeType</a> or <a href="http://freetype.sourceforge.net/freetype1/index.html" target="_blank">FreeType&nbsp;2</a> open source font rendering libraries. <a href="http://freetype.sourceforge.net/freetype1/index.html" target="_blank">FreeType</a> uses a patented optimization algorithm that requires a royalty fee to be paid or must be disabled (resulting in lower quality images). The more recent <a href="http://freetype.sourceforge.net/freetype1/index.html" target="_blank">FreeType&nbsp;2</a> doesn't suffer from this limitation.

						<p>The easiest way to tell if one or both of the libraries are installed on your machine is to check for the freetype.h file:<br />
						</p>
						<div class="source">
							# locate freetype.h<br />
							/usr/include/freetype1/freetype/freetype.h<br />
							/usr/include/freetype2/freetype/freetype.h<br />
						</div>
					</td>
				</tr>
				<tr>
					<td><b>Rendering with FreeType</b></td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageTTFText"></a>array <?=phpfun('imageTTFText')?>&nbsp; ( resource image, int size, int angle, int x, int y, int color, string fontfile, string text)<br />
						Draws the string text in the image identified by <i>image</i>, starting at coordinates <i>x</i>, <i>y</i> (top left is 0, 0), at an angle of <i>angle</i> in color <i>color</i>, using the TrueType font file identified by <i>fontfile</i>. Depending on which version of the GD library that PHP is using, when fontfile does not begin with a leading '/', '.ttf' will be appended to the filename and the library will attempt to search for that filename along a library-defined font path.<br />
						The coordinates given by <i>x</i>, <i>y</i> will define the basepoint of the first character (roughly the lower-left corner of the character).<br />
						<i>angle</i> is in degrees, with 0 degrees being left-to-right reading text (3 o'clock direction), and higher values representing a counter-clockwise rotation. (i.e., a value of 90 would result in bottom-to-top reading text).<br />
						<i>fontfile</i> is the path to the TrueType font you wish to use.<br />
						<i>text</i> is the text string which may include UTF-8 character sequences (of the form: &amp;#123;) to access characters in a font beyond the first 255.<br />
						<i>color</i> is the color index. Using the negative of a color index has the effect of turning off antialiasing.<br />
						Returns an array with 8 elements representing four points making the bounding box of the text. The order of the points is lower left, lower right, upper right, upper left. The points are relative to the text regardless of the angle, so &quot;upper left&quot; means in the top left-hand corner when you see the text horizontallty.
						<p><a name="imageTTFBBox"></a>array <?=phpfun('imageTTFBBox')?>&nbsp; ( int size, int angle, string fontfile, string text)<br />
							Uses a subset of the parameters for <?=phpfun('imageTTFText()')?>, and does nothing but returns the same bounding box array that would be returned by <?=phpfun('imageTTFText()')?>.</p>
					</td>
				</tr>
				<tr>
					<td><b>Rendering with FreeType&nbsp;2</b></td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageFTText"></a>array <?=phpfun('imageFTText')?>&nbsp; ( resource image, int size, int angle, int x, int y, int col, string font_file, string text, array extrainfo )<br />
						Write text to the image using fonts using FreeType 2.

						<p><a name="imageFTBBox"></a>array <?=phpfun('imageFTBBox')?>&nbsp; ( int size, int angle, string font_file, string text, array extrainfo)<br />
							
						Give the bounding box of a text using fonts via freetype2</p>
					</td>
				</tr>
				<tr>
					<td><b>Note</b>: the online manual indicates that the <i>extrainfo</i> paramter is optional, but this is not the case. If you don't have any <i>extrainfo</i> to pass to this (as yet undocumented) function, simply use array() instead to pass a blank parameter. 
						<p>&nbsp;</p>
					</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>
