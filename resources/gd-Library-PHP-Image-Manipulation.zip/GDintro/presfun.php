<?PHP
// checkout basename();



error_reporting(E_ALL ^ E_NOTICE);



$page = substr(end(explode('/',getenv('REQUEST_URI'))),0,-4);
$nam = preg_replace ('/[0-9]*/','',$page);
$num = preg_replace ('/^[a-z]*/','',$page);

function navtable($title) {
	if (!$title) echo '<p>&nbsp;</p>';
	echo '<table width="100%" border="0" cellspacing="2" cellpadding="2"><tr>';
	echo '<td class="navlink" align="left"  valign="top">'.pageLink('LAST',-1).'</td>';
	if ($title) {
		echo '<td class="title" align="center" valign="top">'.$title.'</td>';
	} else {
		echo '<td class="navlink" align="center" valign="top"><a href="gd1.php">Table of Contents</a></td>';
		echo '<td class="navlink" align="center" valign="top"><a href="gd0.php">Function Index</a></td>';
	}
	echo '<td class="navlink" align="right" valign="top">'.pageLink('NEXT',1).'</td>';
	echo '</tr></table>';
	if ($title) echo '<p>&nbsp;</p>';
}

function pageLink($label,$offset) {
	global $nam, $num;
	$destination = $nam . ($num + $offset) . '.php' ;
	if (file_exists($destination)) {
		return "<a href='$destination'>$label</a>";
	} else {
		return $label;
	}
}

function phpfun($fun) {
	echo "<dfn><a title='$fun' href='http://us".rand(2,4).".php.net/$fun' target='_blank'>$fun</a></dfn>";
}

function randomHTMLcolor() {
	$color['r'] = rand(0,255) ;
	$color['g'] = rand(0,255) ;
	$color['b'] = rand(0,255) ;
	$color['hex'] = sprintf("%02X%02X%02X",$color['r'],$color['g'],$color['b']); 
	$color['bin'] = sprintf('%08d%08d%08d',decbin($color['r']),decbin($color['g']),decbin($color['b'])) ;	
	return $color ;
}


function reference($title) {
	global $nam;

	require('tocfile.inc');

	return "<span class='ref'><a href='$nam{$toc[$title]}.php' class='ref'>Chapter {$toc[$title]}: $title</a></span>";
}

