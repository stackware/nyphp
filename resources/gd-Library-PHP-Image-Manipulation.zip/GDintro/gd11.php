<?PHP
$slide_title = 'Clock Example';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script language="JavaScript">
			function popClock() {
				var popWindow = window.open("clock1.php","clock1.php","titlebar=0,menubar=0,height=125,width=124,scrollbars=no")
				popWindow.focus()
				}
		</script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td class="heading">Drawing a Clock</td>
				</tr>
				<tr>
					<td><a href="javascript:popClock();"><img src='clock1.php' height="101" width="101" align="right" border="0" hspace="5"></a>An example of the type of image that you might want to generate dynamically is a clock. If the image at right were not generated dynamically, this page would require 43,200 different versions of the image to show any and all times.<br />
						<br />
						The steps to create the image are fairly simple. First, we set the image's background color to white with <?=phpfun('imageColorAllocate()')?> and save that color's resource id in a variable for later use. The first time we call <?=phpfun('imageColorAllocate()')?>, the background color of the image will be set to the defined color (only with <?=phpfun('imageCreate()')?>, not <?=phpfun('imageCreateTrueColor()')?>). Subsequent calls to <?=phpfun('imageColorAllocate()')?> will only define a color within the color index, but not add it anywhere within the image itself. Next we'll need to define the brown and the black colors to be used in the image. With the colors defined, using <?=phpfun('imageFilledEllipse()')?> we'll draw three progressively smaller ellipses: black, brown and then white that will define the face.<br />
						<br />
						We could use <?=phpfun('imageFilledRectangle()')?> in conjunction with some trigonometry to draw the hands, but it is easier to let the math take care of itself with <?=phpfun('imageFilledArc()')?>. For that to work all we need to know is the angle, which is found by converting the time (0-11 hours, 0-59 minutes &amp; 0-59 seconds) to degrees and shifting 90 degrees because for some godawful reason, GD uses 3 o'clock as its 0.</td>
				</tr>
				<tr>
					<td class="source"><? show_source('clock1.php')?></td>
				</tr>
			</table>
			<? navtable(''); ?>
		</div>
	</body>

</html>
