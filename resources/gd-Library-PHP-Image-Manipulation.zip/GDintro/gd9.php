<?PHP
$slide_title = 'A Simple Example';
require ('presfun.php');

$spc['r'] = rand(0,255) ;
$spc['g'] = rand(0,255) ;
$spc['b'] = rand(0,255) ;
$spc['hex'] = sprintf("%02X%02X%02X",$spc['r'],$spc['g'],$spc['b']); 
$spc['bin'] = sprintf('%08d%08d%08d',decbin($spc['r']),decbin($spc['g']),decbin($spc['b'])) ;	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td class="heading">simplepng.php</td>
				</tr>
				<tr>
					<td>As a first example, consider the PHP file used in the previous True Color/Index Color examples and below. The file is called with a single parameter: the six digit hexadecimal representation of an RGB color, and returns a 50 x 50 pixel PNG set to that color.</td>
				</tr>
				<tr>
					<td>
						<div align="center">
							<table border="0" cellspacing="2" cellpadding="2">
								<tr>
									<td><img src="simplepng.php?color=<?=$spc['hex']?>" alt="" height="50" width="50" border="0"></td>
									<td>&lt;img src=&quot;simplepng.php?color=<?=$spc['hex']?>&quot;&gt;</td>
								</tr>
							</table>
						</div>
					</td>
				</tr>
				<tr>
					<td></td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageColorAllocate"></a>int <?=phpfun('imageColorAllocate')?>&nbsp;( resource image, int red, int green, int blue)<br />
						Returns a color identifier representing the color composed of the given RGB components. The <i>im</i> argument is the return from the <?=phpfun('imageCreate()')?>&nbsp;function. <i>red</i>, <i>green</i> and <i>blue</i> are the values of the red, green and blue component of the requested color respectively. These parameters are integers between 0 and 255 or hexadecimals between 0x00 and 0xFF. <?=phpfun('imageColorAllocate()')?>&nbsp;must be called to create each color that is to be used in the image represented by <i>image</i>. 
						<p>In the event that all 256 colors have already been allocated, <?=phpfun('imageColorAllocate()')?>&nbsp;will return -1 to indicate failure.</p>
					</td>
				</tr>
				<tr>
					<td></td>
				</tr>
				<tr>
					<td class="source"><? show_source('simplepng.php')?></td>
				</tr>
				<tr>
					<td></td>
				</tr>
				<tr>
					<td>It is a good practice to keep steps 3, 4, and 5 together. If you don't wait until the last possible moment to send the headers, any errors thrown by the code will be interpreted as binary gobbeldygook and you won't see them. It also helps to maintain the important habbit of destorying images by doing it immediately after you output or save them.</td>
				</tr>
			</table>
			<? navtable(''); ?>
		</div>
	</body>

</html>