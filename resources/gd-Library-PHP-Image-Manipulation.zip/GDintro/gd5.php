<?PHP
$slide_title = 'Color Theory';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--
		var RGB = new Array(256);
		var k = 0;
		var hex = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F");
		
		for (i = 0; i < 16; i++) {	
			for (j = 0; j < 16; j++) {		
				RGB[k] = hex[i] + hex[j];
				k++;
			}
		}
		function updatergb(data) {
			if (data.hex.value) {
				data.red.value   = HexToR(data.hex.value) ;
				data.green.value = HexToG(data.hex.value) ;
				data.blue.value  = HexToB(data.hex.value) ;
				document.rgbex.src = '/rgb.php?hex=' + data.hex.value ;
			} else {
				document.rgbex.src = '/rgb.php?red=' + min(data.red.value,255)  
								+ '&green=' + min(data.green.value,255) 
								+  '&blue=' + min(data.blue.value,255) ;
				data.hex.value = RGB[data.red.value] + RGB[data.green.value] + RGB[data.blue.value]
			}
		}
			
		function clearHex() { document.rgber.hex.value = "" }
			
		function min(x, y) {
			if (x < y)
				return x; 
			else
				return y;
		}
		function HexToR(h) { return parseInt((cutHex(h)).substring(0,2),16) }
		function HexToG(h) { return parseInt((cutHex(h)).substring(2,4),16) }
		function HexToB(h) { return parseInt((cutHex(h)).substring(4,6),16) }
		function cutHex(h) { return (h.charAt(0)==" #") ? h.substring(1,7) : h} 

     var htmlwin;
     var colhwin;
     var coldwin;
     function popup(win,name,url)
     {
          win=window.open(url,name,'resizable=1');
          win.creator=self;
          win.focus();
     }
	-->
		</script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td class="heading">Some Definitions</td>
				</tr>
				<tr>
					<td><br />
						<span class="def">Color Model</span>: A method for producing a new color by mixing a small set of standard primary colors.</td>
				</tr>
				<tr>
					<td><br />
						<span class="def">Channels</span>: another term for the primary colors used in a color model, e.g. Red, Green and Blue in RGB. Interchangeable with the term component.</td>
				</tr>
				<tr>
					<td><br />
						<span class="def">RGB</span>: The file formats manipulated by the GD library all use the RGB color model, which is an abstract representation of the way television and computer monitors work. In the physical world, adjacent phosphor dots of red, green and blue are stimulated to varying degrees to produce a wide range of color. In the mathematical model, three channels of red, green and blue grids of pixels are given values from zero to 100% that correspond to the levels of red, green and blue light.</td>
				</tr>
				<tr>
					<td><br />
						<span class="def">Bit-depth</span>: the number of steps between zero and 100% in a color model determined by the number of bits used to store the information. The most common and familiar system uses 8 bits to store the value of each channel, thus giving 256 possible values (from 0-255) for each pixel (just for #!@$s and giggles, these values are often still referred to by their hexadecimal values of 0-FF). In an 8-bit RGB color model, it takes 3 channels of 8 bits each to represent any color in the model, hence the familiar six digit <a title="Hex Color Popup" href="javascript:popup(colhwin,'ColorHex_Popup','colhpop.htm')">hexadecimal color codes</a> from HTML.</td>
				</tr>
			</table>
			<p><? navtable(''); ?></p>
		</div>
	</body>

</html>