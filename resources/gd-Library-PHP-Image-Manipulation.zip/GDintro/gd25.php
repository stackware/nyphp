<?PHP
$slide_title = 'Fonts: PostScript';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td class="heading">PostScript </td>
				</tr>
				<tr>
					<td>The PostScript font functions made available by the T1Lib library provide a much higher degree of control than the TrueType functions. Note the ability to control inter-character spacing (<i>tightness</i>), multiple levels of antialiasing, as well as slant (italicize) and extend (embold) fonts. Note also that, like <?=phpfun('imageDestroy()')?>, you have to clean up after yourself with <?=phpfun('imagePSFreeFont()')?>.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imagePSLoadFont"></a>int <?=phpfun('imagePSLoadFont')?>&nbsp; ( string filename )<br>
						If everything went right, a valid font index will be returned and can be used for further purposes. Otherwise, the function returns FALSE and prints a message describing what went wrong.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imagePSText"></a>array <?=phpfun('imagePSText')?>&nbsp; ( resource image, string text, int font, int size, int foreground, int background, int x, int y [, int space [, int tightness [, float angle [, int antialias_steps]]]])<br>
						<i>foreground</i> is the color in which the text will be painted. <i>background</i> is the color to which the text will try to fade in with antialiasing. No pixels with the color background are actually painted, so the background image does not need to be of solid color.<br>
						The coordinates given by <i>x</i>, <i>y</i> will define the origin (or reference point) of the first character (roughly the lower-left corner of the character). This is different from the <?=phpfun('imageString()')?>, where <i>x</i>, <i>y</i> define the upper-right corner of the first character.<br>
						<i>space</i> allows you to change the default value of a space in a font. This amount is added to the normal value and can also be negative.<br>
						<i>tightness</i> allows you to control the amount of white space between characters. This amount is added to the normal character width and can also be negative.<br>
						<i>angle</i> is in degrees.<br>
						<i>size</i> is expressed in pixels.<br>
						<i>antialias_steps</i> allows you to control the number of colours used for antialiasing text. Allowed values are 4 and 16. The higher value is recommended for text sizes lower than 20, where the effect in text quality is quite visible. With bigger sizes, use 4 as it's less computationally intensive.<br>
						Parameters <i>space</i> and <i>tightness</i> are expressed in character space units, where 1 unit is 1/1000th of an em-square.<br>
						This function returns an array containing the following elements: (0 =&gt; lower left x-coordinate, 1 =&gt; lower left y-coordinate, 2 =&gt; upper right x-coordinate, 3 =&gt; upper right y-coordinate ).
						<p><a name="imagePSBBox"></a>array <?=phpfun('imagePSBBox')?>&nbsp; ( string text, int Font, int size [, int space [, int tightness [, float angle]]])<br>
							Uses a subset of the parameters for <?=phpfun('imagePSText()')?>, and does nothing but returns the same bounding box array that would be returned by <?=phpfun('imagePSText()')?>.</p>
					</td>
				</tr>
				<tr>
					<td>
						<p><b>TIP</b>: The paramter <i>text</i> <u>must</u> be a string. In the example below, PHP will quit with an error if $text is undefined:</p>
						<p class="source">
							<?php highlight_string ('<'.'?php imagePSText ($im, $text, $font, $textsize, $black, $white, 10, 10); ?'.'>'); ?></p>
						<p>To easily avoid this situation, simply enclose the $text variable in quotes:</p>
						<p class="source">
							<?php highlight_string ('<'.'?php imagePSText ($im, "$text", $font, $textsize, $black, $white, 10, 10); ?'.'>'); ?></p>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imagePSFreeFont"></a>void <?=phpfun('imagePSFreeFont')?>&nbsp; ( int fontindex )<br>
						
						Frees memory used by a PostScript Type 1 font.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imagePSExtendFont"></a>bool <?=phpfun('imagePSExtendFont')?>&nbsp; ( int font_index, float extend)<br>
						
						Extend or condense a font (<i>font_index</i>), if the value of the <i>extend</i> parameter is less than one you will be condensing the font.
						<p><a name="imagePSSlantFont"></a>bool <?=phpfun('imagePSSlantFont')?>&nbsp; ( int font_index, float slant )<br>
							
						
						Slant a font given by the <i>font_index</i> parameter with a slant of the value of the <i>slant</i> parameter.</p>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imagePSEncodeFont"></a>int <?=phpfun('imagePSEncodeFont')?>&nbsp; ( int font_index, string encodingfile )<br>
						Loads a character encoding vector from from a file (*.enc) and changes the fonts encoding vector to it. As a PostScript fonts default vector lacks most of the character positions above 127, you'll definitely want to change this if you use an other language than english.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imagePSCopyFont"></a>int <?=phpfun('imagePSCopyFont')?>&nbsp; ( int fontindex )<br>Use this function if you need make further modifications to the font, for example extending/condensing, slanting it or changing it's character encoding vector, but need to keep the original as well. Note that the font you want to copy must be one obtained using <?=phpfun('imagePSLoadFont()')?>, not a font that is itself a copied one. You can make modifications to it before copying.<br>
						If you use this function, you must free the fonts obtained this way yourself and in reverse order. Otherwise your script will hang.<br>If everything went right, a valid font index will be returned and can be used for further purposes. Otherwise the function returns FALSE and prints a message describing what went wrong.</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>