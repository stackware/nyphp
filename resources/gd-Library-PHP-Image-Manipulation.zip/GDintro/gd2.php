<?PHP
$slide_title = 'RTFM &amp; YMMV';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<? navtable($slide_title); ?>
		<div align='center'>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>The <a href="http://www.php.net/manual/en/ref.image.php" target="_blank">PHP Image functions</a> read, manipulate, and output image streams by accessing functions provided by the external GD library (<a href="http://www.boutell.com/gd/" target="_blank">http://www.boutell.com/gd/</a>), which in turn, requires a variety of other libraries to support a number of image formats &amp; font systems.
						<p>Since PHP 4.3 the GD library is bundled and installed by default.</p>
						<p>
						In previous versions, to enable GD-support configure PHP <code>--with-gd[=DIR]</code>, where DIR is the GD base install directory. To use the recommended bundled version of the GD library (which was first bundled in PHP 4.3.0), use the configure option <code>--with-gd</code>. In Windows, you'll include the GD2 DLL PHP_gd2.dll as an extension in PHP.ini.
</p>
						<p>You can find a good, detailed guide to compiling and enabling GD in PHP by <a href="http://www.onlamp.com/pub/au/1152" target="_blank">Marco Tabini</a> in the <a href="http://www.onlamp.com/pub/a/php/2003/03/27/php_gd.html" target="_blank">OnLamp.com PHP DevCenter</a>.</p>
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="gd_info"></a>array <?=phpfun('gd_info')?>&nbsp; ( void ) <br />
						Returns an associative array describing the version and capabilities of the installed GD library. </td>
				</tr>
				<tr>
					<td class="source"><? highlight_string('<?PHP print_r(gd_info()); '.'?'.'>');?><p>
					<pre><? print_r(gd_info()); ?></pre></td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageTypes"></a>int <?=phpfun('imageTypes')?>&nbsp; ( void )<br />
						Returns a bit-field corresponding to the image formats supported by the version of GD linked into PHP. The following bits are returned:<br />
						<b>IMG_GIF | IMG_JPG | IMG_PNG | IMG_WBMP</b>.</td>
				</tr>
				<tr>
					<td class="source"><? show_source('imagetypes.php')?><p>
						<?php require('imagetypes.php') ;?>
					</td>
				</tr>
			</table>
			<p><? navtable(''); ?></p>
		</div>
	</body>

</html>
