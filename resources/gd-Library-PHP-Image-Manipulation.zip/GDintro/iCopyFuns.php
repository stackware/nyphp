<?PHP


error_reporting(E_ALL ^ E_NOTICE);

/*
iCopyFuns.php
*/

$src_f = (isset($_REQUEST['src'])) ? $_REQUEST['src']:'blackbox.png';
$dst_f = (isset($_REQUEST['dst'])) ? $_REQUEST['dst']:'blackbox.png';
$dst_x = (is_numeric($_REQUEST['dst_x'])) ? max(min($_REQUEST['dst_x'],100),0):0;
$dst_y = (is_numeric($_REQUEST['dst_y'])) ? max(min($_REQUEST['dst_y'],100),0):0;
$src_x = (is_numeric($_REQUEST['src_x'])) ? max(min($_REQUEST['src_x'],100),0):0;
$src_y = (is_numeric($_REQUEST['src_y'])) ? max(min($_REQUEST['src_y'],100),0):0;
$dst_w = (is_numeric($_REQUEST['dst_w'])) ? max(min($_REQUEST['dst_w'],100),0):100;
$dst_h = (is_numeric($_REQUEST['dst_h'])) ? max(min($_REQUEST['dst_h'],100),0):100;
$src_w = (is_numeric($_REQUEST['src_w'])) ? max(min($_REQUEST['src_w'],100),0):100;
$src_h = (is_numeric($_REQUEST['src_h'])) ? max(min($_REQUEST['src_h'],100),0):100;
$pct = (is_numeric($_REQUEST['pct'])) ? max(min($_REQUEST['pct'],100),0):100;

$src = imageCreateFromFile($src_f) ;
$dst = imageCreateFromFile($dst_f) ;

$format = 'JPEG';

switch ((isset($_REQUEST['fun'])) ? $_REQUEST['fun']:'imageCopy') {
	case 'imageCopyMerge':
		imageCopyMerge ( $dst, $src, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $pct ) ;
		break;
	case 'imageCopyMergeGray':
		imageCopyMergeGray ( $dst, $src, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $pct ) ;
		break;
	case 'imageCopyResampled':
		imageCopyResampled ( $dst, $src, $dst_x, $dst_y, $src_x, $src_y, $dst_w, $dst_h, $src_w, $src_h ) ;
		break;
	case 'imageCopyResized':
		imageCopyResized ( $dst, $src, $dst_x, $dst_y, $src_x, $src_y, $dst_w, $dst_h, $src_w, $src_h ) ;
		break;
	case 'imageColorMatch':
		if (function_exists('imageColorMatch')) {
			imageColorMatch ( $dst, $src ) ;
		} else {
			$dst = imageCreateFromPNG('unsup.png') ;
			$format = 'PNG';
		}
		break;
	case 'imagePaletteCopy':
		imagePaletteCopy ( $dst, $src ) ;
		$format = 'PNG';
		break;
	case 'imageRotate':
		if (function_exists('imageRotate')) {
			$angle = (is_numeric($_REQUEST['a'])) ? $_REQUEST['a']:45;
			$c = (eregi('^[0-9a-f]{6}$',$_REQUEST['c']))?hex2int($_REQUEST['c']):hex2int('FF0000');
			$bgd_color = imageColorAllocate($src, $c['r'], $c['g'], $c['b']); 
			$dst = imageRotate( $src, $angle, $bgd_color ) ;
		} else {
			$dst = imageCreateFromPNG('unsup.png') ;
			$format = 'PNG';
		}
		break;
	default:
		imageCopy ( $dst, $src, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h ) ;
		break;
}

switch ($format) {
	case 'JPEG':
		header('Content-type: image/jpeg');
		imageJPEG($dst);
		break;
	case 'PNG':
		header('Content-type: image/png');
		imagePNG($dst);
		break;
}

imageDestroy($dst);
imageDestroy($src);

function imageCreateFromFile($in_file) {
	switch (substr($in_file,-3)) {
		case 'jpg':
			return imageCreateFromJPEG($in_file) ;
			break;
		case 'png':
			return imageCreateFromPNG($in_file) ;
			break;
	}
}

/**
 * @return array
 * @param $hex string
 * @desc Converts a 6 digit hexadecim  al number into an array of
 *       3 integer values (red, green, & blue)
 */
function hex2int($hex) {
        return array(
                'r' => hexdec(substr($hex, 0, 2)), // 1st pair of digits
                'g' => hexdec(substr($hex, 2, 2)), // 2nd pair
                'b' => hexdec(substr($hex, 4, 2)), // 3rd pair
        );
}
?>

