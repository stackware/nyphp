<?PHP
if (imagetypes() & IMG_GIF) echo "GIF Support is enabled<br />";
if (imagetypes() & IMG_JPG) echo "JPEG Support is enabled<br />";
if (imagetypes() & IMG_PNG) echo "PNG Support is enabled<br />";
if (imagetypes() & IMG_WBMP) echo "WBMP Support is enabled<br />";
?>