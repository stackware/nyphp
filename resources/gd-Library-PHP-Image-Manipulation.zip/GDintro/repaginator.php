<?PHP
require ('fundex.php');
$nam = 'gd';

$n=0;
while (file_exists($nam.$n.'.php')) {
	$fileArray = file($nam.$n.'.php');
	$toc[$n] = str_replace("';\n",'',str_replace('$slide_title = \'','',$fileArray[1])) ;
	foreach ($fileArray as $line) {
		$pos1 = strpos($line,'<a '.'name="') ;
		if ($pos1) {
			$pos2 = strpos($line,'"></a>') ;
			$fundex[substr($line,$pos1+9,$pos2 - $pos1 - 9)]['page'] = $n ;
		}
	}
	++$n;
}
ksort($fundex) ;

$tocfile = '<'.'?PHP'."\n";
foreach ($toc as $chapter => $title)  $tocfile .= "\$toc['$title'] = $chapter ;\n";
$tocfile .= '?'.">\n";

file_put_contents_php4 ('tocfile.inc' , $tocfile ) ;

$funfile = '<'.'?PHP'."\n";
foreach ($fundex as $fun => $data) {
	 $funfile .= "\$fundex['$fun']['def'] = '".addslashes($data['def'])."' ;\n";
	 $funfile .= "\$fundex['$fun']['page'] = '{$data['page']}' ;\n";
}
$funfile .= '?'.">\n";

file_put_contents_php4 ('funfile.inc' , $funfile ) ;

function file_put_contents_php4($location, $whattowrite) {
	if ( file_exists ($location )) { 
		unlink ($location );
	}
	$fileHandler =fopen ($location ,'w' ); 
	fwrite ($fileHandler ,$whattowrite ); 
	fclose ($fileHandler ); 
}

?>