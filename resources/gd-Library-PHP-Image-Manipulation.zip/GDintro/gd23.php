<?PHP
$slide_title = 'Fonts: Bitmap';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
		<script type="text/javascript" language="JavaScript">
		<!--

		function drawString(data) {
			document.stringImage.src = "simplestring.php"
				+ "?font=" + data.font.value
				+ "&tColor=" + data.tColor.value
				+ "&x=" + data.x.value
				+ "&y=" + data.y.value
				+ "&string=" + data.string.value ;
		}
		-->
		</script>
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>
						<p>Five bitmap fonts are provided with gd: gdFontTiny, gdFontSmall, gdFontMediumBold, gdFontLarge, and gdFontGiant. These fonts are identified for use in the image functions, in order, by the integers 1-5.</p>
					</td>
				</tr>
				<tr>
					<td class="phpnet">
						<p><a name="imageString"></a> int <?=phpfun('imageString')?>&nbsp; ( resource image, int font, int x, int y, string s, int color )<br />
							Draws the string <i>s</i> in the image identified by <i>image</i> at coordinates <i>x</i>, <i>y</i> (top left is 0, 0) with the color <i>color</i>.</p>
						<p><a name="imageStringUp"></a>int <?=phpfun('imageStringUp')?>&nbsp; ( resource image, int font, int x, int y, string s, int color )<br />
							Draws the string <i>s</i> vertically in the image identified by <i>image</i> at coordinates <i>x</i>, <i>y</i> (top left is 0, 0) with the color <i>color</i>.</p>
						<p><a name="imageChar"></a>int <?=phpfun('imageChar')?>&nbsp; ( resource image, int font, int x, int y, string c, int color )<br />
							Draws the first character of <i>c</i> in the image identified by <i>id</i> with its upper-left at <i>x</i>, <i>y</i> (top left is 0, 0) with the color <i>color</i>.</p>
						<p><a name="imageCharUp"></a> int <?=phpfun('imageCharUp')?>&nbsp; ( resource image, int font, int x, int y, string c, int color )<br />
							Draws the first character of <i>c</i> vertically in the image identified by <i>image</i> at coordinates <i>x</i>, <i>y</i> (top left is 0, 0) with the color <i>color</i>.</p>
					</td>
				</tr>
				<tr>
					<td class="controller">
						<form method="get" name="simpleStringForm">
							<?=phpfun('imageString')?>&nbsp;($im, <select name="font" size="1">
								<option value="1">gdFontTiny (1)</option>
								<option value="2">gdFontSmall (2)</option>
								<option value="3" selected>gdFontMediumBold (3)</option>
								<option value="4">gdFontLarge (4)</option>
								<option value="5">gdFontGiant (5)</option>
							</select>, <input type="text" name="x" value="$x" size="4" maxlength="3">,&nbsp;<input type="text" name="y" value="$y" size="4" maxlength="2">, <input type="text" name="string" value="" size="20" maxlength="78">, <select name="tColor" size="1">
								<option selected value="FFFFFF">$white</option>
								<option value="FF0000">$red</option>
								<option value="00FF00">$green</option>
								<option value="0000FF">$blue</option>
								<option value="7FFF00">$lime</option>
								<option value="FF7F00">$orange</option>
								<option value="7F00FF">$purple</option>
								<option value="000000">$black</option>
							</select> );
							<p><input onclick="drawString(this.form);" type="button" name="ilrd" value="redraw"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td align="center"><img src="simplestring.php" alt="" name="stringImage" height="40" width="400" border="0"></td>
				</tr>
				<tr>
					<td align="left">In order to calculate the position of text within an image, there are two useful functions to help determine how much space a character will require.</td>
				</tr>
				<tr>
					<td class="phpnet" align="left"><a name="imageFontHeight"></a>int <?=phpfun('imageFontHeight')?>&nbsp; ( int font )<br />
						Returns the pixel height of a character in the specified font.
						<p><a name="imageFontWidth"></a>int <?=phpfun('imageFontWidth')?>&nbsp; ( int font )<br />
							Returns the pixel width of a character in the specified font.</p>
					</td>
				</tr>
				<tr>
					<td>In the <?=phpfun('imageString()')?>&nbsp; example above (simplestring.php), the default $x value is set to center the input string by calculating half of the total of the font width multiplied by the number of characters in the string, then subtraced from the image width:</td>
				</tr>
				<tr>
					<td class="source"><?php
					// highlight_string ('<?php'."\n".'$x = ceil ( ( $wd - ( imageFontWidth ($font) * strlen ($string) ) ) / 2 ) ;'."\n?".'>');
					show_source('simplestring.php');
					?></td>
				</tr>
				<tr>
					<td>In addition to the fonts distributed with gd, you can also use any bitmap fonts installed on the system. The font file format is binary and architecture dependent. Since this introduction is intended to be run on several environments, there will be no demonstration of this function.</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="imageLoadFont"></a>int <?=phpfun('imageLoadFont')?>&nbsp; ( string file )<br />
						Loads a user-defined bitmap font and returns an identifier for the font (that is always greater than 5, so it will not conflict with the built-in fonts).</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>