<?PHP
$slide_title = 'EXIF';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>
						<p>Many image formats, especially JPEG, provide the ability to store textual (&amp; binary thumbnail) metadata within the file itself. Digital cameras, scanners and other imaging equipment will often generate technical data and store it in a image more or less standard format know as the Exchangeable Image File Format or EXIF. Details can be found at <a href="http://www.exif.org/" target="_blank">http://www.exif.org/</a></p>
						<p>if PHP has been compiled with <code>--enable-exif</code>, several functions become available to read EXIF data. Since EXIF data is related to the generation of image (see the example below), there is no need to write EXIF data, and none are provided. </p>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="exif_imageType"></a>int <?=phpfun('exif_imageType')?>&nbsp; ( string filename )<br />
						Reads the first bytes of an image and checks its signature. When a correct signature is found a constant will be returned otherwise the return value is FALSE. The return value is the same value that <?=phpfun('getImageSize()')?>  returns in index 2 but this function is much faster.<br />
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="exif_read_data"></a>int <?=phpfun('exif_read_data')?>&nbsp; (  string filename [, string sections [, bool arrays [, bool thumbnail]]]<br />Reads the EXIF headers from a JPEG or TIFF image file. It returns an associative array where the indexes are the header names and the values are the values associated with those headers. If no data can be returned the result is FALSE.<br />
						<i>filename</i> is the name of the file to read. This cannot be an url.<br />
						<i>sections</i> is a comma separated list of sections that need to be present in file to produce a result array<br />
						<table border="1" cellspacing="0" cellpadding="0">
							<tr>
								<td class="phpnet">FILE</td>
								<td class="phpnet">FileName, FileSize, FileDateTime, SectionsFound</td>
							</tr>
							<tr>
								<td class="phpnet">COMPUTED</td>
								<td class="phpnet">html, Width, Height, IsColor and some more if available.</td>
							</tr>
							<tr>
								<td class="phpnet">ANY_TAG</td>
								<td class="phpnet">Any information that has a Tag e.g. IFD0, EXIF, ...</td>
							</tr>
							<tr>
								<td class="phpnet">IFD0</td>
								<td class="phpnet">All tagged data of IFD0. In normal image files this contains image size and so forth.</td>
							</tr>
							<tr>
								<td class="phpnet">THUMBNAIIL</td>
								<td class="phpnet">A file is supposed to contain a thumbnail if it has a second IFD. All tagged information about the embedded thumbnail is stored in this section.</td>
							</tr>
							<tr>
								<td class="phpnet">COMMENT</td>
								<td class="phpnet">Comment headers of JPEG images.</td>
							</tr>
							<tr>
								<td class="phpnet">EXIF</td>
								<td class="phpnet">The EXIF section is a sub section of IFD0. It contains more detailed information about an image. Most of these entries are digital camera related.</td>
							</tr>
						</table>
						<i>arrays</i> specifies whether or not each section becomes an array. The sections FILE, COMPUTED and THUMBNAIL allways become arrays as they may contain values whose names are conflict with other sections.<br />
						<i>thumbnail</i> whether or not to read the thumbnail itself and not only its tagged data. 
						<p><a name="read_exif_data"></a>int <?=phpfun('read_exif_data')?>&nbsp;  -- Alias of <?=phpfun('exif_read_data()')?><br />
							Description</p>
					</td>
				</tr>
				<tr>
					<td class="source" valign='top' align="left">
					<img src="AtTheLodge.jpg" alt="" width="220" height="180" align="right" border="0">
					<?PHP
					$exifString  = '<'."?PHP\nprint_r(exif_read_data('AtTheLodge.jpg',ANY_TAG)) ;\n?".'>';
					
					highlight_string($exifString);

					echo '<pre>';
					print_r(exif_read_data('AtTheLodge.jpg',ANY_TAG)) ;
					echo '</pre>';
					?>
					</td>
				</tr>
				<tr>
					<td class="phpnet" align="left"><a name="exif_thumbnail"></a>int <?=phpfun('exif_thumbnail')?>&nbsp; ( string filename [, int &amp;width [, int &amp;height [, int &amp;imagetype]]] )<br />Reads the embedded thumbnail of a TIFF or JPEG image. If the image contains no thumbnail FALSE  will be returned.<br />
						The parameters <i>width</i>, <i>height</i> and <i>imagetype</i> are available since PHP 4.3.0 and return the size of the thumbnail as well as its type. It is possible that <?=phpfun('exif_thumbnail()')?> cannot create an image but can determine its size. In this case, the return value is FALSE but <i>width</i> and <i>height</i> are set.<br />
						If you want to deliver thumbnails through this function, you should send the mimetype information using the <?=phpfun('header()')?> function.
						<p>Starting from version PHP 4.3.0, the function exif_thumbnail() can return thumbnails in TIFF format. </p>
					</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>
