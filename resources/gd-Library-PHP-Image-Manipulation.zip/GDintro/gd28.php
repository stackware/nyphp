<?PHP
$slide_title = 'IPTC';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td>
						<p>Non-technical information such as Author and Keywords can also be attached to image headers. The <a href="http://www.iptc.org/" target="_blank">International Press Telecommunications Council</a> has published as standard in widespread use referred to as IPTC. </p>
					</td>
				</tr>
				<tr>
					<td class="phpnet"><a name="iptcParse"></a>array <?=phpfun('iptcParse')?>&nbsp; ( string iptcblock )<br />
						his function parses a binary IPTC block into its single tags. It returns an array using the tagmarker as an index and the value as the value. It returns FALSE on error or if no IPTC data was found. See getimagesize() for a sample. </td>
				</tr>
				<tr>
					<td class="source" valign='top' align="left">
					<img src="AtTheLodge.jpg" alt="" width="220" height="180" align="right" border="0">
					<?PHP
					$iptcString  = '<'."?PHP\n\$size = getImageSize ('AtTheLodge.jpg',&\$info);\n";
					$iptcString .= "\$iptc = iptcParse(\$info['APP13']); // key for IPTC\n"; 
					$iptcString .= "print_r($iptc);\n?".'>';
					
					highlight_string($iptcString);
					
					$size = getimagesize ('AtTheLodge.jpg',$info);
					$iptc = iptcparse ($info['APP13']);
					echo '<pre>';
					print_r($iptc);
					echo '</pre>';
					?>
					</td>
				</tr>
				<tr>
					<td class="phpnet" align="left"><a name="iptcEmbed"></a>array <?=phpfun('iptcEmbed')?>&nbsp; ( string iptcdata, string jpeg_file_name [, int spool] )<br />
						Embeds binary IPTC data into a JPEG image</td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>