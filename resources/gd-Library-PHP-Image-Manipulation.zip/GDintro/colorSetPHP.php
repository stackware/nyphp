<?PHP

error_reporting(E_ALL ^ E_NOTICE);

/*
colorSetPHP.php
uses imageColorSet with an input color to alter the PHP logo
*/

$phpHex = '5B69A6';
$phpColor = hex2int($phpHex);

$newColor = hex2int(validHexColor($_REQUEST['color'],$phpHex)) ;

// should use php_logo_guid(), but that returns a .gif
$im = imageCreateFromPNG('php.png');

$phpCIndex = imageColorExact($im,$phpColor['r'],$phpColor['g'],$phpColor['b']);

imageColorSet($im,$phpCIndex,$newColor['r'],$newColor['g'],$newColor['b']);

header('Content-type: image/png');
imagePNG($im);
imageDestroy($im); 

/**
 * @param	$hex string		6-digit hexadecimal color
 * @return	array			3 elements 'r', 'g', & 'b' = int color values
 * @desc Converts a 6 digit hexadecimal number into an array of
 *       3 integer values ('r'  => red value, 'g'  => green, 'b'  => blue)
 */
function hex2int($hex) {
        return array( 'r' => hexdec(substr($hex, 0, 2)), // 1st pair of digits
					  'g' => hexdec(substr($hex, 2, 2)), // 2nd pair
                	  'b' => hexdec(substr($hex, 4, 2))  // 3rd pair
        			);
}

/**
 * @param $input string     6-digit hexadecimal string to be validated
 * @param $default string   default color to be returned if $input isn't valid
 * @return string           the validated 6-digit hexadecimal color
 * @desc returns $input if it is a valid hexadecimal color, 
 *       otherwise returns $default (which defaults to black)
 */
function validHexColor($input = '000000', $default = '000000') {
	// A valid Hexadecimal color is exactly 6 characters long
	// and eigher a digit or letter from a to f
	return (eregi('^[0-9a-f]{6}$', $input)) ? $input : $default ;
}

?>
