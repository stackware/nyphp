<?PHP


error_reporting(E_ALL ^ E_NOTICE);

// if 'from' & 'to' are not valid colors (i.e. 6 hex digits),
// set them to black & white
$fr_hex = (eregi('^[0-9a-f]{6}$',$_REQUEST['from']))?$_REQUEST['from']:'000000';
$to_hex = (eregi('^[0-9a-f]{6}$',$_REQUEST['to']))?$_REQUEST['to']:'FFFFFF';

// convert hex values to integers
$fr_int = hex2int($fr_hex);
$to_int = hex2int($to_hex);

// create a new image from file defined by input, then count total number of colors
// $im = imageCreatefrompng($_REQUEST['image']);

$im = safeGetImage($_REQUEST['image']);

// $im = safeGetImage($_REQUEST['image']);
$tc = imageColorstotal($im) ;

// based on the number of colors in the image, calculate
// the distance...
$r_step = ($to_int['r'] - $fr_int['r']) / $tc ;
$g_step = ($to_int['g'] - $fr_int['g']) / $tc ;
$b_step = ($to_int['b'] - $fr_int['b']) / $tc ;

// then set each index to the new colors,
// advancing $from to $to by the step distance calculated above
for ($n=0;$n<$tc;++$n) {
        imageColorset(  $im,    // resource image
                                        $n,             // int index
                                        round(($n * $r_step) + $fr_int['r']), // int red
                                        round(($n * $g_step) + $fr_int['g']), // int green
                                        round(($n * $b_step) + $fr_int['b'])  // int blue
                                ) ;
}

header("Content-type: image/png"); // do at last possible line
imagePng($im);
imageDestroy($im);

/**
 * @return array
 * @param $hex string
 * @desc Converts a 6 digit hexadecim  al number into an array of
 *       3 integer values (red, green, & blue)
 */
function hex2int($hex) {
        return array(
                'r' => hexdec(substr($hex, 0, 2)),
                'g' => hexdec(substr($hex, 2, 2)),
                'b' => hexdec(substr($hex, 4, 2)),
        );
}

function safeGetImage($rawInput) {
        $safeName = $rawInput ;
        if (is_file($safeName)) {
                $localim = imageCreatefrompng($safeName) ;
        } else {
                $localim = imageCreate (101, 101) ;
                $wht = imageColorAllocate($im,255,255,255);
                $red = imageColorAllocate($im,255,0,0);
                imageEllipse($im,50,50,90,90,$red);
                imageLine($im,20,20,80,80);
                imageLine($im,80,20,20,80);
        }
        return $localim ;
}
?>