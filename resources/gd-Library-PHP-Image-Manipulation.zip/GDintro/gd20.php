<?PHP
$slide_title = 'Thumbnail Example';
// set the amount of time before gallery images are destroyed
$time_limit = 30; // currently 10 minutes

require ('presfun.php');
require ('thumbnailer.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td colspan="3">
<?php

define('ORIGINALS_DIR', '/var/www/www.nyphp.org/content/presentations/GDintro/upload_originals/');
define('THUMBS_DIR', '/var/www/www.nyphp.org/content/presentations/GDintro/upload_thumbnails/');

define('ORIGINALS_URL', '/content/presentations/GDintro/upload_originals/');
define('THUMBS_URL', '/content/presentations/GDintro/upload_thumbnails/');


if( !is_dir(ORIGINALS_DIR) || !is_dir(THUMBS_DIR) || !is_writeable(ORIGINALS_DIR) || !is_writeable(THUMBS_DIR) )
   exit('The required directories are not created - please check the installation');

if( !empty($_REQUEST['upload']) && ($_REQUEST['upload'] === 'Upload to Gallery') ) {

   $orig_filename = $_FILES['image']['name'];
	$orig_fullpath = ORIGINALS_DIR.$_FILES['image']['name'];

	if( $_FILES['image']['size'] <= 0)
	   $ermsg = "$orig_filename is empty<br /><br />" ; 

	if( $_FILES['image']['size'] >= 409600 )
	   $ermsg = "$orig_filename is too large" ; //409600 is 400k, so its bytes/1024 

   if( isset($ermsg) ) {

	   echo $ermsg;

   } else {
		if( !move_uploaded_file($_FILES['image']['tmp_name'], $orig_fullpath) ) {
			echo "Possible file upload attack!  Here's some debugging info:\n";
			echo '<pre>';
			print_r($_FILES);
			echo '</pre>';
			exit;
		}

      $posi = strpos(strrev($orig_filename),'.') + 1;

      $withoutext = substr($orig_filename,0,$posi*-1);

		$ermsg = makeThumbnail($orig_fullpath,THUMBS_DIR."{$withoutext}.jpg");

      if( $ermsg )
         echo "<pre>$ermsg</pre>";
	}
}


if ($handle = opendir(ORIGINALS_DIR)) {

	while( false !== ($ofile = readdir($handle)) ) {

      if( ($ofile === '.') || ($ofile === '..') || ($ofile === 'CVS')  )
         continue;

      $posi = strpos(strrev($ofile),'.') + 1;
      $withoutext = substr($ofile,0,$posi*-1);

      $tfileurl = THUMBS_URL."{$withoutext}.jpg";
      $tfilepath = THUMBS_DIR."{$withoutext}.jpg";

      $ofileurl = ORIGINALS_URL.$ofile;
      $ofilepath = ORIGINALS_DIR.$ofile;

      if( ($withoutext !== 'jeffSP') && ((time() - filemtime($ofilepath)) > $time_limit) ) {
         unlink($ofilepath);
         if( is_readable($tfilepath) )
            unlink($tfilepath);
         continue;
      }

      if( strpos($ofile,'.gif') === FALSE )
         echo "<a href='$ofileurl' target='_blank'><img src='$tfileurl' alt='' border='0'></a> &nbsp; ";
	}
	closedir($handle);
}



?>
					</td>
				</tr>
				<tr>
					<td class="controller" colspan="3">
						<form enctype="multipart/form-data" action="gd20.php" method="post" name="FormName" target="_self">
							image: <input type="file" name="image" size="25">
							<p><input type="submit" name="upload" value="Upload to Gallery"></p>
						</form>
					</td>
				</tr>
				<tr>
					<td class="source" colspan="3"><? show_source('thumbnailer.php')?></td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>
