<?php
/*
 * thumbnailer.php
*/

/**
 * @return string
 * @param $o_file string	Filename of image to make thumbnail of
 * @param $t_file string	Filename to use for thumbnail
 * @desc Takes an image and makes a jpeg thumbnail defaulted to 100px high
 */
function makeThumbnail($o_file, $t_file, $t_ht = 100) {
	$image_info = getImageSize($o_file) ; // see EXIF for faster way
	
	switch ($image_info['mime']) {
		case 'image/gif':
			if (imagetypes() & IMG_GIF)  { // not the same as IMAGETYPE
				$o_im = imageCreateFromGIF($o_file) ;
			} else {
				$ermsg = 'GIF images are not supported<br />';
			}
			break;
		case 'image/jpeg':
			if (imagetypes() & IMG_JPG)  {
				$o_im = imageCreateFromJPEG($o_file) ;
			} else {
				$ermsg = 'JPEG images are not supported<br />';
			}
			break;
		case 'image/png':
			if (imagetypes() & IMG_PNG)  {
				$o_im = imageCreateFromPNG($o_file) ;
			} else {
				$ermsg = 'PNG images are not supported<br />';
			}
			break;
		case 'image/wbmp':
			if (imagetypes() & IMG_WBMP)  {
				$o_im = imageCreateFromWBMP($o_file) ;
			} else {
				$ermsg = 'WBMP images are not supported<br />';
			}
			break;
		default:
			$ermsg = $image_info['mime'].' images are not supported<br />';
			break;
	}
	
	if (!isset($ermsg)) {
		$o_wd = imagesx($o_im) ;
		$o_ht = imagesy($o_im) ;
		// thumbnail width = target * original width / original height
		$t_wd = round($o_wd * $t_ht / $o_ht) ; 

		$t_im = imageCreateTrueColor($t_wd,100);
		
		imageCopyResampled($t_im, $o_im, 0, 0, 0, 0, $t_wd, $t_ht, $o_wd, $o_ht);
		
		imageJPEG($t_im,$t_file);
		
		imageDestroy($o_im);
		imageDestroy($t_im);
	}
	return isset($ermsg)?$ermsg:NULL;
}


?>