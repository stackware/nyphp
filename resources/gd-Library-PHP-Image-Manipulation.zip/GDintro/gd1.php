<?PHP
$slide_title = 'Table of Contents';
require ('presfun.php');
require ('tocfile.inc');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
	<div align='center'>
		<table width="80%" border="0" cellspacing="2" cellpadding="2">
			<?PHP foreach ($toc as $title => $chapter) { ?>
			<tr><td class="heading" align='right'><?=$chapter?>:</td><td class="heading"><?="<a href='gd$chapter.php'>$title</a>"?></td></tr>
			<?PHP } ?>
			<tr><td class="heading" align='right'><?=count($toc)?>:</td><td class="heading"><a href='gd0.php'>Index of Functions</a></td></tr>
		</table>
	</div>
   <p style="margin: 55px; ">
      More <a href="/presentations/">presentations</a> and <br /><a href="http://phundamentals.nyphp.org">PHundamentals Articles</a> are available.
      <br /><br />
      <a href="/"><img border="0" src="/img/nyphp.logo.sm.black.gif"></a>
   </p>
	</body>

</html>
