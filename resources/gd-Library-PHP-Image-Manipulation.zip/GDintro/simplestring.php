<?PHP


error_reporting(E_ALL ^ E_NOTICE);

/*
simplestring.php
Generates image of a colored box with text
*/
$wd = 400 ;
$ht = 40 ;

// convert guaranteed valid hex value to array of integers
$bkgColor = hex2int(validHexColor($_REQUEST['bColor']));
$txtColor = hex2int(validHexColor($_REQUEST['tColor'],'ffffff'));
if ($txtColor === $bkgColor) $bkgColor = hex2int('FFFFFF') ;

$font = (is_numeric($_REQUEST['font']))  ? max(min($_REQUEST['font'], 5),1):3;
$string = safeString($_REQUEST['string']) ;

// if a number is passed for x, make sure it is > 0 and < image width - string width
$x = (is_numeric($_REQUEST['x'])) 
	? max(min($_REQUEST['x'],$wd - ceil( imageFontWidth($font) * strlen($string))),0) 
	: ceil(($wd - (imageFontWidth($font) * strlen($string)))/2);
// if a number is passed for 7, make sure it is > 0 and < image height - string height
$y = (is_numeric($_REQUEST['y'])) 
	? max(min($_REQUEST['y'],$ht - imageFontHeight($font)),0) 
	: ceil(($ht - imageFontHeight($font)) / 2) ;

$im = imageCreate($wd,$ht);

$bkgC = imageColorAllocate($im, $bkgColor['r'], $bkgColor['g'], $bkgColor['b']);
$txtC = imageColorAllocate($im, $txtColor['r'], $txtColor['g'], $txtColor['b']);

imageString($im,$font,$x,$y,$string,$txtC) ;

// send headers, output & destroy
header('Content-type: image/png');
imagePNG($im);
imageDestroy($im); 

/**
 * @param	$hex string		6-digit hexadecimal color
 * @return	array			3 elements 'r', 'g', & 'b' = int color values
 * @desc Converts a 6 digit hexadecimal number into an array of
 *       3 integer values ('r'  => red value, 'g'  => green, 'b'  => blue)
 */
function hex2int($hex) {
        return array( 'r' => hexdec(substr($hex, 0, 2)), // 1st pair of digits
					  'g' => hexdec(substr($hex, 2, 2)), // 2nd pair
                	  'b' => hexdec(substr($hex, 4, 2))  // 3rd pair
        			);
}

/**
 * @param $input string     6-digit hexadecimal string to be validated
 * @param $default string   default color to be returned if $input isn't valid
 * @return string           the validated 6-digit hexadecimal color
 * @desc returns $input if it is a valid hexadecimal color, 
 *       otherwise returns $default (which defaults to black)
 */
function validHexColor($input = '000000', $default = '000000') {
	// A valid Hexadecimal color is exactly 6 characters long
	// and eigher a digit or letter from a to f
	return (eregi('^[0-9a-f]{6}$', $input)) ? $input : $default ;
}

function safeString($input) {
	return stripslashes($input) ;
}
?>
