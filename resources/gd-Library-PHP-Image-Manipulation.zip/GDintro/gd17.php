<?PHP
$slide_title = 'Map Example';
require ('presfun.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title><?=$slide_title?></title>
		<link href="gd.css" rel="stylesheet" media="screen">
	</head>

	<body>
		<div align="center">
			<? navtable($slide_title); ?>
			<table width="80%" border="0" cellspacing="2" cellpadding="2">
				<tr>
					<td colspan="3">In the example below, the original image is an indexed file with each state colored by a different value from the palette. By converting the relative &quot;sales data&quot; of each state to a color value, we can use <?=phpfun('imageColorSet()')?>&nbsp;to display this information graphically. The darker the blue, the more sales in that state.</td>
				</tr>
				<tr>
					<td colspan="3" align="center"><img src="salesbystate.php" alt="" height="380" width="600" border="0"></td>
				</tr>
				<tr>
					<td class="source" colspan="3"><? show_source('salesbystate.php')?></td>
				</tr>
				<tr>
					<td>Note that in the original image to the right, even though each state is colored with a different index, all the indexes refer to the value of white.</td>
					<td>&nbsp;</td>
					<td align="right"><img src="<?='usa.png'?>" alt="" height="190" width="300" border="0"></td>
				</tr>
			</table>
			<? navtable(''); ?></div>
	</body>

</html>