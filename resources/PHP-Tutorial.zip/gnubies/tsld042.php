
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>The PHP Manual</TITLE> 
</HEAD>

<BODY     >

 <H1>The PHP Manual</H1> 
 <P><UL>
<LI>http://www.php.net/manual/en/
</UL><UL>
<LI>Quick ref: php.net/count
</UL><UL>
<LI>Downloadable:
<UL>
<LI>HTML
<LI>PDF
<LI>CHM
<LI>(<A HREF="http://www.php.net/download-docs.php">http://www.php.net/download-docs.php</A>)
</UL></UL><UL>
<LI>User comments</UL></P>
<P><UL>
RTMF<BR></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld041.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld043.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld042.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
