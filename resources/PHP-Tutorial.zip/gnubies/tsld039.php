
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceControl Structures</H1> 
 <P><UL>
<LI>if
</UL><UL>
<LI>else
</UL><UL>
<LI>elseif
</UL><UL>
<LI>while
</UL><UL>
<LI>do�while
</UL><UL>
<LI>for
</UL><UL>
<LI>foreach</UL></P>
<P><UL>
<LI>break
</UL><UL>
<LI>continue
</UL><UL>
<LI>switch
</UL><UL>
<LI>declare
</UL><UL>
<LI>return	</UL></P>
<P><UL>
<LI>require
</UL><UL>
<LI>include
</UL><UL>
<LI>require_once
</UL><UL>
<LI>include_once	</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld038.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld040.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld039.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
