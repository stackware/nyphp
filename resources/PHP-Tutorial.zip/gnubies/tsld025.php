
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceTypes</H1> 
 <P><UL>
<LI>A boolean expresses a truth value. It can be either TRUE or FALSE. 
</UL><UL>
<LI>An integer is a number of the set Z = {..., -2, -1, 0, 1, 2, ...}. 
</UL><UL>
<LI>Floating point numbers (AKA "floats", "doubles" or "real numbers") 
</UL><UL>
<LI>A string is a series of characters. In PHP, a character is the same as a byte, that is, there are exactly 256 different characters possible. This also implies that PHP has no native support of Unicode. 
</UL><UL>
<LI>An array in PHP is actually an ordered map. A map is a type that maps values to keys.
</UL><UL>
<LI>The special NULL value represents that a variable has no value. NULL is the only possible value of type NULL. </UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld024.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld026.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld025.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
