
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceVariables (cont.)</H1> 
 <P><UL>
<LI>
</UL></P>
<P><UL>
<LI>$var = "Bob"; 
</UL><UL>
<LI>$Var = "Joe"; 
</UL><UL>
<LI>echo "$var, $Var"; 
</UL><UL>
<LI>$4site = 'not yet'; 
</UL><UL>
<LI>$_4site = 'not yet'; 
</UL><UL>
<LI>$t�yte = 'mansikka';</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld026.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld028.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld027.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
