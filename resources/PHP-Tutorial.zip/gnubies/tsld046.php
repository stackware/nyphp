
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>New York PHP</TITLE> 
</HEAD>

<BODY     >

 <H1>New York PHP</H1> 
 <P><UL>
Important Dates
<BR></UL><UL>

</UL><UL>
April 21 � 22: PHP Training (http://www.nyphp.org/training.php)
</UL><UL>
April 22: NYPHP Monthly Meeting with Special Guest Zeev Suraski
</UL><UL>
April 23 � 24: PHP-Con (http://www.nyphp.org/phpcon)</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld045.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld047.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld046.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
