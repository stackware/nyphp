
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceBasic syntax</H1> 
 <P><UL>
Comments
<BR></UL><UL>

</UL><UL>
&#060?php echo "This is a test"; // This is a one-line c++ style comment /* This is a multi line comment 	yet another line of comment */echo "This is yet another test"; echo "One Final Test"; # This is shell-style style comment
</UL><UL>
?&#062</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld022.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld024.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld023.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
