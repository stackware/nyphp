
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>exit(0);</TITLE> 
</HEAD>

<BODY     >

 <H1>exit(0);</H1> 
 <P><UL>
Thank You!<BR></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld047.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100></TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld048.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
