
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceBasic syntax</H1> 
 <P><UL>
<LI>&#060? echo ("this is the simplest, an SGML processing instruction\n"); ?&#062 &#060?= expression ?&#062 This is a shortcut for "&#060? echo expression ?&#062�
</UL><UL>
<LI>&#060?php echo("if you want to serve XHTML or XML documents, do like this\n"); ?&#062
</UL><UL>
<LI>&#060script language="php"&#062 	echo ("some editors (like FrontPage) don't like processing instructions"); &#060/script&#062
</UL><UL>
<LI> &#060% echo ("You may optionally use ASP-style tags"); %&#062 &#060%= $variable; # This is a shortcut for "&#060% echo . . ." %&#062</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld021.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld023.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld022.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
