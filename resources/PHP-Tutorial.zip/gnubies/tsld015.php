
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Client Server</TITLE> 
</HEAD>

<BODY     >

 <H1>Client Server</H1> 
 <P><UL>
Get me a pie<BR></UL></P>
<P><UL>
Okay<BR></UL></P>
<P><UL>
Server<BR></UL></P>
<P><UL>
Protocol<BR></UL></P>
<P><UL>
Client<BR></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld014.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld016.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld015.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
