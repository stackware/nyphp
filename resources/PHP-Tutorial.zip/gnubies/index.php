<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>New York PHP</title>
<meta name="robots" content="index,follow" />
<meta name="revisit-after" content="4 weeks" />
<meta name="Keywords" content="New, York, City, PHP, Apache, MySQL, Linux, FreeBSD, Windows, Oracle, PostgreSQL, AMP, LAMP, Technology, Training, Certification, Zend, Classroom, User, Group, Programming, Development, Web, Design, Application, Resource, Email, Mailing, List" />
<meta name="Description" content="New York PHP, AMP Technology, PHP Development, PHP Training, Zend Training, PHP Classroom, Zend Classroom, PHP Certification, Zend Certification, New York City" />
<?php nyphpcss(); ?>
</head>
<body>
<?php
require('header_full.inc');  // insert header html
require('leftnav_open.inc'); // insert left nav html
?>
<!-- Presentations Content Start -->
<table width="93%" border="0" cellspacing="0" cellpadding="0" align="center">
 <tr align="center">
  <td valign="middle" colspan="2">&nbsp;</td>
 </tr>
 <tr>
   <td align="left" class="newsitemtitle">New York PHP Presentations</td>
   <td align="left" class="newsitem">&nbsp;&nbsp;&nbsp;<a name="top"><!-- Top --></a></td>
 </tr>
 <tr>
   <td align="center">&nbsp;</td>
 </tr>
 <tr>
   <td align="center">&nbsp;</td>
 </tr>


<tr align="center">
  <td valign="middle" colspan="2">
   <table style="border-top: 1px solid #666666; border-left: 1px solid #666666; border-bottom: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC;" width="85%" border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
     <td align="center" valign="middle">
      <table width="97%" border="0" cellpadding="3" cellspacing="3">

       <tr>
        <td colspan="3" align="left" valign="middle" class="newsitem">
<?php
include("index.inc");
?>
<!--    still too new --> 
   
        </td>
       </tr>

      </table>
     </td>
    </tr>
   </table>
  </td>
 </tr>
 <tr>
   <td align="center">&nbsp;</td>
 </tr>



</table>



<!-- Presentations Content End-->
<?php
leftnav_close();            // close left nav table with function from leftnav_open.php
require('footer.inc');       // insert footer html
?>
</body>
</html>
