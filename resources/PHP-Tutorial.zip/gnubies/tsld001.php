
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>An Introduction to PHP</TITLE> 
</HEAD>

<BODY     >

 <H1>An Introduction to PHP</H1> 
 <P><UL>
<H2>By Daniel Kushner � New York PHP
</H2>
<BR></UL><UL>
<H2><A HREF="http://www.nyphp.org">http://www.nyphp.org</A>
</H2>
</UL><UL>
<H2><a href="mailto:daniel@nyphp.org">daniel@nyphp.org</a></H2>
</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100></TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld002.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld001.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
