
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Lets PHP</TITLE> 
</HEAD>

<BODY     >

 <H1>Lets PHP</H1> 
 <P><UL>
<LI>HTTP and Web pages
</UL><UL>
<LI>What is HTTP?
</UL><UL>
<LI>HTML
</UL><UL>
<LI>Protocols (FTP, SMTP)
</UL><UL>
<LI>Static vs. Dynamic
</UL><UL>
<LI>Data
</UL><UL>
	</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld012.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld014.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld013.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
