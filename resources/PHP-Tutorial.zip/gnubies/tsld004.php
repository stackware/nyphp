
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>What is PHP?</TITLE> 
</HEAD>

<BODY     >

 <H1>What is PHP?</H1> 
 <P><UL>
<LI><H2>PHP Hypertext Preprocessing
</H2>
</UL><UL>
<LI><H2>History
</H2>
<UL>
<LI>1994/1995 Rasmus Lerdorf
<LI>1995 PHP/FI Version 2
<LI>1997 Zeev Suraski & Andi Gutmans
<LI>2001 PHP4
<LI>2004 ?
</UL></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld003.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld005.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld004.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
