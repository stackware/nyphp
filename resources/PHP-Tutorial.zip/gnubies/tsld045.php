
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>New York PHP</TITLE> 
</HEAD>

<BODY     >

 <H1>New York PHP</H1> 
 <P><UL>
Dedicated to the development of PHP and AMP Technology. 
<BR></UL><UL>
Over 700 members worldwide
</UL><UL>
Largest group in the United States. 
</UL><UL>
We actively support the PHP/AMP community through Open Source projects, sponsoring of networking events and meetings, and technical mailing lists.
</UL><UL>
Developing partnerships with New York's business community and national PHP companies</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld044.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld046.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld045.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
