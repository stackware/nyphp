
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>What is PHP?</TITLE> 
</HEAD>

<BODY     >

 <H1>What is PHP?</H1> 
 <P><UL>
&#060html&#062
<BR></UL><UL>
     &#060head&#062
</UL><UL>
          &#060title&#062PHP Test&#060/title&#062
</UL><UL>
     &#060/head&#062
</UL><UL>
     &#060body&#062 
</UL><UL>
          &#060?php 
</UL><UL>
               echo "&#060p&#062Hello World&#060/p&#062"; 
</UL><UL>
          ?&#062 
</UL><UL>
     &#060/body&#062 
</UL><UL>
&#060/html&#062</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld005.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld007.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld006.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
