
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Data</TITLE> 
</HEAD>

<BODY     >

 <H1>Data</H1> 
 <P><UL>
Where is that recipe?<BR></UL></P>
<P><UL>
Ah ha! There it is<BR></UL></P>
<P><UL>
PHP<BR></UL></P>
<P><UL>
Database<BR></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld017.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld019.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld018.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
