
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceOperators (cont.)</H1> 
 <P><UL>
String Operators<BR></UL></P>
<P><UL>
There are two string operators. The first is the concatenation operator ('.'), which returns the concatenation of its right and left arguments. 
<BR></UL><UL>
The second is the concatenating assignment operator ('.='), which appends the argument on the right side to the argument on the left side.</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld037.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld039.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld038.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
