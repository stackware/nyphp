
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceVariables (cont.)</H1> 
 <P><UL>
<LI>
</UL></P>
<P><UL>
<LI>$GLOBALS
</UL><UL>
<LI>$_SERVER
</UL><UL>
<LI>$_GET
</UL><UL>
<LI>$_POST</UL></P>
<P><UL>
<LI>$_COOKIE
</UL><UL>
<LI>$_FILES
</UL><UL>
<LI>$_REQUEST
</UL><UL>
<LI>$_SESSION</UL></P>
<P><UL>
PHP Superglobals<BR></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld027.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld029.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld028.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
