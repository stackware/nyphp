
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Some Numbers</TITLE> 
</HEAD>

<BODY     >

 <H1>Some Numbers</H1> 
 <P><UL>
Source: Netcraft<BR></UL></P>
<P><UL>
PHP: 10,519,623 Domains, 1,220,927 IP Addresses<BR></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld007.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld009.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld008.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
