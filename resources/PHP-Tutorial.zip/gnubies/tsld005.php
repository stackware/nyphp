
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>What is PHP?</TITLE> 
</HEAD>

<BODY     >

 <H1>What is PHP?</H1> 
 <P><UL>

<BR><UL>
<LI>PHP-GTK 
</UL></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld004.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld006.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld005.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
