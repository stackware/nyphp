
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language Reference</H1> 
 <P><UL>
<LI><H2>Basic syntax
</H2>
</UL><UL>
<LI><H2>Types
</H2>
</UL><UL>
<LI><H2>Variables
</H2>
</UL><UL>
<LI><H2>Constants
</H2>
</UL><UL>
<LI><H2>Expressions</H2>
</UL></P>
<P><UL>
<LI>Operators
</UL><UL>
<LI>Control Structures
</UL><UL>
<LI>Functions
</UL><UL>
<LI>Classes and Objects</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld020.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld022.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld021.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
