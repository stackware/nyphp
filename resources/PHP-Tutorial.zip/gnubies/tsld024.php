
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceTypes</H1> 
 <P><UL>
<LI>Boolean
</UL><UL>
<LI>Integer
</UL><UL>
<LI>Float
</UL><UL>
<LI>String</UL></P>
<P><UL>
<LI>Array
</UL><UL>
<LI>Object</UL></P>
<P><UL>
<LI>Resource
</UL><UL>
<LI>NULL</UL></P>
<P><UL>
Scalar Types<BR></UL></P>
<P><UL>
Compound Types<BR></UL></P>
<P><UL>
Special Types<BR></UL></P>
<P><UL>
Primitive Types<BR></UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld023.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld025.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld024.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
