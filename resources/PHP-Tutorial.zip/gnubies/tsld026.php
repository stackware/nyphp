
<HTML>

<HEAD>
<META HTTP-EQUIV="Context-Type" CONTEXT="text/html;charset=windows-1252">
<meta name="GENERATOR" content="Microsoft Internet Assistant for PowerPoint 97">
 <TITLE>Language Reference</TITLE> 
</HEAD>

<BODY     >

 <H1>Language ReferenceVariables</H1> 
 <P><UL>
<LI>
</UL></P>
<P><UL>
<LI>Variables in PHP are represented by a dollar sign followed by the name of the variable.
</UL><UL>
<LI>The variable name is case-sensitive.</UL></P>
<P></P> 
<P>
<TABLE>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld025.php">Previous slide</A> </TD>
  <TD HEIGHT=100 WIDTH=100> <A HREF="tsld027.php">Next slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="tsld001.php">Back to first slide</A> </TD>
  <TD HEIGHT=100 WIDTH=150> <A HREF="sld026.php">View graphic version</A> </TD>
</TABLE>
<BR>
</P>



</Body>
</HTML>
