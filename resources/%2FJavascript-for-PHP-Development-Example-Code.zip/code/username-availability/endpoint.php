<?php

header('Content-type: text/plain');

if (!array_key_exists('username', $_REQUEST) || empty($_REQUEST['username'])) {
	die('Error: no username provided.');
}

$usernames = array('mikeg', 'jdoe', 'foo', 'bar');

if (in_array($_REQUEST['username'], $usernames)) {
	printf('%s is not available. Sorry champ.', $_REQUEST['username']);
}
else {
	printf('%s is available!', $_REQUEST['username']);
}