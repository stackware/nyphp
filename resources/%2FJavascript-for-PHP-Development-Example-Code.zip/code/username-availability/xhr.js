window.XHR = function () {
	var getExplorerXHR = function () {
		var xhr, axo, ex;
		var objects = ['Microsoft', 'Msxml2', 'Msxml3'];

		for (var i = 0; i < objects.length; i++) {
			axo = objects[i] + '.XMLHTTP';
			try {
				xhr = new ActiveXObject(axo);
      			return xhr;
    		} catch (ex) {};
		}

		throw 'Unable to create XHR object.';
	};

	var getW3XHR = function () {
		return new XMLHttpRequest;
	};

	return {
		'getXHR' : function () {
			if (window.XMLHttpRequest) {
				return getW3XHR;
			}
			else if (window.ActiveXObject) {
				return getExplorerXHR;
			}
			else {
				throw 'Unable to determine XHR type';
			}
		}()
	};
}();