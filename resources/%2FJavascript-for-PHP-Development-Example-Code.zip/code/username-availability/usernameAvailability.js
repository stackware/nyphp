window.onload = function () {
	var usernameContainer, usernameCheckTrigger, username, xhr, uri;

	usernameContainer = document.getElementById('username-container');
	username = document.getElementById('username');

	// Create the check link
	usernameCheckTrigger = document.createElement('a');
	usernameCheckTrigger.setAttribute('href', '#');
	usernameCheckTrigger.appendChild(document.createTextNode('Check Availability'));

	// Set the check link's click handler
	usernameCheckTrigger.onclick = function () {

		// Create a URI by appending the username to the endpoint's query string
		uri = 'endpoint.php?username=' + encodeURIComponent(username.value);

		// Get an XHR instance
		xhr = XHR.getXHR();

		// Open an async. GET request
		xhr.open('GET', uri, true);

		// Set the state change callback
		xhr.onreadystatechange = function () {

			// Return if the ready state isn't complete
			if (xhr.readyState !== 4) {
				return;
			}

			// If the HTTP status is 200, we're good
			if (xhr.status === 200) {
				alert(xhr.responseText);
			}
		};

		// Send the request
		xhr.send(null);

		// Return false so the link doesn't activate
		return false;
	};

	usernameContainer.appendChild(usernameCheckTrigger);
};