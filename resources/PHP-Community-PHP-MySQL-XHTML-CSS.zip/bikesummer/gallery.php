<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<ul>
<li class="main">Gallery at <a target="outside" href="http://www.bikesummer.org/2003/photos/photos.php">www.bikesummer.org/2003/photos/</a></li>
<li class="main">Accepts submissions from public</li>
<li class="main">Thumbnails &amp; resizing automatic using GD Library</li>
<li class="main">Submissions go live immediately</li>
<li class="main">Public can report objectionable content</li>
<li class="main">Moderator can edit/remove content</li>
<li class="main">This presentation shows getting the output to line up</li>
</ul>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
