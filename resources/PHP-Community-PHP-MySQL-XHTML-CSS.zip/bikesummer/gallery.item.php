<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<h2>Put Values Into Arrays for Each DATABASE Row</h2>
<pre>
if ($PriorGroup != $SQL-&gt;{$Order}) {
    $PriorGroup = $SQL-&gt;{$Order};
    $Color = 1 - ($Color % 2);
    <b class="green">$Group[]</b> = &quot;  &lt;td align=\&quot;center\&quot; class=\&quot;group$Color\&quot;&gt;&quot;
               . &quot;{$OrderText} {$SQL-&gt;{$Order}}&lt;/td&gt;&quot;;
} else {
    <b class="green">$Group[]</b> = &quot;  &lt;td align=\&quot;center\&quot; class=\&quot;group$Color\&quot;&gt;&amp;nbsp;&lt;/td&gt;&quot;
}

<b class="orange">$Img[]</b> = &quot;  &lt;td align=\&quot;center\&quot; class=\&quot;img$Color\&quot;&gt;&quot;
         . &quot;&lt;a href=\&quot;view.php?PhotoID=$SQL-&gt;PhotoID\&quot;&gt;&quot;
         . &quot;&lt;img src=\&quot;thumb/$SQL-&gt;PhotoID.jpg\&quot; &quot;
         . &quot;alt=\&quot;$SQL-&gt;Caption\&quot; &quot;
         . 'class=&quot;img&quot; border=&quot;0&quot; /&gt;&lt;/a&gt;&lt;/td&gt;';

<b class="maroon">$Caption[]</b> = &quot;  &lt;td align=\&quot;center\&quot; class=\&quot;caption$Color\&quot;&gt;&quot;
             . &quot;&lt;small class=\&quot;caption\&quot;&gt;$SQL-&gt;Caption&lt;/small&gt;&lt;/td&gt;&quot;;
</pre>


<h2>Echo Arrays At End of DISPLAY Row</h2>
<pre>
if ($ColCount == $ThumbCols) {
    echo &quot;\n &lt;tr valign=\&quot;top\&quot; class=\&quot;group\&quot;&gt;\n&quot;;
    echo implode(&quot;\n&quot;, <b class="green">$Group</b>);
    echo &quot;\n &lt;/tr&gt;\n&quot;;

    echo &quot; &lt;tr valign=\&quot;top\&quot; class=\&quot;img\&quot;&gt;\n&quot;;
    echo implode(&quot;\n&quot;, <b class="orange">$Img</b>);
    echo &quot;\n &lt;/tr&gt;\n&quot;;

    echo &quot; &lt;tr valign=\&quot;top\&quot; class=\&quot;caption\&quot;&gt;\n&quot;;
    echo implode(&quot;\n&quot;, <b class="maroon">$Caption</b>);
    echo &quot;\n &lt;/tr&gt;\n&quot;;

    $ColCount = 0;
}
</pre>




<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
