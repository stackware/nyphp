<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<h2>Navigation Arrays</h2>
<pre>
/*
 * MAIN MENUS...
 *     dir name      navigation text
 *     v             v
 */
$Nav1['calendar'] = 'Calendar';
$Nav1['photos']   = 'Photo Gallery';
$Nav1['<b>local</b>']    = '<b>NYC</b>';          // &lt;-- *
$Nav1['new']      = 'What\'s New';

// * Year-to-year portability created by using a generic directory
//   name and defining the city name in the text only.


/*
 * SUB MENUS...
 *     directory name
 *     |           file name         navigation text
 *     v           v                 v
 */
$Nav2['calendar']['mail']         = 'Order a Calendar';
$Nav2['calendar']['addorganizer'] = 'Be an Organizer';
$Nav2['calendar']['addevent']     = 'Add an Event';
$Nav2['calendar']['plan']         = 'Plan/List an Event';

$Nav2['photos']['add']            = 'Add a Photo';
</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
