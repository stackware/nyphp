<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<ul>
<li class="main">Annual event, but host &amp; city changes each year</li>
<li class="main">PHP</li>
<li class="main">MySQL</li>
<li class="main">XHTML</li>
<li class="main">CSS 1</li>
</ul>

<p style="margin-top: 3em"><big>Please Note:</big></p>
<ul>
<li>Sample code has been significantly simplified</li>
<li>If viewing on the web: set browser to full screen / kiosk mode and 
    change font size / zoom until this page fits comfortably in the whole screen</li>
<li>Opera 7 Win32 users: our style sheet may cause rendering delays, even though it's valid</li>
<li>Footer placement works right in Mozilla on multiple OS's, but IE and Opera only on Windows</li>
</ul>

<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
