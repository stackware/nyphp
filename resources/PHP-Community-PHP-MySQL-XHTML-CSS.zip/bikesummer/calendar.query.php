<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<h2>Validate Input and Set Optional Query String Segment</h2>
<pre>
if ( empty($Form-&gt;<b><a class="green" href="calendar.form.php">CategoryID</a></b>)  OR  !is_array($Form-&gt;<b><a class="green" href="calendar.form.php">CategoryID</a></b>) ) {
    $Form-&gt;<b><a class="green" href="calendar.form.php">CategoryID</a></b> = array();
    <b class="orange">$Category</b> = '';
} else {
    foreach ($Form-&gt;<b><a class="green" href="calendar.form.php">CategoryID</a></b> AS $Key =&gt; $Value) {
        if ( !is_string($Value)  OR  !preg_match('/^\d{1,5}$/', $Value) ) {
            unset($Form-&gt;<b><a class="green" href="calendar.form.php">CategoryID</a></b>[$Key]);
        }
    }
    <b class="orange">$Category</b> = ' AND CategoryID IN ('
            . implode(',', $Form-&gt;CategoryID) . ')';
}
</pre>


<h2>Set Query String</h2>
<pre>
$SQL-&gt;SQLQueryString = &quot;SELECT <b><a class="maroon" href="calendar.table.php">{$Layout-&gt;BSYear}_Calendar</a></b>.CalendarID,
 <b><a class="blue" href="calendar.table.php">CategoryIDCSV</a></b>, Title,
 LOWER(TIME_FORMAT(TimeStart, '%l:%i %p')) AS TimeStartStr
 FROM <b><a class="maroon" href="calendar.table.php">{$Layout-&gt;BSYear}_Calendar</a></b>
 LEFT JOIN <b><a class="violet" href="calendar.table.php">{$Layout-&gt;BSYear}_CalendarCategories</a></b>
  ON (<b><a class="violet" href="calendar.table.php">{$Layout-&gt;BSYear}_CalendarCategories</a></b>.CalendarID
  = <b><a class="maroon" href="calendar.table.php">{$Layout-&gt;BSYear}_Calendar</a></b>.CalendarID)
 WHERE ( (DateStart BETWEEN '$Form-&gt;From' AND '$Form-&gt;To')
  <b class="orange">$Category</b>
 GROUP BY CalendarID&quot;;
</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
