<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '
 p.intro {font-size: 20pt; text-align: center; margin-top: 2em}
';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<p class="intro">PHP Highlights From the
<br /><a href="http://www.bikesummer.org/2003/">BikeSummer 2003 Website</a></p>

<p class="intro"><a href="http://www.nyphp.org/">New York PHP</a> Monthly Meeting
<br />November 25, 2003</p>

<p class="intro">by Daniel Convissor
<br /><a href="http://www.analysisandsolutions.com/">The Analysis and Solutions Company</a></p>



<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
