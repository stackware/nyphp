<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>



<h2>Table Structure</h2>
<pre>
mysql&gt; select CalendarID, <b class="blue">CategoryIDCSV</b>, Title, TimeStart from <b class="maroon">2003_Calendar</b>;
+------------+---------------+------------------+-----------+
| CalendarID | <b class="blue">CategoryIDCSV</b> | Title            | TimeStart |
+------------+---------------+------------------+-----------+
|          1 | 10,15         | Bridges by Night | 20:00:00  |
+------------+---------------+------------------+-----------+


mysql&gt; select * from <b class="violet">2003_CalendarCategories</b>;
+------------+------------+
| CategoryID | CalendarID |
+------------+------------+
|         10 |          1 |
|         15 |          1 |
+------------+------------+

mysql&gt; select * from <b class="black">2003_Categories</b>;
+------------+----------+--------+
| CategoryID | Category | Active |
+------------+----------+--------+
|         10 | Ride     | Y      |
|         15 | +FREE    | Y      |
+------------+----------+--------+
</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
