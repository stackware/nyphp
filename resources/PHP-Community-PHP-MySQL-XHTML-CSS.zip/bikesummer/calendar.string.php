<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<h2>Code Called For Each Calendar Item</h2>
<pre>
$CatEvent = explode(',', $SQL-&gt;<b><a class="blue" href="calendar.table.php">CategoryIDCSV</a></b>);
$CatTranslate = array();

foreach ($CatEvent AS $ID) {
    $CatTranslate[] = <b><a class="pink" href="calendar.array.php">$CatDb</a></b>[$ID];
}

asort($CatTranslate);
$CatDisplay = implode(', ', $CatTranslate);
</pre>


<h2>echo $CatDisplay</h2>
<pre>
+FREE, Ride
</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
