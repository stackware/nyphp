<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<h2>Code Called At Start of Script</h2>
<pre>
$SQL-&gt;SQLQueryString = &quot;SELECT CategoryID, Category FROM
        <b><a class="black" href="calendar.table.php">{$Layout-&gt;BSYear}_Categories</a></b>&quot;;
$SQL-&gt;RunQuery(__FILE__,__LINE__);

<b class="pink">$CatDb</b> = array();
while ( list($ID, $Cat) = $SQL-&gt;RecordAsEnumArray() ) {
    <b class="pink">$CatDb</b>[$ID] = $Cat;
}
</pre>


<h2>print_r(<b class="pink">$CatDb</b>)</h2>
<pre>
Array
(
    [10] => Ride
    [15] => +FREE
)
</pre>



<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
