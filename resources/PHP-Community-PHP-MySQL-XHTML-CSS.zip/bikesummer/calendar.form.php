<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<h2>Category Selection HTML</h2>
<pre>
&lt;form&gt;
  &lt;input type=&quot;checkbox&quot; name=&quot;<b class="green">CategoryID[]</b>&quot; value=&quot;15&quot; class=&quot;limitcat&quot; /&gt;+FREE
  &lt;input type=&quot;checkbox&quot; name=&quot;<b class="green">CategoryID[]</b>&quot; value=&quot;10&quot; class=&quot;limitcat&quot; checked /&gt;Ride
&lt;/form&gt;
</pre>


<h2>Category Selection Rendered</h2>
<form method="post" action="calendar.form.php">
    <input type="checkbox" name="CategoryID[]" value="15" class="limitcat" />+FREE
    <input type="checkbox" name="CategoryID[]" value="10" class="limitcat" checked />Ride
</form>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
