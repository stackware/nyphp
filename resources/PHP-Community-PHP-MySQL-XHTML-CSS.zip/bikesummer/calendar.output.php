<?php
#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '
 table.calendar {border-style: none}

 td.categoryN1,
 td.titleN1,
 td.startN1 {
    background-color: #99CC99;
 }

 td.titleN0,    td.titleN1,    td.titleY0,    td.titleY1,
 td.startN0,    td.startN1,    td.startY0,    td.startY1 {
     font-size: 90%;
     border-style: solid none none none;
     border-top: thick solid #FFFFFF;
 }

 td.categoryN0, td.categoryN1, td.categoryY0, td.categoryY1 {
     font-size: 80%;
     border-style: solid none none none;
     border-top: thick solid #FFFFFF;
 }

 td.startN0,    td.startN1,    td.startY0,    td.startY1 {
    white-space: nowrap;
 }

 a.out:link    {color: #0000FF; background-color: #99CC99}
 a.out:visited {color: #9999FF; background-color: #99CC99}
 a.out:hover   {color: #00FF00; background-color: #99CC99}

';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<h2>Rendered</h2>
<table class="calendar" width="90%" border="1" cellpadding="2" summary="Summary of calendar items">
 <tr valign="top" class="calendar">
  <td class="categoryN1">+FREE, Ride</td>
  <td class="titleN1"><a href="?CalendarID=1" class="out">Bridges by Night</a></td>
  <td class="startN1">8:00 pm</td>
 </tr>
</table>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
