<?php
	include 'fpage.php';
	$fPage = new FPage;
	
	echo "<h1>We are tprivileged.php</h1>";
	echo "<a href=\"tlogout.php\">logout</a>";
	
	error_log($fPage->debug_dump(true), 3 , "trace_log");
?>
