<?php
/*
	Copyright 2004 Felix Zaslavskiy
	http://www.zaslavskiy.net
	
	Release 0.1 beta
	
	This code can be used, modified or redistributed with only 
	the following restriction:
	  The original Copyright notice and url must
	  remain where they are.

	This code should work with php 4.2 or higher.
	
	The most recent information about this class mini library
	can be found at http://www.zaslavskiy.net/fpage

	TODO:
		Implement timeout handling. I am not convinced yet its needed.
		Implement more flexible clear_bookmarks. Need some field experience to figure out how this could be done.
		Write docs in one of those fancy auto document formats
*/

class FPageCaller
{
	var $url = "";			// absolute url of the caller
	var $args = null;		// any args the user may have passed alone
	var $bookmark = null;	// the bookmark that was used when making the jump
}

class FPage
{
	/*
		Configuration parameters.
			Can be set right here in the script or
			Can set dynamically uppon script startup.
			Do not set these to different values across script invocations.
	*/
	
	// We try to construct an absolute URL when redirecting.
	// It is required by the HTTP standard.
	// Many clients will accept just fine a short URL.
	// Change this to true only if you are absolutely sure.
	var $use_short_url = false;
	
	// If use_short_url = false $proto and $host may be 
	// use to set the protocol and host part of the URL manually.
	// The script does its best to guess the URL correctly.
	// Set these only if you are certain that those value
	// will alwasy be used. The $proto and $host do not 
	// overwrite the script decision but are used only if the 
	// script cannot guess correctly.
	
	// set to "http" or "https"
	var $proto = "";
	
	// dont forget a port number if it is none standard
	var $host = "";
	
	// wheather we should dump $_SESSION in the debug_dump function
	var $dump_session = false;


	/*
		The structure of a bookmark is as follows:
		array(
			[0] => name; 		// id of the bookmark assigned by user
			[1] => url;			// absolute url of page on which bookmark is for
			[2] => timestamp;	// time at which bookmark was created
			[3] => bdata;		// extra data user may attach to a bookmark
		)
	*/
	var $_bookmarks = null;
	var $_initialized = false;
	var $_caller = null;

	/*
		Reason for doing this is to avoid cases where a session needs
		to be started after some output.
	*/
	function FPage()
	{
		$this->_init();
	}
	
	/* 
		string $target:		  	Could be a unique value or not
		boolean $replace_last:	Specifies how to treat $target
			If last bookmark is same as $target we want to do nothing.
			This is supposed to accomodate a common case where the same page 
			may be accessed multiple times and the bookmarks("thispage") 
			is called repeatedly. We would not like to stack indentical 
			bookmarks on top of each other.  If you don't like this particular
			behaviour then set $replace_last = false		
	*/
	function bookmark($target, $bdata = null, $replace_last = true)
	{
		$this->_init();
		if(!empty($this->_bookmarks) && $replace_last){
			$last = &end($this->_bookmarks); 
			if($last[0] == $target )
		  		return;
		}
		$this->_bookmarks[] = $this->_init_bookmark($target, $bdata);
	}

	/*
		Returns weather there are any bookmarks present.
	*/
	function have_bookmarks()
	{
		$this->_init();
		return !empty($this->_bookmarks); 
	}
	
	/*
		Returns weather a particular bookmark exists.
		This is useful in case where it cannot be assumed that a 
		certain bookmark is around.
		
		Example usage:
		if($fPage->bookmark_exists("pre_login")){
			$fPage->jump_to("pre_login");
		}	
	*/
	function bookmark_exists($target)
	{
		foreach($this->_bookmarks as $bookmark){
			if($bookmark[0] == $target)
				return true;
		}
		return false;		
	}
	
	/*
		Returns the last bookmark.
	*/
	function get_last_bookmark()
	{
		$this->_init();
		if(!empty($this->_bookmarks)){
			$last = &end($this->_bookmarks);
			return $last[0];
		}else{ return false; }
	}
	
	/*
		If current page view is result of jump_to the get_caller()
		function can be used to view information about the caller.
		Take a look at class FPageCaller for the definition.
		
		Note: The Caller object can only be retrived on the page to
		which the original bookmark pointed to in the jump_to() call.
		This has nothing to do with normal http redirections or navigation. 
		In essence the function only provides information about the last
		jump_to() call.
	*/
	function get_caller()
	{
		if(empty($this->_caller->url)){
			return false;
		}else{
			// since we are not really on the page which was called anymore
			// we should the caller is no longer valid
			if($this->_caller->bookmark[1] != $this->_this_pages_url()){
				return false;
			}else{
				return $this->_caller;
			}
		}
	}
	
	/*
		string $target:		Identity of the bookmark to go to.
							If $target is "" then we jump to last known bookmark.
		object $args: 		Any $args we want to pass along.
		
		Notes:
			1. This function can only be used before any output is sent to the 
		browser.
			2. If target is really a redirect to the current page then
		 that is treated as any other jump_to() nothing special is done.
		 	3. This function does not return in the php sence of things.
	*/
	function jump_to($target, $args = null)
	{
		$this->_init();
		// search from latest to earliest bookmarks
		// for a match to $target
		$count = count($this->_bookmarks);
		for($i = $count - 1; $i >= 0; $i--){
			if(empty($target) ||  $target == $this->_bookmarks[$i][0]){
				$bookmark = $this->_bookmarks[$i];
				for($j = $i; $j < $count; $j++){
					unset($this->_bookmarks[$j]);
				}
				//lets reindex the array because unset alone won't
				$this->_bookmarks = array_values($this->_bookmarks);
				
				//lets store the caller data
				$this->_caller->url = $this->_this_pages_url();
				//if(isset($args)){ // we want to overwrite args no matter what
					$this->_caller->args = $args;
				//}
				$this->_caller->bookmark = $bookmark;
				// this is what its all about
				header("Location: {$bookmark[1]}");
				//just in case
				exit;
			}
		}
		//no bookmarks are around ?
		if(empty($target))
			trigger_error("There is not bookmarks so we cant jump to last bookmark", E_USER_ERROR);
		else
			trigger_error("The bookmark with id: $target was not found", E_USER_ERROR);
	}

	/* 
		string $target:	The bookmark id after which to clear bookmarks
						If $target is not specified all bookmarks are cleared.
		
		Note: If there is multiple occurances of $target then the starting
		point from which bookmarks are cleared is the oldest occurance of 
		$target.
	*/	
	function clear_bookmarks($target = null)
	{
		$this->_init();

		$count = count($this->_bookmarks);		
		for($i = 0; $i < $count; $i++){
			if(!isset($target) || $target == $this->_bookmarks[$i][0]){
				for(; $i < $count; $i++){
					unset($this->_bookmarks[$i]);
				}
				//lets reindex the array because unset alone won't
				$this->_bookmarks = array_values($this->_bookmarks);
				break;
			}
		}
		//there is not specific reason to wipe the caller object here
		//$this->_caller = new FPageCaller;
	}
	
	/*
		To sort of be similar how var_dump and print_r works the 
		$should_return will return the debug data instread of echoing it.
	*/
	function debug_dump($should_return = false)
	{
		$this->_init();
		$str = "Fpage Debug Output from {$_SERVER['REQUEST_URI']}\n";
		$str .= "Bookmarks:\n";
		$str .= print_r($this->_bookmarks, true) . "\n";
		$str .= "Caller:\n";
		$str .= print_r($this->_caller, true). "\n";
		if($this->dump_session){
			$str .= "Session Data:\n";
			if(isset($_SESSION))
				$str .= print_r($_SESSION, true) . "\n";
			else
				$str .= "No Session Present\n";
		}
		$str .= "-----------------------------------------------------\n\n";
		if(!$should_return)
			echo $str;
		else
			return $str;
	}
	
	
	/////////////////////////////////////////////////////////
	// Internal functions below. Not documented nor supported
	/////////////////////////////////////////////////////////
	function _init()
	{
		if($this->_initialized) return;
		// we may have started session in anohter _init call
		// but the session cookie has not made back to us that is 
		// why we have to check for isset($_SESSION)
		if(!isset($_SESSION)){
			if(headers_sent()){
				trigger_error("FPage requires a PHP session to be started in order to work.  Seems like headers where already sent probably because output has already been started elsewhere.  A common solution would be to call FPage constructor before any output generated.", E_USER_WARNING);
			}
			//we dont have session initiated, lets do it
			session_start();
			if(!isset($_SESSION["_fpage_bookmarks"]))
				$_SESSION["_fpage_bookmarks"] = array();
			if(!isset($_SESSION["_fpage_caller"]))
				$_SESSION["_fpage_caller"] = new FPageCaller;
		} // it does not matter if someone called session_start already
		
		$this->_bookmarks = &$_SESSION["_fpage_bookmarks"];
		$this->_caller = &$_SESSION["_fpage_caller"];
		$this->_initialized = true;
	}

	function _init_bookmark($name, $bdata)
	{
		return array($name, $this->_this_pages_url(), time(), $bdata);
	}
	
	function _this_pages_url()
	{
		$url = "";
		if(!$this->use_short_url){
			$url = "http://";
			if(isset($_SERVER['HTTPS'])){ 
				$url = "http://";
			}else if(!empty($this->proto)){
				$url = $this->proto . "://";
			}
			if(isset($_SERVER['HTTP_HOST'])){
				$url .= $_SERVER['HTTP_HOST'];
			}else if(!empty($this->host)){
				$url .= $this->host;
			}
		}
		$url .= $_SERVER['REQUEST_URI'];
		return $url;
	}
}

?>
