<?php
	include 'fpage.php';
	$fPage = new FPage;
	$fPage->bookmark("login");
	
	echo "<h1>We are tlogin.php</h1>";
	echo "<p>A valid username is \"bond\" , password dont matter :)</p>";
	$caller = $fPage->get_caller();
	if($caller && $caller->args == "incorrect")
		echo '<span style="color:red">Login Incorrect</span>';
	
	echo '<form action="tlogin_proc.php" method="post">
		 	User<input type="text" name="uname" /><br />
		 	Pass<input type="password" name="pass" /><br />
		 	<input type="submit" name="submit" value="login" />
		  </form><a href="tcancel_login.php">cancel</a>';
	
	error_log($fPage->debug_dump(true), 3 , "trace_log");
?>
