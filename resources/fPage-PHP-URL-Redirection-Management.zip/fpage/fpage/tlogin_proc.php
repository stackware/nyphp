<?php
	include 'fpage.php';
	$fPage = new FPage;
	
	if(isset($_POST['submit']))
	{
		if($_POST['uname'] == "bond"){	
			$fPage->clear_bookmarks("login");
			//note here we just do out own redirect because
			//tprivileged.php was never bookmarked by FPage
			// Note this is not a standards comforming redirect
			header("Location: tprivileged.php");
		}
		else {
			// we dont return here
			error_log($fPage->debug_dump(true), 3 , "trace_log");
			if($fPage->bookmark_exists("login")){
				$fPage->jump_to("login", "incorrect" );
			}else{ echo "You didnt come from a login page"; }
		}
	}	
	error_log($fPage->debug_dump(true), 3 , "trace_log");
?>
