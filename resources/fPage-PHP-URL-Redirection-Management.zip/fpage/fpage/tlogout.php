<?php
	include 'fpage.php';
	$fPage = new FPage;
	
	//do all sorts of logout stuff first
	if($fPage->bookmark_exists("pre_login")){
		$fPage->jump_to("pre_login", "Logged out. Goodbye!");
	}else{
		echo "Logged out ok";
	}
	error_log($fPage->debug_dump(true), 3 , "trace_log");
?>
