<?php
	include 'fpage.php';
	$fPage = new FPage;
	if($fPage->bookmark_exists("pre_login")){
		$fPage->jump_to("pre_login", "Login sometime soon!!");
	}else{
		echo "Dont know where to send you";
	}
	error_log($fPage->debug_dump(true), 3 , "trace_log");
?>
