<?php
	include 'fpage.php';
	$fPage = new FPage;
	$fPage->bookmark("pre_login");
	
	echo "<h1>We are tmain.php</h1>";
	$caller = $fPage->get_caller();
	if($caller){
		echo "<b>{$caller->args}</b><br />";
	}
	echo "<br /><a href=\"tlogin.php\">login</a>";
	
	error_log($fPage->debug_dump(true), 3 , "trace_log");
?>
