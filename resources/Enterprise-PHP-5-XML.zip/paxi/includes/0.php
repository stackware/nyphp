<table>
  <tr>
    <td class="acronym"><font color="#000066">P</font>HP <font color="#000066">A</font>pplication <font color="#000066">X</font>ML <font color="#000066">I</font>nterface</td>
  </tr>
  <tr>
    <td>
      <ul>
        <li>Built to support a variety of web services (XML) and to be deployed across any number of uniquely branded URLs</li>
        <li>Objective was to keep the framework extremely light weight and portable across many physical and virtual servers</li>
        <li>Client requirements were flexible templates & dynamic paramaters</li>
        <li>Personal requirements - no <a class="external" href="http://pear.php.net/">PEAR</a>!</li>        
        <li>Obviously wanted to use PHP for both speed and flexibility and its inherent template engine<br />(see: <a href="http://www.nyphp.org/content/presentations/3templates/whynot/" class="external">Why PHP is a template engine?</a>)</li>             
      </ul>
    </td>
  </tr>
</table>