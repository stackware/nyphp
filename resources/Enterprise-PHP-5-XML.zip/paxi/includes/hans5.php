

<table width="100%">
    <tr>
      <td>
      <ul>
              <li>�	PHP 5 to PHP 4 Communication</li><br /><br />
                  <ul>
                    <li>The XML response is often large and the array that is generated is equally large and complex</li>
                    <li>The PHP 4 script expects a string representation of an array.  Using serialize() and native UNIX file descriptors make this an efficient operation</li>                    
                    <? highlight_string("
in paxi.psh:  echo serialize(\$xmlresponse_array);

in PHP 4: 
	ob_start();
	fpassthru(\$soappipes[1]);
	\$response_array = unserialize(ob_get_clean());

                    ");?>
</li>
                        <li>The presentation logic in PHP 4 now determines formatting and layout of the returned data</li>
                        <li>If data appears invalid or corrupt, the user's original request is resubmitted to paxi.psh from memory and the process starts again</li>
                  </ul>
       </ul>
             </td>
    </tr>    
</table>