<table width="100%">
    <tr>
      <td>
      <ul>
        <li><strong>PHP/Javascript:</strong> <a href="http://www.webxpertz.net/faqs/jsfaq/jsserver.php" class="external">www.webxpertz.net/faqs/jsfaq/jsserver.php</a></li>                 
        <li><strong>SimpleXML:</strong> <a href="http://www.php.net/simplexml" class="external">www.php.net/simplexml</a></li>                         
        <li><strong>SOAP:</strong> <a href="http://www.w3.org/TR/2003/REC-soap12-part1-20030624/" class="external">www.w3.org/TR/2003/REC-soap12-part1-20030624</a></</li>         
      </ul>
      </td>
    </tr>
    <tr>
      <td align="center">
      Presentation given by: Christopher Hendry (<a href="mailto:contact" onclick="location.href='mail'+'to'+':'+'chendry'+unescape('%40')+'harlangroup.org'; return false" class="external">chendry at harlangroup dot org</a>)
      </td>
    </tr>
</table>
    