<table width="100%">
  
    <tr>
      <td>
      <ul>
              <li>PHP 5 Request XML Processing</li>
                  <ul>
                    <li>The PHP 5 CLI script (paxi.psh) reads stdin via output buffering</li>
                    <li>Multipart MIME entities are created and wrapped around each other</li>
                      <ul>
                        <li>Unique Boundary values are generated</li>
                        <li>Accurate Content-Length values are determined</li>
                      </ul>              
                    <li>Managing large amounts of XML quickly and efficiently was a goal; using output buffering provided a fast and flexible method for doing this</li>
                  </ul>
       </ul>
              <li>SOAP Server Communication</li>
                  <ul>
                    <li>Manual SSL socket communication using fsockopen().  Flexibility and performance were key concerns.<br /><br />
<? highlight_string("\$soapfp = fsockopen(SOAPD_URL,SOAPD_PORT,\$errno,\$errstr,CONNECT_TIMEOUT);");?></li><br /><br />

                    <li>Network and SOAP server health is chaotic and problematic</li>
                      <ul>
                        <li>Detection of network/server errors required connection and communication timeouts and retries for both request and response phases</li>
                        <li>PHP 5's stream API stabilized since PHP 4</li>
                      </ul>
                    </ul>
     </ul>
      </td>
      </tr>
</table>