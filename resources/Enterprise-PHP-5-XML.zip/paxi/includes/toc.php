<table>
  <tr>
    <td>
      <ul>
    <? for ( $i=0; $i<$totalSlides; ++$i ) { ?>
    <li>Slide: <? $number = $i+1; print $number; ?> - <a class="navLink" href="<?=$_SERVER['PHP_SELF']?>?slide=<?=$i?>"><?=$slideName[$i]?></a></li>
  <? } ?>
      </ul>
    </td>
  </tr>
</table>      