<table width="100%">
    <tr>
      <td>
      <ul>
        <li>Use sockets to connect over SSL to SOAP server</li>
        <li>Build custom SOAP client (pMime)</li>
        <li>Use SimpleXML to parse XML into an array (allowing access to data across dynamic templates)</li>
        <li>Decided not to use sessions to speed up development time</li>                
        <ul>
          <li>Used SOAP server's sessionID instead (since in most instances all user info is returned)</li>                       
          <li>Allows for rapid scalability across multiple webservers</li>          
        </ul>
              
      </ul>
      </td>
    </tr>

</table>
    