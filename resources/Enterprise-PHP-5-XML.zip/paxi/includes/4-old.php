<SCRIPT language="javascript" SRC="http://dev.cheapairlines.com/support/index_hotels.js"></script>
<table width="100%">
    <tr>
      <td>
      <ul>
        <li>On form submit dynamic javascript function changes the source reference of script in the header</li>
        <li>New source reference has search paramaters in the query string</li>
        <li>PHP outputs javascript which then gets executed in the page without refresh</li><br />
      </ul>
      </td>
    </tr>
    <tr>
      <td class="code">
        <table align="center">
          <tr>
              <td align="center">City Name or Aiport Code:&nbsp;<input type="text" id="dloc1" name="dloc" /></td></tr>
          <tr>
              <td height="1" align="center"><div id="dloc1_menu"></div></td>
          </tr> 
          <tr>
              <td align="center"><input type="button" name="Submit" value="Search!" onclick="getAirports();" />
          </tr>
        </table>
      </td>
    </tr>
</table>