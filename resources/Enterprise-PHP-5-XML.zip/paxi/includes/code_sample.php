<table width="100%">
    <tr>
      <td>
      <ul>
        <li>Initial webservice used SOAP with attachments.</li>
        <li>Webservice didn't properly use SOAP protocol.</li>
        <li>The SOAP header did not define what was in the attachment.</li>
        <li>PHP-SOAP, nuSOAP, PEAR though capable of building SOAP attachments do not currently support receiving SOAP with attachments.</li>        
      </ul>
      </td>
    </tr>

</table>
    