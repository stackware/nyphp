

<table width="100%">
    <tr>
      <td>
      <ul>
              <li>PHP 5 Response XML Processing</li><br /><br />
                  <ul>
                    <li>pMIME accepts a file descriptor (in this case a network socket from the SOAP server) and determines the structure of the incoming MIME/SOAP packet in real-time<br /><br />
                    <? highlight_string("
\$responseparser = new pMIME;
\$responseparser->Incoming($soapfp);
                    
                    ");?>
</li>
                    <ul>
                        <li>pMIME is lightweight and fast, keeping only a single copy of the data.  Structure is retained by use of an array of integers</li>
                        <li>Particular MIME entities and header fields can be examined.  JSESSION was important for transactional integrity<br /><br />
                                            <? highlight_string("\$responseparser->setHeaderPart(0);
\$responseparser->setField('Set-Cookie',TRUE);
if( \$responseparser->isParameter('SESSIONID') )
  \$REQUEST_SESSIONID = \$responseparser->parseField('SESSIONID');
		 else
  \$REQUEST_SESSIONID = NULL;
  
  ");?>
                        </li>
                      </ul>              
                    <li>Extracted XML is passed to SimpleXML routines for XML parsing and manipulation<br /><br />
                    
 <? highlight_string("\$xmlresponse_array = XMLResponseParser(\$responseparser->fetchPart(5);
");?>                 
                    </li>
                  </ul>
       </ul>
             </td>
    </tr>    
</table>