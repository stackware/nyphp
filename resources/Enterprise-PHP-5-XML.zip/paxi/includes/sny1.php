<? 
// code blocks for this page
$block1 = <<<___EOCODE___
function getAirports() {  
  // call as popup for browsers that won't rescript on the fly  
  if ( window.name != 'airports' && nodynamicjs ) {
    popupAirports();
  }
  else if ( nodynamicjs ) {    
    //window.alert('submitting');    
    document.getElementById('form1').submit();
  } else {    
    // allow refresh by removing any previously appended script
    var aphead = document.getElementsByTagName('body').item(0);
    var apold  = document.getElementById('scriptId');
    if (apold) aphead.removeChild(apold);
    
    // create DOM script element    
    newscript = document.createElement('script');
    var apfullpath = "http://example.com/airports.php?";

    // (snippet) get query values from form and add to scripturl
    if ( document.getElementById('destination1') ) {
    	  var dest1 = document.getElementById('destination1').value;
       	apfullpath = apfullpath + 'destination1=' + destination1 + '&';
    }
    // assign src attribute to our script element
    newscript.setAttribute("src", apfullpath);
    // assign other attributes
    newscript.setAttribute("type",'text/javascript');
    newscript.setAttribute("defer", 'false');
    newscript.setAttribute("id", 'dynscript');
    newscript.setAttribute("version", '0.4');

    // append it to the head... nice trick (thanks D Kushner, DC Krook, J Knight)
    void(aphead.appendChild(newscript));  }
  }
___EOCODE___;


// code blocks for this page
$block2 = <<<___EOCODE2___
// return (string) menu of Airports; or TRUE if valid Airport or City Code
function process(\$loc, \$key) {
  // if \$loc isn't already an airport...
  if ( !isAirport(\$loc) ) {
	  // parse \$loc for state/country names
  	\$loc_States = getStates(\$loc);
  	// look up possible matches
   	\$loc_Airports = array();
   	\$loc_Choices = getAirports(\$loc_States, \$loc_Airports);
   	
  	  	// if there are choices, render select menus
  	  	if ( is_array(\$loc_Choices) ) {
  	      		 \$loc_menu = '<select class="dropdown"
  				                   name="'.\$key.'Select"
   				                   onchange="document.getElementById(\''.\$key.'\').value=this.value;" >
    			                  <option value="">Please choose an airport...</option>';
    			                  
    		   		 foreach ( \$loc_Choices AS \$codearray ) {
                    		\$code = \$codearray[0];
                     		\$citystate = \$codearray[1];
                  			\$loc_menu .= '<option value="'.\$code.'">'.htmlentities(\$citystate).'</option>';
            	 }         
           		 \$loc_menu .= '</select><span class="error">*</span>';
       	}
      	// or render message if no choices found
      	else {
      	   		 \$loc_menu = '<div class="error">Aiport or City not found, please try again.</div>';
       	}
  // quote the html for delivery
  \$loc_menu = addslashes(\$loc_menu);
  }
  else {
       // loc is an airport code, proceed
     	 \$loc_menu = TRUE;
  }
 return \$loc_menu;
}

___EOCODE2___;

// code blocks for this page
$block3 = <<<___EOCODE3___
if ( validateTripType(document.getElementById('form1'), $single) ) {
 	document.getElementById('form1').submit();
}
___EOCODE3___;

$block4 = <<<___EOCODE4___
document.getElementById('destination1').innerHTML = "$destination1_menu";
___EOCODE4___;


?>
<SCRIPT language="javascript" SRC="http://dev.cheapairlines.com/support/index_hotels.js"></script>
<table width="100%">
    <tr><td><font size="3"><strong>Dynamic JavaScript Tricks</strong></font></td></tr>
    <tr>
      <td class="code">
        <table align="center">
          <tr>
              <td align="center">City Name or Aiport Code:&nbsp;<input type="text" id="dloc1" name="dloc" /></td></tr>
          <tr>
              <td height="1" align="center"><div id="dloc1_menu"></div></td>
          </tr> 
          <tr>
              <td align="center"><input type="button" name="Submit" value="Search!" onclick="getAirports();" />
          </tr>
        </table>
      </td>
    </tr>    
    <tr>
      <td>
      <ul>
        <li>This function is called when you click the Submit button. If your browser is capable of it, a new <?=htmlentities('<script>');?> element will be appended to the <head> element of the document, with the src attribute set to our airports.php script on the server.
</li><br />       
      </ul>
      </td>
    </tr>    
    <tr>
      <td class="code">
              <? highlight_string($block1); ?>
      </td>
    </tr>
    <tr><td><font size="3"><strong>The main processor function</strong></font></td></tr>    
    <tr>
      <td>
      <ul>
        <li>The following function takes a location query (like "St. Louis, MO") and a label ( like "destination1" ). It parses the query then checks to see if there are any airports or cities that match. 
</li>
        <li>If the the query is an airport code, TRUE is returned, indicating to the calling script that no choice needs to be made.
</li>
        <li>If choices are found, a custom HTML <?=htmlentities('<select>');?> menu is returned listing each of the choices for that label.
</li>
        <li>If nothing is found to match the query, an HTML message is returned requesting a different query.
</li>
<br />    
      </ul>
      </td>
    </tr>   
    <tr>
      <td class="code">
               <? highlight_string($block2); ?>
      </td>
    </tr> 
    <tr><td><font size="3"><strong>Returning the Javascript</strong></font></td></tr>        
    <tr>
      <td>
      <ul>
        <li>If all locations are valid airport codes, the following JavaScript is sent, which ensures that other form fields are valid, then submits the form:
</li><br />    
      </ul>
      </td>
    </tr>  
    <tr>
      <td class="code">
              <? highlight_string($block3); ?>
      </td>
    </tr>  
    <tr>
      <td>
      <ul>
        <li>If not, we return JavaScript that renders the <?=htmlentities('<select>');?> menu of choices in the proper place on the from (destination1 in this case):
</li><br />    
      </ul>
      </td>
    </tr>  
    <tr>
      <td class="code">
              <? highlight_string($block4); ?>
      </td>
    </tr>            
</table>