<? 
// code blocks for this page
$block1 = <<<___EOCODE___
<?php 

if( empty(\$sessionID) )
  \$soap = proc_open(IPAXI_ARPSH,\$fds,\$soappipes);
else
  \$soap = proc_open(IPAXI_ARPSH."{\$sessionID}",\$fds,\$soappipes);

		fwrite(\$soappipes [0],\$requestxml);

?>
___EOCODE___;


?>
<table width="100%">
  
    <tr>
      <td>
      <ul><li><strong>PHP 4 to PHP 5 Communication</strong></li>
      <ul>
              <li>PHP 4 validates form input from browser and generates SOAP packet using output buffering</li>
              <li>Using <strong>proc_open()</strong> and command line arguments, PHP 4 controls and maintains bi-directional communication with paxi.psh</ul></ul>
              
      </td>
    </tr> 
    <tr>
      <td class="code">
              <? highlight_string($block1); ?>
      </td>
    </tr>          
</table>