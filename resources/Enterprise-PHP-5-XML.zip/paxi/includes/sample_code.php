<? 
// code blocks for this page
$block1 = <<<___EOCODE___
<?php

class beer
{
  
  var \$sixPack = 6;
  
  function beer() 
  {
    return \$this->getBeer();
  }  
  
  function getBeer() {
    
    if ( \$this->sixPack > 0 ) { \$this->sixPack--; return \$this->sixPack; }
    
      else return \$this->doh();
      
  }
  
  function doh()
  {
    return 'doh!';
  } 
    
  
}
  

\$gotBeer = new beer();

?>
___EOCODE___;

?>

<table width="100%">
    <tr>
      <td>
      <ul>
        <li>There's nothing wrong with me, really.</li>
        <li>Sanity is a maleable thing.</li>
      </ul>
      </td>
    </tr>
    <tr>
      <td class="code">
      <? highlight_string($block1); ?>
      </td>
    </tr>
    <tr>
      <td>
      <ul>
        <li>I'm not feeling very creative tonite.</li>
      </ul>
      </td>
    </tr>    
</table>
    