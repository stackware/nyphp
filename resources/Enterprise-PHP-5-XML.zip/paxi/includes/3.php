<table width="100%">
  
    <tr>
      <td>
      <ul>
               <li>PHP 4 frontend validates user input, does a fuzzy match for airport codes</li>
               <li>PHP 4 frontend builds appropriate XML using buffers</li> 
               <li>PHP 4 passes XML and sessionID (if appropriate) to PHP5 CLI</li>
               <li>PHP 5 CLI script (paxi.psh) communicates with PHP 4 Apache module via fast native UNIX pipes</li>
               <li>paxi.psh script determines request type and validates input</li>
               <li>Using SSL sockets, paxi.psh makes a SOAP request to remote server</li>
               <li>After validating the response and handling exceptions,  parsed data is passed back into PHP 4 Apache module</li>
      </ul>
      </td>
    </tr>    
</table>