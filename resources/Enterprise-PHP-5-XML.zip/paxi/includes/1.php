<table width="100%">
    <tr>
      <td>
      <ul>
        <li>Web service used SOAP with attachments</li>
        <li>Web service didn't properly use SOAP protocol</li>
        <li>No information, except SOAP Fault, could be attained from the SOAP body or header (ie, couldn't continue process until XML document was parsed)</li>
        <li>PHP-SOAP, nuSOAP, PEAR though capable of building SOAP attachments do not currently support receiving/parsing SOAP with attachments</li>        
        <li>Transport had to support POST over SSL</li>
        <li>cURL / PEAR complex implementation for POST over SSL</li>        
        <li>XML files could be between 50k and 1.5Megs</li>          
        <li>Needed XML values in an array to support dynamic templates (don't want to just transform the XML, ie, XSLT)</li>         
        <li>At launch, framework needed to support 2k searches an hour - scaling to 10x that over three months</li>         
        <li><strong>One month development timeline!</strong></li>                 
      </ul>
      </td>
    </tr>

</table>
    