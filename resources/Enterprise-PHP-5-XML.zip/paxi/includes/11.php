<table width="100%">
    <tr>
      <td>
      <ul>
        <li>We use PHP sessions to maintain state, and a response table to tie remote responses to sessions.
</li>
          <ul>
        <li>The remote request script is called with a key that it will use to save the remote response</li>
        <li>Waiting.php script looks for the returned response, refreshing every few seconds</li>
        <li>If the response times out, the waiting script redisplays the current step in the process, otherwise it uses the information in the response to display the next step.</li>           
        </ul>           
       <li>Remote requests may now be called in advanced, and saved for later use by the session</li>
      </ul>
      </td>
    </tr>

</table>
    