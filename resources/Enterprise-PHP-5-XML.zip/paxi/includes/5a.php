<? 
// code blocks for this page
$block1 = <<<___EOCODE___
<?xml version="1.0" encoding="UTF-8"?>
<nyphp>
	<currentVersion>2</currentVersion>
	<userID>NYPHP</userID>
	<memberShip>1256</memberShip>
	<state>New York</state>
	<members>
		<member>
			<memberID>001</memberID>
			<email>hans at nyphp dot org</email>
			<contactInfo>
				<address>
					<street>123 Street</street>
					<city>New York</city>
					<stateID>NY</stateID>
					<postalCode>10101</postalCode>
					<countryID>US</countryID>
				</address>
				<phone>212 867 5309</phone>
				<fax/>
			</contactInfo>
		</member>
		<member>
			<memberID>023</memberID>
			<email>harlan at nyphp dot org</email>
			<contactInfo>
				<address>
					<street>127 Street</street>
					<city>New York</city>
					<stateID>NY</stateID>
					<postalCode>10101</postalCode>
					<countryID>US</countryID>
				</address>
				<phone>212 666 HELL</phone>
				<fax/>
			</contactInfo>
		</member>		
		<member>
			<memberID>066</memberID>
			<email>snyder at nyphp dot org</email>
			<contactInfo>
				<address>
					<street>185 Street</street>
					<city>New York</city>
					<stateID>NY</stateID>
					<postalCode>10101</postalCode>
					<countryID>US</countryID>
				</address>
				<phone>212 666 HELL</phone>
				<fax/>
			</contactInfo>
		</member>			
	</members>
	<extraStuff>
		<URL>www.nyphp.org</URL>
		<meetingDate>Fourth Tuesday of each Month</meetingDate>
		<comments>Not the last Tuesday</comments>
	</extraStuff>
</nyphp>
___EOCODE___;


// code blocks for this page
$block2 = <<<___EOCODE2___
<?php

  /* create SimpleXML object */
  \$xml = simplexml_load_string(\$responsexml);

  /* Find the name of the root node
	   Would prefer to do this entirely in SimpleXML */
  \$type = dom_import_simplexml(\$xml)->tagName;
	
  /* call the toArray method for this particular XML file (Parser_nyphp class) */
  if ( \$type == 'nyphp' ) \$response_array = PARSER_nyphp::toArray(\$xml); 
  
  
  /* simple parser - Adam Trachtenberg */
    class PARSER_ComplexType {
  
      protected \$data = array();
  
      static public function toArray() {
        return array();
      }
      
    }

  /* parser for nyphp node - need to know schema */
    class PARSER_nyphp extends PARSER_ComplexType {

     	static public function toArray(\$xml) {
     	  
  	  \$data = array();	    /**** protected \$data ****/   	  
     	  
      /* Need to test if a node exists.
         Two possible solutions:   	  

         a) not tested - Adam? */
      if ( count(\$xml->xpath(currentVersion)) > 0 ) {   

        \$data['currentVersion'] = (int) \$xml->currentVersion;
        
      }

      /* b) we can only do this on a leaf node, will the above always work - what about with iterators (as below)???  */
      if ( (string) \$xml->currentVersion) !='' ) {   
        \$data['currentVersion'] = (int) \$xml->currentVersion;
      }
       
      if ( (string) \$xml->userID) !='' ) {   
        \$data['userID'] = (string) \$xml->userID;
      }     
      
      .
      .
      .
      
      /* Must be a better way to do this???
      
         Right now if you cast a node that has children to a string 
         it returns as an empty string, thus you need to test for the
         leaf node, which will return the value
      */
      if ( (string) \$xml->members->member->memberID !='' ) {
		  
		    foreach(\$xml->members as \$member) {
		      \$data['members'][] = PARSER_member::toArray(\$member);
		    }
		    
		  }

      .
      .
      .  
     	  
     	return \$data;
     	  
    	}
    	
    }

    /* build out a class for each node */
    class PARSER_member extends PARSER_ComplexType {

     	static public function toArray(\$xml) {
     	  
  	  \$data = array();	       	  
     	  
      if ( (string) \$xml->memberID) !='' ) {   
        \$data['memberID'] = (int) \$xml->memberID;
      }
       
      if ( (string) \$xml->email) !='' ) {   
        \$data['email'] = (string) \$xml->email;
      }     
      
      .
      .
      .
      
      /* same as above, need to test the leaf */
      if ( (string) \$xml->contactInfo->address->street !='') {
		  
		    foreach(\$xml->contactInfo->address as \$address) {
		      // here we alter the way the array is returned, leaving out the contactInfo node
		      \$data['address'] = PARSER_address::toArray(\$address);
		    }
		    
		  }

      .
      .
      .  
     	  
     	return \$data;
     	  
    	}
    	
    }

   /* build out a class for each node */
    class PARSER_address extends PARSER_ComplexType {

     	static public function toArray(\$xml) {
     	  
  	  \$data = array();	
  	  
  	  .
  	  .
  	  .
  	  
  	  return \$data;
  	  
  	  }
  	  
  	}
  
?>
___EOCODE2___;
?>
<table width="100%">
    <tr>
      <td>
      <ul>
        <li>To be the first kid on my block using in production</li>
        <li>Lower level to speed up parsing large file size</li>
        <li>Built in XPATH</li>
        <li>It's so easy, even I can do it</li><br />       
      </ul>
      </td>
    </tr>
    <tr>
      <td class="code">
              <? highlight_string($block1); ?>
      </td>
    </tr>
    <tr>
      <td>
      <ul>
        <li>Load a string or file into SimpleXML</li>
        <li>Then you can act on the object using SimpleXML methods, looping through the nodes or using XPATH</li>
        <li>In our case we want to rebuild the object into an array so we can normalize the data from the different XML files, access it in a variety of ways and place parts on it in DB</li><br />    
      </ul>
      </td>
    </tr>   
    <tr>
      <td class="code">
               <? highlight_string($block2); ?>
      </td>
    </tr>  
    <tr>
      <td>
      <ul>
        <li>Some limitations exist, and some functionality needs to be added to SimpleXML</li>
        <li>But if you know the Schema, it's fast and easy to build out classes to build any structure you need to work with</li>
        <li>You can also easily work directly with the SimpleXML object</li><br />    
      </ul>
      </td>
    </tr>      
</table>