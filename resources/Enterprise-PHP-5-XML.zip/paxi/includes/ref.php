<table width="100%">
    <tr>
      <td>
      <ul>
        <li>PHP/Javascript: http://www.webxpertz.net/faqs/jsfaq/jsserver.php</strong></li>                 
      </ul>
      </td>
    </tr>

</table>
    