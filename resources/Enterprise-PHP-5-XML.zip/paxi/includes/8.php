

<table width="100%">
    <tr>
      <td>
      <ul>
              <li><strong>PHP 5 Response XML Processing</strong></li><br />
                  <ul>
                    <li>pMIME accepts a file descriptor (in this case a network socket from the SOAP server) and determines the structure of the incoming MIME/SOAP packet in real-time</li><br />
                   </ul>
      </ul>
    <tr>
      <td class="code">
                    <? highlight_string("<?php

\$responseparser = new pMIME;
\$responseparser->Incoming(\$soapfp);

?>");?>
    </td>
    </tr>
    <tr>
      <td>
        <ul>
          <ul>
                    <ul>
                        <li>pMIME is lightweight and fast, keeping only a single copy of the data.  Structure is retained by use of an array of integers</li>
                        <li>Particular MIME entities and header fields can be examined.  SESSIONID was important for transactional integrity</li><br />
                    </ul>
          </ul>
        </ul>
      </td>
    </tr>
    <tr>
      <td class="code">
                                            <? highlight_string("<?php
                                            
\$responseparser->setHeaderPart(0);
\$responseparser->setField('Set-Cookie',TRUE);
if( \$responseparser->isParameter('SESSIONID') )
  \$REQUEST_SESSIONID = \$responseparser->parseField('SESSIONID');
		 else
  \$REQUEST_SESSIONID = NULL;

?>");?>
      </td>
    </tr>
    <tr>
      <td>
        <ul><ul>
                <li>Extracted XML is passed to SimpleXML routines for XML parsing and manipulation</li><br />
                  </ul>
       </ul>
          
      </td>
    </tr>
    <tr>
      <td class="code">
 <? highlight_string("<?php
 
\$xmlresponse_array = XMLResponseParser(\$responseparser->fetchPart(5);

?>");?>                 
      </td>
    </tr> 
</table>