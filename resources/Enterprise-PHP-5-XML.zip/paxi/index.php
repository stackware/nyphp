<?

include('includes/config.inc');

if (isset($_GET['slide'])) {

  if ( $_GET['slide']>0 && $_GET['slide']<=$totalSlides ) {
  
    $slideNumber = $_GET['slide'];
    
    } else $slideNumber = 0;
    
} else $slideNumber = 0;

include ('includes/header.inc');

if ($slideNumber<>$totalSlides) {    
include ("includes/$slideNumber.php");
} else include ('includes/toc.php');

include ('includes/footer.inc');

?>