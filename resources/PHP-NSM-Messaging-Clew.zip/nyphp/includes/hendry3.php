<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td>
<h2>How to get involved</h2>
<ul>
  <li>Continue to attend monthly meetings and participate on the <a href="http://www.nyphp.org/content/mailinglist/mlist.php">mailing lists</a>.</il>
  <li>Contact a <a href="http://clew.nyphp.org/clew">Department</a> to become more involved in any one of the four Departments to which you feel you are best suited.</il>  
  <li>Let your Department head know that you are available to help with any future or ongoing Projects.</il>    
  <li>Attend the Development meetings.</il>      
</ul> 
</td></tr></table>