<head>
<title>Project Proposal Slides</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<style>
<!--
body,td,a{font-family:verdana,sans-serif;font-size:14px;}
TD.headTitle{font-size:18px;font-weight:bold;}
TD.acronym{font-size:18px;font-weight:bold;color:#999999;}
TABLE.header {background-color:#ffffff; border-collapse: collapse; border-style : solid; border-width: 0px 0px 1px 0px; border-color : #999999;}
TABLE.nav {height:25px;background-color:#cccccc;color: black;font-weight:bold; border-collapse: collapse; border-style : solid; border-width: 0px 0px 1px 0px; border-color : #999999;}
a.navLink {color: black;font-weight:bold;text-decoration:none;font-size:12px;}
a.navLinkW {color: #999999;font-weight:bold;text-decoration:none;font-size:12px;}
a.external {text-decoration:underline;color:#006600;}
TABLE.body {background-color:white; border-collapse: collapse; border-style : solid; border-width: 0px 0px 1px 0px; border-color : #999999;}
TD.content {padding:20px;}
TD.code {padding:20px;background-color:#efefef; border-collapse: collapse; border-style : solid; border-width: 1px; border-color : #666666; }
LI {padding-top:20px;}
//-->
</style>
<body>
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <h2><strong>Introduction - Project Proposal Process</strong></h2>
      <ul>
        <li><strong>Project Coordinator: </strong>Hans Kaspersetz, Hans.Kaspersetz
        at NYPHP.org</li>
        <li>Projects are the heart of New York PHP's activities</li>
        <li>Guidelines for the submission and review of Project
        Proposals</li>
      </ul>
      <br>

      <h3><strong>Objectives</strong></h3>
      <ul>
        <li>To fairly review all Project Proposals for merit and feasibility
        </li>
        <li>To collect all necessary information about a project and determine
          its needs, man power and technology.
        </li>
        <li>To find a home at NY PHP for accepted projects, projects must have
          a sponsoring department and project manager</li>
      </ul><br>

      <h3><strong>Who should submit a Project Proposal?</strong></h3>
      <ul>
        <li>Anyone who wants to put the NY PHP community of developer to work
          on an interesting problem or piece of software that will benefit the
          php community.</li>
      </ul>
    </td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td>
     <h2>How do I Submit a Project Proposal?</h2>
      <ul>
        <li>Project Proposal Instructions, Guidelines and Forms are available
          online.<br />
        </li>
        <li><strong>http://clew.nyphp.org/clew/operations/newproposals</strong><br />
        </li>
        <li>Complete the Project Proposal Form located online<br />
        </li>
        <li><strong>http://clew.nyphp.org/clew/operations/newproposals/projectproposalform</strong></li>
        <li>Email the completed form to Hans.Kaspersetz at NYPHP.org</li>
        <li><strong>Project Proposal Form</strong><br />
            <br />
            <table width="100%" border="1" cellspacing="0" cellpadding="0">
              <tr>
                <td class="code">&lt;h1&gt;{Project Title (required)}&lt;/h1&gt;<br />
&lt;h3&gt;{Proposal Date (required)}&lt;/h3&gt;
          <p>&lt;h3&gt;Project Summary&lt;/h3&gt;<br />
            {summary description - one sentence or less (required)}</p>
          <p>&lt;h3&gt;Project Manager&lt;/h3&gt;<br />
            {Principal's Name (optional)}&lt;br /&gt;<br />
            {Principal's Email (optional)}&lt;br /&gt;<br />
            {Principal's Department (optional)}&lt;br /&gt;<br />
            {Principal's Phone (optional)}</p>
          <p>&lt;h4&gt;Submitted by&lt;/h4&gt;<br />
            {Name (required)}&lt;br /&gt;<br />
            {Organization (optional)}&lt;br /&gt;<br />
            &lt;private&gt;{Email (required)}&lt;/private&gt;&lt;br /&gt;<br />
            &lt;private&gt;{Phone (required)}&lt;/private&gt;</p>
          <p>&lt;h4&gt;Sponsoring Department&lt;/h4&gt;<br />
            {Department (optional)}</p>
          <p>&lt;h4&gt;Status&lt;/h4&gt;<br />
&lt;p&gt;{Leave Blank}&lt;/p&gt;</p>
          <p>&lt;h4&gt;Detailed Description&lt;/h4&gt;<br />
            {include as much detail as possible about the goals of the project}</p>
          <p>&lt;h4&gt;Timeline for Development&lt;/h4&gt;<br />
            {estimated length to completion (optional)}&lt;br /&gt;<br />
            {list some significant milestones (optional)}</p>
          <p>&lt;h4&gt;Required Human Resources&lt;/h4&gt;<br />
            {list assumed human resources; ie, programmers, designers, authors
              (optional)}</p>
          <p>&lt;h4&gt;Required Technical Resources&lt;/h4&gt;<br />
            {list assumed technical resources, if applicable; ie, CVS, servers,
              mailing lists (optional)}</p>
          <p>&lt;h4&gt;Supplied Resources&lt;/h4&gt;<br />
            {list any resources that will be provided, if applicable; ie, servers,
              pre-existing software/components, wireframes (required)}</p>
          <p>&lt;h4&gt;Software License&lt;/h4&gt;<br />
            {if applicable (optional)}</p>
                </td>
              </tr>
            </table>
        </li>
        <li><strong> Required fields include:</strong> Project Title, Proposal Date, Project
        Summary, Name, Email, Phone, Detailed Description, and Supplied Resources</li>
        <li><strong>Optional
            fields include:</strong> Timeline for Development, Required Human Resources,
            Required Technical Resources, and Software License.<br />
          <br />
            </li>
      </ul>
    </td>
  </tr>
</table>
<p>&nbsp;  </p>
<table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <h2>Project Proposal Review Process</h2>
      <ul>
        <li>  Proposal is reviewed for completeness and merit by Project Coordinator.</li>
        <li>Proposal is posted to Clew as a new proposal and the VPs and submitter
          are notified</li>
        <li>Project's status updated to: Under Review</li>
        <li>The VPs will confer and either request more information or make a
          determination</li>
        <li>Possible outcomes are</li>
        <ul>
			<li><strong>Approved:</strong> Projects that have a department and project manager. The projects
		  will be transferred to the appropriate node.</li>
		    <li> <strong>Postponed:</strong> Proposals
			    that lacked the needed support from the board. These proposals
		      remain the responsibility of the Project Coordinator
		     and should have a review date set for them.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       </li>
            <li> <strong>Rejected: </strong>Proposals
		         not approved by the board. These proposals are tagged as
              such and no further action is planned.</li>
        </ul>
        <li>If your Proposal is accepted you will be notified by email and further
          action will be planned by your project manager.</li>
        <li>All questions and proposals should be emailed to <strong>Hans.Kaspersetz
          at NYPHP.org</strong></li>
      </ul>
    </td>
  </tr>
 </table>

</body>
</html>
