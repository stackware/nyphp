<h2>Messages and Resources</h2>
<em>Clew Ties Messages to Web Resources</em>
<h4>Messages Are Auto-named Nodes</h4>
<ul>
  <li>Messages are organized into threads. A thread is referenced by its first Message parent.</li>
  <li>New Messages are broadcast to Subscribers</li>
  <li>Message as in Message Board</li>
</ul>
<h4>Resources Are Human-named Nodes</h4>
<ul>
  <li>Resources act like web documents with associated mailing lists</li>
  <li>New Resources are *not* broadcast</li>
  <li>Resource as in Uniform Resource Locator</li>
</ul>