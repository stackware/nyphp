<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td>
<h3>The Re-organization of New York PHP</h3>
To support the growth of both the organization and the community that it supports, New York PHP is re-structuring.  To allow for more participation by its members and to take on more open-source projects, New York PHP is decentralizing into four distinct but cooperative Departments.
<ul>
<li><a href="http://clew.nyphp.org/clew/operations">Operations</a></li>
  <ul>
    <li>Providing organizational support to New York PHP and acting as a liason to outside groups, vendors and speakers.</li>
    <li>Planning and organizing meetings and events.</li>
    <li>Shepharding new projects through the submittal process.</li>
    <li>Working with Media Department to maintain websites.</li>
  </ul>
<li><a href="http://clew.nyphp.org/clew/education">Education</a></li>
  <ul>
    <li>Forming, maintaining, and developing an educational strategy.</li>
    <li>Overseeing educational programs, courses and materials for the AMP community.</li>    
    <li>Providing general oversight and leadership in all educational areas.</li>        
  </ul>
<li><a href="http://clew.nyphp.org/clew/media">Media</a></li>
  <ul>
    <li>Providing general oversight for creation, review, and editing of all New York PHP content.</li>
    <li>Developing graphical, layout and design elements for digital or paper media.</li>    
    <li>Writing and maintaining meeting/event abstracts, announcements, summaries and newsletter.</li>            
  </ul>
<li><a href="http://clew.nyphp.org/clew/development">Research & Development</a></li>
  <ul>
    <li>Providing technical support and guidance.</li>
    <li>Providing software, server and infrastructure development.</li>    
    <li>Developing innovative technical solutions to support Departments and Projects (Clew).</li>            
    <li>General oversight and management of all technical areas.</li>                
  </ul> 
</ul> 
</td></tr></table>
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td>
<h3>Where do you fit in?</h3>
New York PHP takes a collaborative and consesus oriented approach using the following general structure:
<ul>
<li>Board of Directors</li>
  <ul>
    <li>Made up of the President (Hans Zaunere) and the Vice President of each Department.</li>
  </ul>
<li>Department</li>
  <ul>
    <li>A Department is comprised of two or more Principals who work together and share related skills and interest to carry out Projects and other associated tasks.</li>                
  </ul>
<li>Vice President</li>
  <ul>
    <li>Elected from the members of a Department, the Vice President's duties including managing their Department and represnting it on the Board of Dierctors.</li>                
  </ul>
<li>Principal</li>
  <ul>
    <li>Any Associate demonstrating ongoing participation in New York PHP, and an association with a particular Department.</li>                
  </ul>       
<li>Project Manager</li>
  <ul>
    <li>Seleted on a volunteer basis per Project.  The Project Manager is responsible for their Project's successful conclusion.</li>        
  </ul>
<li>Project</li>
  <ul>
    <li>A Project is a goal overseen by a Department and directly managfed by a Project Manager.  Projects can either be directly technical or indirectly technical in nature.</li>        
  </ul>  
<li>Associate</li>
  <ul>
    <li>Any person subscribing to and participating in New York PHP mailing lists, but not otherwise participating on an ongoing basis.</li>            
  </ul>    
</ul> 
</td></tr></table>
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td>
<h3>How to get involved</h3>
<ul>
  <li>Continue to attend monthly meetings and participate on the <a href="http://www.nyphp.org/content/mailinglist/mlist.php">mailing lists</a>.</il>
  <li>Contact a <a href="http://clew.nyphp.org/clew">Department</a> to become more involved in any one of the four Departments to which you feel you are best suited.</il>  
  <li>Let your Department head know that you are available to help with any future or ongoing Projects.</il>    
  <li>Attend the Development meetings.</il>      
</ul> 
</td></tr></table>