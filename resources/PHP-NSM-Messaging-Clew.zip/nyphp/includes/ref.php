<table>
  <tr>
    <td>
<ul>
  <li>Clew Homepage: <a href="http://clew.nyphp.org/clew/clew" class="external">http://clew.nyphp.org/clew/clew</a></li>
  <li>Clew Source Code: <a href="http://cvs.nyphp.org" class="external">http://cvs.nyphp.org</a></li>    
  <li>New York PHP Department Listings: <a href="http://clew.nyphp.org/clew/" class="external">http://clew.nyphp.org/clew/</a></li>    
  <li>New York PHP Project Proposal: <a href="http://clew.nyphp.org/clew/operations/newproposals" class="external">http://clew.nyphp.org/clew/operations/newproposals</a></li>      
  <li>New York PHP Mailing Lists: <a href="http://www.nyphp.org/content/mailinglist/mlist.php" class="external">http://www.nyphp.org/content/mailinglist/mlist.php</a></li>        
  <li>New York PHP PHundamentals: <a href="http://phundamentals.nyphp.org/" class="external">http://phundamentals.nyphp.org/</a></li>            
  <li>New York PHP Training: <a href="http://www.nyphp.org/content/training/" class="external">http://www.nyphp.org/content/training/</a></li>               
</ul>    
    
    </td>
  </tr>
</table>