<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
     <h2>How do I Submit a Project Proposal?</h2>
      <ul>
        <li>Project Proposal Instructions, Guidelines and Forms are available
          online.<br />
        </li>
        <li><strong>http://clew.nyphp.org/clew/operations/newproposals</strong><br />
        </li>
        <li>Complete the Project Proposal Form located online<br />
        </li>
        <li><strong>http://clew.nyphp.org/clew/operations/newproposals/projectproposalform</strong></li>
        <li>Email the completed form to Hans.Kaspersetz at NYPHP.org</li>
        <li><strong>Project Proposal Form</strong><br />
            <br />
            <table width="90%" border="1" cellspacing="0" cellpadding="0">
              <tr>
                <td class="code">&lt;h1&gt;{Project Title (required)}&lt;/h1&gt;<br />
&lt;h3&gt;{Proposal Date (required)}&lt;/h3&gt;
          <p>&lt;h3&gt;Project Summary&lt;/h3&gt;<br />
            {summary description - one sentence or less (required)}</p>
          <p>&lt;h3&gt;Project Manager&lt;/h3&gt;<br />
            {Principal's Name (optional)}&lt;br /&gt;<br />
            {Principal's Email (optional)}&lt;br /&gt;<br />
            {Principal's Department (optional)}&lt;br /&gt;<br />
            {Principal's Phone (optional)}</p>
          <p>&lt;h4&gt;Submitted by&lt;/h4&gt;<br />
            {Name (required)}&lt;br /&gt;<br />
            {Organization (optional)}&lt;br /&gt;<br />
            &lt;private&gt;{Email (required)}&lt;/private&gt;&lt;br /&gt;<br />
            &lt;private&gt;{Phone (required)}&lt;/private&gt;</p>
          <p>&lt;h4&gt;Sponsoring Department&lt;/h4&gt;<br />
            {Department (optional)}</p>
          <p>&lt;h4&gt;Status&lt;/h4&gt;<br />
&lt;p&gt;{Leave Blank}&lt;/p&gt;</p>
          <p>&lt;h4&gt;Detailed Description&lt;/h4&gt;<br />
            {include as much detail as possible about the goals of the project}</p>
          <p>&lt;h4&gt;Timeline for Development&lt;/h4&gt;<br />
            {estimated length to completion (optional)}&lt;br /&gt;<br />
            {list some significant milestones (optional)}</p>
          <p>&lt;h4&gt;Required Human Resources&lt;/h4&gt;<br />
            {list assumed human resources; ie, programmers, designers, authors
              (optional)}</p>
          <p>&lt;h4&gt;Required Technical Resources&lt;/h4&gt;<br />
            {list assumed technical resources, if applicable; ie, CVS, servers,
              mailing lists (optional)}</p>
          <p>&lt;h4&gt;Supplied Resources&lt;/h4&gt;<br />
            {list any resources that will be provided, if applicable; ie, servers,
              pre-existing software/components, wireframes (required)}</p>
          <p>&lt;h4&gt;Software License&lt;/h4&gt;<br />
            {if applicable (optional)}</p>
                </td>
              </tr>
            </table>
        </li>
        <li><strong> Required fields include:</strong> Project Title, Proposal Date, Project
        Summary, Name, Email, Phone, Detailed Description, and Supplied Resources</li>
        <li><strong>Optional
            fields include:</strong> Timeline for Development, Required Human Resources,
            Required Technical Resources, and Software License.<br />
          <br />
            </li>
      </ul>
    </td>
  </tr>
</table>