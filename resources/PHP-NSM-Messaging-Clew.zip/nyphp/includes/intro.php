<ul>
<li><h1>Conversationally Linked Email and other Writings</h1><br />
<em><u>Clew</u>: from the Middle English 'clewe' and the Old English 'cliewen' is commonly used to refer to a "ball of thread". Because in myth and literature balls of thread were used to escape from labyrinths (most notably in the story of Theseus and the Minotaur) 'clew' has come to mean anything that can be used to guide someone through a difficult place or problem-as in a 'clew' which solves a mystery.
</em></li>
<li><h1>The New New York PHP</h1><br />A brief discussion on the re-organization of New York PHP to better support the growing community.</li>
<li><h1>The Project Proposal Process</h1><br />Got an open-source project idea?  Learn how to submit your project for consideration by New York PHP.</li>
</ul>