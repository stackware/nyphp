<h2>What Is Clew?</h2>
<em>An Open Source Project Sponsored By NYPHP R&amp;D</em>
<h4>Development Goals</h4>
<ul>
  <li>Mailing list manager</li>
  <li>Online message archive</li>
  <li>Document management system</li>
</ul>
<h4>Research Goals</h4>
<ul>
  <li>PHP/MySQL implementation of a nested set storage engine</li>
  <li>What happens when you can create arbitrary threads of PHP objects?</li>
  <li>What are the pros and cons of such a system in everyday use?</li>
</ul>