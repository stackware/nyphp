<table>
<tr>
<td>
<ol>
<? $count = 0; foreach($slideName as $name) { ?>
<li><a href="<?=$_SERVER['PHP_SELF']?>?slide=<?=$count?>" class="external"><?=$title[$name]?></a></li>
<? ++$count; } ?>
</ol>
</td>
</tr>
</table>