<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <h2>Project Proposal Review Process</h2>
      <ul>
        <li>Proposal is reviewed for completeness and merit by Project Coordinator.</li>
        <li>Proposal is posted to Clew as a new proposal and the VPs and submitter
          are notified</li>
        <li>Project's status updated to: Under Review</li>
        <li>The VPs will confer and either request more information or make a
          determination</li>
        <li>Possible outcomes are</li>
        <ul>
			<li><strong>Approved:</strong> Projects that have a department and project manager. The projects
		  will be transferred to the appropriate node.</li>
		    <li> <strong>Postponed:</strong> Proposals
			    that lacked the needed support from the board. These proposals
		      remain the responsibility of the Project Coordinator
		     and should have a review date set for them.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       </li>
            <li> <strong>Rejected: </strong>Proposals
		         not approved by the board. These proposals are tagged as
              such and no further action is planned.</li>
        </ul>
        <li>If your Proposal is accepted you will be notified by email and further
          action will be planned by your project manager.</li>
        <li>All questions and proposals should be emailed to <strong>Hans.Kaspersetz
          at NYPHP.org</strong></li>
      </ul>
    </td>
  </tr>
 </table>