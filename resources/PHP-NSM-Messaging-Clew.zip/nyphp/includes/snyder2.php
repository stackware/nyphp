<h2>Nodes and the Nested Set Model</h2>
<em>Clew Ties Nodes into Threads</em>
<h4>The Nested Set Explained</h4>
<pre>
                    node1 (1,14)
                    /   |      \
                  /     |       \
                /       |        \
              /         |         \
    node2 (2,3)    node3 (4,11)    node5 (12,13)
                   /    |   \
                 /      |     \
               /        |       \
             /          |         \
        node4 (5,6)  node6 (7,8)  node7 (9,10)
</pre>
<h4>The Database</h4>
<pre>
CREATE TABLE IF NOT EXISTS `pnsm` ( 
  `pnsmid` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
  `pnsml` INT UNSIGNED, 
  `pnsmpl` INT UNSIGNED, 
  `pnsmr` INT UNSIGNED ) Type=MyISAM;

CREATE TABLE IF NOT EXISTS `node` ( 
  `pnsmid` INT UNSIGNED PRIMARY KEY, 
  `uid` INT UNSIGNED, 
  `gid` INT UNSIGNED, 
  `created` DATETIME, 
  `status` ENUM('new', 'active', 'deleted') NOT NULL, 
  `type` VARCHAR(64), 
  `name` VARCHAR(64) NOT NULL, 
  `title` VARCHAR(255), 
  `content` TEXT, 
  `properties` TEXT, 
  INDEX `ix_uid` (`uid`), 
  INDEX `ix_gid` (`gid`), 
  INDEX `ix_status` (`status`), 
  INDEX `ix_type` (`type`), 
  UNIQUE `uk_name` (`name`), 
  FULLTEXT INDEX `ft_content` (`content`) ) Type=MyISAM;
</pre>