<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td>
<h2>The Re-organization of New York PHP</h2><br />
To support the growth of both the organization and the community that it supports, New York PHP is re-structuring.  To allow for more participation by its members and to take on more open-source projects, New York PHP is decentralizing into four distinct but cooperative Departments.
<ul>
<li><a class="external" href="http://clew.nyphp.org/clew/operations">Operations</a></li>
  <ul>
    <li>Providing organizational support to New York PHP and acting as a liason to outside groups, vendors and speakers.</li>
    <li>Planning and organizing meetings and events.</li>
    <li>Shepharding new projects through the submittal process.</li>
    <li>Working with Media Department to maintain websites.</li>
  </ul>
<li><a class="external" href="http://clew.nyphp.org/clew/education">Education</a></li>
  <ul>
    <li>Forming, maintaining, and developing an educational strategy.</li>
    <li>Overseeing educational programs, courses and materials for the AMP community.</li>    
    <li>Providing general oversight and leadership in all educational areas.</li>        
  </ul>
<li><a class="external" href="http://clew.nyphp.org/clew/media">Media</a></li>
  <ul>
    <li>Providing general oversight for creation, review, and editing of all New York PHP content.</li>
    <li>Developing graphical, layout and design elements for digital or paper media.</li>    
    <li>Writing and maintaining meeting/event abstracts, announcements, summaries and newsletter.</li>            
  </ul>
<li><a class="external" href="http://clew.nyphp.org/clew/development">Research & Development</a></li>
  <ul>
    <li>Providing technical support and guidance.</li>
    <li>Providing software, server and infrastructure development.</li>    
    <li>Developing innovative technical solutions to support Departments and Projects (Clew).</li>            
    <li>General oversight and management of all technical areas.</li>                
  </ul> 
</ul> 
</td></tr></table>