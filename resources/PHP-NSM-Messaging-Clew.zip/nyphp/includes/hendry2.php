<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td>
<h2>Where do you fit in?</h2><br />
New York PHP takes a collaborative and consesus oriented approach using the following general structure:
<ul>
<li>Board of Directors</li>
  <ul>
    <li>Made up of the President (Hans Zaunere) and the Vice President of each Department.</li>
  </ul>
<li>Department</li>
  <ul>
    <li>A Department is comprised of two or more Principals who work together and share related skills and interest to carry out Projects and other associated tasks.</li>                
  </ul>
<li>Vice President</li>
  <ul>
    <li>Elected from the members of a Department, the Vice President's duties including managing their Department and represnting it on the Board of Dierctors.</li>                
  </ul>
<li>Principal</li>
  <ul>
    <li>Any Associate demonstrating ongoing participation in New York PHP, and an association with a particular Department.</li>                
  </ul>       
<li>Project Manager</li>
  <ul>
    <li>Seleted on a volunteer basis per Project.  The Project Manager is responsible for their Project's successful conclusion.</li>        
  </ul>
<li>Project</li>
  <ul>
    <li>A Project is a goal overseen by a Department and directly managfed by a Project Manager.  Projects can either be directly technical or indirectly technical in nature.</li>        
  </ul>  
<li>Associate</li>
  <ul>
    <li>Any person subscribing to and participating in New York PHP mailing lists, but not otherwise participating on an ongoing basis.</li>            
  </ul>    
</ul> 
</td></tr></table>