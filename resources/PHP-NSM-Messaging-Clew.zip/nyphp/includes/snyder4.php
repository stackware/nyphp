<h2>The Clew PHP Classes</h2>
<em>Clew Is A Communication Framework</em>
<ul>
  <li>clewRequest discovers the request and server environment</li>
  <li>clewAuth (extends pauth) handles PHP-Session, authentication, and roles-based authorization</li>
  <li>clewNode (extends pNSM) provides an interface to the node and pnsm tables</li>
  <li>clewTemplate includes PHP scripts from a template path to create the response</li>
  <li>also several helper classes: pauthmin, pmime, clewSubscription</li>
</ul>