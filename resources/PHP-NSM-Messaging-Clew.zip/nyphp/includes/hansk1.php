<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <h2><strong>Introduction - Project Proposal Process</strong></h2>
      <ul>
        <li><strong>Project Coordinator: </strong>Hans Kaspersetz, Hans.Kaspersetz
        at NYPHP.org</li>
        <li>Projects are the heart of New York PHP's activities</li>
        <li>Guidelines for the submission and review of Project
        Proposals</li>
      </ul>
      <br>

      <h3><strong>Objectives</strong></h3>
      <ul>
        <li>To fairly review all Project Proposals for merit and feasibility
        </li>
        <li>To collect all necessary information about a project and determine
          its needs, man power and technology.
        </li>
        <li>To find a home at NY PHP for accepted projects, projects must have
          a sponsoring department and project manager</li>
      </ul><br>

      <h3><strong>Who should submit a Project Proposal?</strong></h3>
      <ul>
        <li>Anyone who wants to put the NY PHP community of developer to work
          on an interesting problem or piece of software that will benefit the
          php community.</li>
      </ul>
    </td>
  </tr>
</table>