<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing Zend Studio (cont.)</h1>
   <ul>
      <li>Server Options</li>
      <ul>
         <li>Apache</li>
         <li>Use existing PHP setup</li>
         <li>Detection of PHP version from a PHP binary</li>
         <li>Allow access from other hosts:</li>
         <ul>
            <li>No</li>
         </ul>
         <li>Enable register_globals:</li>
         <ul>
            <li>No</li>
         </ul>
      </ul>
   </ul>
   <h2>ZendStudioServer-2.5.0c-Windows-i386.exe</h2>
</div>

<?=slidefooter()?>