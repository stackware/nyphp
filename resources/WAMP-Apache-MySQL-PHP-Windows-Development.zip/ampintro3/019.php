<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Creating Virtual Hosts (cont.)</h1>
   <pre>
      <?=htmlentities('
      <VirtualHost *>
         DocumentRoot "c:\sites\foo.localhost"
         ServerName foo.localhost
         php_value auto_prepend_file "c:\sites\foo.localhost\prepend.inc"
      </VirtualHost>

      <VirtualHost *>
         DocumentRoot "c:\sites\bar.localhost"
         ServerName bar.localhost
      </VirtualHost>');?>
   </pre>
</div>

<?=slidefooter()?>