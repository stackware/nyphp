<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Creating Virtual Hosts</h1>
   <ul>
      <li>In httpd.conf:</li>
   </ul>
   <pre>
      <?=htmlentities('
      <VirtualHost *>
         DocumentRoot "c:\sites\nyphp.localhost"
         ServerName nyphp.localhost
      </VirtualHost>');?>
   </pre>
</div>

<?=slidefooter()?>