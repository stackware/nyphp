<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing Apache (cont.)</h1>
   <div align=center><img size="50%" src="slide7.gif"></div>
</div>

<?=slidefooter()?>