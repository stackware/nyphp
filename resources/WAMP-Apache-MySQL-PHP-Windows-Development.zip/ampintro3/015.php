<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing Zend Studio (cont.)</h1>
   <ul>
      <li>Client Options</li>
      <ul>
         <li>Zend Studio Server address: localhost</li>
      </ul>
   </ul>
   <h2>ZendStudio-2_5_0.exe</h2>
</div>

<?=slidefooter()?>