<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing Zend Studio (cont.)</h1>
   <div align=center><img src="slide14.gif"></div>
</div>

<?=slidefooter()?>