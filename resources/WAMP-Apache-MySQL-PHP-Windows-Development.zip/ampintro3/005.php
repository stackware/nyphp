<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing Apache (cont.)</h1>
   <div align=center><img src="slide5.gif"></div>
</div>

<?=slidefooter()?>