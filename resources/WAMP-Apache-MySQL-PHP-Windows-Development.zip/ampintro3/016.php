<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing MySQL</h1>
   <ul>
      <li>Run SETUP.EXE</li>
      <li>Choose typical setup</li>
      <li>Start > Run > c:\mysql\bin\winmysqladmin.exe</li>
      <li>Start > Run > cmd</li>
      <li>cd c:\mysql\bin</li>
      <li>mysql</li>
   </ul>
</div>

<?=slidefooter()?>