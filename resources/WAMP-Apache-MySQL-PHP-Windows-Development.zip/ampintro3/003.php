<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing Apache</h1>
   <ul>
      <li>.msi File (Windows Installer Package)</li>
   </ul>
   <div align=center><img src="slide3.gif"></div>
</div>

<?=slidefooter()?>