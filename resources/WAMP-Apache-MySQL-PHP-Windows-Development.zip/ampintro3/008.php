<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing PHP</h1>
   <ul>
      <li>Download .ZIP file from PHP.net or Zend.com</li>
      <li>Unzip to C:\PHP</li>
      <li>Copy file php4ts.dll to c:\winnt\system32\</li>
      <li>Copy file php.ini-recommended to c:\winnt\php.ini</li>
      <li>Edit php.ini by adding the line:</li>
      <ul>
         <li>extension_dir ="c:\php"</li>
      </ul>
      <li>Edit httpd.conf file by adding the lines:</li>
      <ul>
         <li>LoadModule php4_module c:/php/sapi/php4apache.dll</li>
         <li>AddModule mod_php4.c</li>
         <li>AddType application/x-httpd-php .php</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>