<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Overview (cont.)</h1>
   <ul>
      <li>Creating Virtual Hosts</li>
      <li>Virtual Host PHP Configuration</li>
      <li>Mapping IP addresses to host names</li>
      <li>Using the Zend Studio Project Management</li>
   </ul>
</div>

<?=slidefooter()?>