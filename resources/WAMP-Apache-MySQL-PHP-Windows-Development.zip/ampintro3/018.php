<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Creating Virtual Hosts (cont.)</h1>
   <ul>
      <li>Create directory in file system</li>
      <li>Edit C:\WINNT\system32\drivers\etc\host</li>
      <li>Restart Apache and close all browsers</li>
      <li>http://nyphp.localhost/ (oops)</li>
      <li>Update DirectoryIndex in httpd.conf</li>
      <li>Restart Apache</li>
   </ul>

</div>

<?=slidefooter()?>