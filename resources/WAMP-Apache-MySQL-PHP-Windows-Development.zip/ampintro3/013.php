<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing Zend Studio (cont.)</h1>
   <ul>
      <li>phpinfo();</li>
   </ul>
</div>

<?=slidefooter()?>