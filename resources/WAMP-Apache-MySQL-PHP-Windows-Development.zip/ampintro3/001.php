<?php
// javascript:window.alert('Width: ' + window.innerWidth + ' Height: ' + window.innerHeight);

require_once('ampintro3.inc');

?>

<div class=slidebody>
   <h1>Overview</h1>
   <ul>
      <li>Installing Apache</li>
      <li>Installing PHP</li>
      <li>Installing Zend Studio</li>
      <li>Installing MySQL</li>
   </ul>
</div>

<?=slidefooter()?>