<?php

require_once('ampintro3.inc');

?>


<div class=slidebody>
   <h1>Installing Zend Studio</h1>
   <ul>
      <li>Details and trial available at <a target=_blank href="http://zend.com/store/products/zend-studio.php">Zend</a></li>
      <li>NYPHP members get <b>50%</b> discount!</li>
      <li>Client:</li>
      <ul>
         <li>IDE and local debugging</li>
      </ul>
      <li>Server:</li>
      <ul>
         <li>Apache, PHP and remote debugging</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>