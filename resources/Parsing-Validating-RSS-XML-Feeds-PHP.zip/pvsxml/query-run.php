<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>/**
 * Executes the query string provided.
 *
 * &lt;p&gt;Errors from attempts to create records with duplicate keys are ignored.
 * Minor errors generate an email.  Major errors shut down ST Parser.&lt;/p&gt;
 *
 * @param   string    $Query  the query string to execute
 */
function runQuery($Query) {
    $Result =&amp; $this-&gt;db-&gt;query($Query);

    if ( DB::isError($Result) ) {
        switch ( $Result-&gt;getMessage() ) {
            case 'DB Error: already exists':
                //  Generally means key duplicate.  No problem.
                break;

            case 'DB Error: syntax error':
            case 'DB Error: invalid':
            case 'DB Error: invalid date or time':
            case 'DB Error: invalid number':
                $this-&gt;Probs[] = $Result-&gt;getMessage() . &quot;\n&quot; . $this-&gt;db-&gt;last_query;
                break;

            default:
                $this-&gt;killProcess($Result-&gt;getMessage() . &quot;\n&quot; . $this-&gt;db-&gt;last_query);
        }
    }
}
</pre>

<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
