<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();


#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<ul>
<li class="main">Examines file linearly</li>
<li class="main">Each step type handled by a related user defined function
    <ul>
    <li class="main">Start-tag</li>
    <li class="main">Character Data</li>
    <li class="main">End-tag</li>
    <li class="main">etc...</li>
    </ul>
</li>
<li class="main">Concepts for programming a parser
    <ul>
    <li class="main">Produce the user defined functions</li>
    <li class="main">Obtain data</li>
    <li class="main">Declare the parser</li>
    <li class="main">Pass data to parser</li>
    </ul>
</li>
</ul>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
