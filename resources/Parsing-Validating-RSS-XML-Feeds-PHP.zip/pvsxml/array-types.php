<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '
 table.courier {font-size: 10pt; font-family: "courier new", courier, monospace; margin-bottom: 2em}
 caption {font-size: 15pt; font-family: sans-serif; font-weight: bold; margin-bottom: 0.5em}
 p {margin-bottom: -1em}
';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<table class="courier" border="4" cellpadding="4">
 <caption class="maroon">STP_DataTypes</caption>
 <tr><th>DataTypeID</th><th>RegularExpression</th></tr>
 <tr><td>Alpha10</td><td>/^[\w-]{1,10}$/</td></tr>
 <tr><td>Int2</td><td>/^\d{1,2}$/</td></tr>
 <tr><td>Int3Neg</td><td>/^-\d{1,2}|\d{1,3}$/</td></tr>
</table>

<p class="maroon"><a name="types" id="types">$DataTypes</a></p>
<pre>    [Alpha10] =&gt; /^[\w-]{1,10}$/
    [Int2] =&gt; /^\d{1,2}$/
    [Int3Neg] =&gt; /^-\d{1,2}|\d{1,3}$/
</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
