<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<ul>

<li class="main"><a href="http://php.net/ref.xml">PHP XML Parser Documentation</a>
<br />php.net/ref.xml</li>

<li class="main"><a href="http://www.w3.org/TR/REC-xml">W3C Recommendation: Extensible Markup Language</a>
<br />www.w3.org/TR/REC-xml</li>

<li class="main"><a href="http://www.analysisandsolutions.com/">The Analysis and Solutions Company</a>
<br />www.analysisandsolutions.com/</li>

<li class="main"><a href="http://www.analysisandsolutions.com/code/phpxml.htm">PHP XML Parsing Basics -- A Tutorial</a>
<br />www.analysisandsolutions.com/code/phpxml.htm</li>

<li class="main"><a href="http://www.stparser.com/">ST Parser</a>
<br />www.stparser.com/</li>

<li class="main"><a href="http://www.sportsticker.com/ticker/">SportsTicker</a>
<br />www.sportsticker.com/ticker/</li>

</ul>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
