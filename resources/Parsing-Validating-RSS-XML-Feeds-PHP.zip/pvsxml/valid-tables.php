<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '
 table.courier {margin-bottom: 2em; font-size: 10pt; font-family: "courier new", courier, monospace}
 caption {font-size: 15pt; font-weight: bold; margin-bottom: 0.5em}
';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<table class="courier" border="4" cellpadding="4">
 <caption class="maroon">STP_DataTypes</caption>
 <tr><th>DataTypeID</th><th>RegularExpression</th></tr>
 <tr><td>Alpha10</td><td>/^[\w-]{1,10}$/</td></tr>
 <tr><td>Int2</td><td>/^\d{1,2}$/</td></tr>
 <tr><td>Int3Neg</td><td>/^-\d{1,2}|\d{1,3}$/</td></tr>
</table>

<table class="courier" border="4" cellpadding="4">
 <caption class="orange">STP_DataFields</caption>
 <tr><th>RootElement</th><th>ParentElement</th><th>DataField</th><th>DataTypeID</th></tr>
 <tr><td>NFLDSTAT</td><td>PRECORD</td><td>P_CODE</td><td>Alpha10</td></tr>
 <tr><td>NFLDSTAT</td><td>PRECORD</td><td>P_PUNTYDS</td><td>Int3Neg</td></tr>
 <tr><td>NFLBOXSCORE</td><td>LINESCORE</td><td>LINESCORE:QTR4</td><td>Int2</td></tr>
 <tr><td>NFLBOXSCORE</td><td>LINESCORE</td><td>LINESCORE:TEAMCODE</td><td>Alpha10</td></tr>
</table>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
