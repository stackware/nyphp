<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>
/**
 * Processes data between XML tags.
 *
 * &lt;p&gt;Places character data from the current XML element
 * into a temporary array, $this-&gt;CData.  The XML parser
 * automatically calls this function each time a new line
 * of data is found between element tags.  Don't call this
 * manually.&lt;/p&gt;
 *
 * &lt;p&gt;We temporarily store the data because some
 * elements have multiple lines of information but the XML
 * parser only remembers the current line.&lt;/p&gt;
 *
 * @param   mixed    $Parser  variable to contain the current parser's reference id
 * @param   mixed    <tt class="violet">$Line</tt>    variable to contain the present line's data
 */
function saxCharacterHandler(&amp;$Parser, &amp;<tt class="violet">$Line</tt>) {
    <tt class="red">if ($this-&gt;IgnoreTheRest == 'Y') {
        return;
    }</tt>
    <tt class="green">$this-&gt;CData[] = <tt class="violet">$Line</tt>;</tt>
}
</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
