<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>
/**
 * Processes XML end tags.
 *
 * &lt;p&gt;Determines what to do when we reach the end of each XML element.  The
 * XML parser automatically calls this function. Don't call this manually.&lt;/p&gt;
 *
 * @param   mixed    $Parser  variable to contain the current parser's reference id
 * @param   mixed    <tt class="pink">$Elem</tt>    variable to contain the current element's name
 */
function saxEndHandler(&amp;$Parser, &amp;<tt class="pink">$Elem</tt>) {

    <tt class="red">if ($this-&gt;IgnoreTheRest == 'Y') {
        return;
    }</tt>

    <tt class="green">$this-&gt;Data[<tt class="pink">$Elem</tt>] = trim( implode('', <a href="parse-char.php" class="green">$this-&gt;CData</a>) );</tt>

    <tt class="violet">switch (<tt class="pink">$Elem</tt>) {
        case 'PRECORD':</tt>
            <tt class="orange">if ( !<a href="valid-method.php" class="orange">$this-&gt;validateDataFields</a>(<tt class="pink">$Elem</tt>) ) {
                break;
            }</tt>

            <a href="query-run.php" class="black">$this-&gt;runQuery(</a> <a href="query-string.php" class="black">$this-&gt;qsStatNflGamePlayerD(</a>
                    $this-&gt;Data['P_CODE'],
                    $this-&gt;Data['P_PUNTYDS'] ) );

            <a href="unset.php" class="maroon">$this-&gt;unsetFields(<tt class="pink">$Elem</tt>);</a>
            break;

        <tt class="violet">case 'LINESCORE':</tt>
            <tt class="orange">if ( !<a href="valid-method.php" class="orange">$this-&gt;validateDataFields</a>(<tt class="pink">$Elem</tt>) ) {
                break;
            }</tt>

            <a href="query-run.php" class="black">$this-&gt;runQuery(</a> <a href="query-string.php" class="black">$this-&gt;qsStatNflLinescore(</a>
                    $this-&gt;Data['LINESCORE:TEAMCODE'],
                    $this-&gt;Data['LINESCORE:QTR4'] ) );

            <a href="unset.php" class="maroon">$this-&gt;unsetFields(<tt class="pink">$Elem</tt>);</a>
    <tt class="violet">}</tt>
    <tt class="blue">array_pop($this-&gt;ParentElements);</tt>
}</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
