<?php
$Title = 'Access Denied';
$Description = '';
$Keywords = '';
$Robots = 'noindex, noarchive';
$Style = '';

$File = __FILE__;
require('./directory.inc');

$Layout->Head();

?>


<p>This directory is not intended for public viewing.</p>


<?php
$Layout->Foot();
?>
