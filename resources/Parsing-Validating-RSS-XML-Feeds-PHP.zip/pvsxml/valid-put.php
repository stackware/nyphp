<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<pre>
/**
 * Establishes system settings.
 */
function getSettings() {

    <tt class="maroon">//  <a name="types" id="types">Data types.</a>

    $this-&gt;DataTypes = array();

    $this-&gt;DataTypes =&amp; $this-&gt;db-&gt;getAssoc( $this-&gt;qsDataTypeArray() );
    if ( DB::isError($this-&gt;DataTypes) ) {
        $this-&gt;killProcess('Having problems creating the DataTypes array.');
    }</tt>

    <tt class="orange">//  <a name="fields" id="fields">Data fields.</a>

    $this-&gt;DataFields = array();

    $Result =&amp; $this-&gt;db-&gt;query( $this-&gt;qsDataFieldArray() );
    if ( DB::isError($Result) ) {
        $this-&gt;killProcess('Having problems creating the DataFields array.');
    }

    while ( $Result-&gt;fetchInto($Temp) ) {
        // Create a three dimensional array.
        $this-&gt;DataFields[<b>$Temp['RootElement']</b>][<b>$Temp['ParentElement']</b>]
                [<b>$Temp['DataField']</b>] = <b>$Temp['DataTypeID']</b>;
    }</tt>
}
</pre>

<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
