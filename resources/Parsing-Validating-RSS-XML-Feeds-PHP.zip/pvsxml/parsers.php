<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<ul>
<li class="main">Event Based
    <ul>
    <li class="main">Goes through XML line by line</li>
    <li class="main">Read only</li>
    <li class="main">SAX &nbsp; <small>(<u>S</u>imple <u>A</u>PI for <u>X</u>ML)</small></li>
    </ul>
</li>
</ul>

<ul>
<li class="main">Tree Based
    <ul>
    <li class="main">Places entire XML document into memory</li>
    <li class="main">Can move around, read and (often) write</li>
    <li class="main">DOM XML &nbsp; <small>(<u>D</u>ocument <u>O</u>bject <u>M</u>odel)</small></li>
    <li class="main">SimpleXML</li>
    </ul>
</li>
</ul>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*
*/

$Layout->Foot();
?>
