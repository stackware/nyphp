<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '
 p {margin-bottom: -1em}
';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<p class="maroon"><a name="types" id="types">$DataTypes</a></p>

<pre>    [Alpha10] =&gt; /^[\w-]{1,10}$/
    [Int2] =&gt; /^\d{1,2}$/
    [Int3Neg] =&gt; /^-\d{1,2}|\d{1,3}$/
</pre>


<p class="orange"><a name="fields" id="fields">$DataFields</a></p>
<pre>    [NFLDSTAT] =&gt; Array
        (
            [PRECORD] =&gt; Array
                (
                    [P_CODE] =&gt; Alpha10
                    [P_PUNTYDS] =&gt; Int3Neg
                )
        )
    [NFLBOXSCORE] =&gt; Array
        (
            [LINESCORE] =&gt; Array
                (
                    [LINESCORE:QTR4] =&gt; Int2
                    [LINESCORE:TEAMCODE] =&gt; Alpha10
                )
        )
</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
