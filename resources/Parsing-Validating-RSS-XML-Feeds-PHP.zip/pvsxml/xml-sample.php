<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre><b class="red">&lt;?xml version=&quot;1.0&quot; standalone=&quot;no&quot; ?&gt;</b>
<b class="orange">&lt;!DOCTYPE NFLDSTAT SYSTEM &quot;NFLDSTAT.dtd&quot;&gt;</b>
<b class="green">&lt;NFLDSTAT&gt;</b>
    <b class="blue">&lt;DATE&gt;</b>2003-08-20<b class="blue">&lt;/DATE&gt;</b>
    <b class="violet">&lt;SOURCE office=&quot;NY&quot; /&gt;</b>
    &lt;PRECORD gender=&quot;M&quot;&gt;
        &lt;P_CODE&gt;<b class="pink">JOHNSONR</b>&lt;/P_CODE&gt;
        &lt;P_PUNTYDS&gt;53&lt;/P_PUNTYDS&gt;
    &lt;/PRECORD&gt;
    &lt;PRECORD <b class="maroon">gender=&quot;F&quot;</b>&gt;
        &lt;P_CODE&gt;DIFRANCOA&lt;/P_CODE&gt;
        &lt;P_PUNTYDS&gt;41&lt;/P_PUNTYDS&gt;
    &lt;/PRECORD&gt;
<b class="green">&lt;/NFLDSTAT&gt;</b>
</pre>


<ul>

<li><b class="red">XML Declaration</b>: specifies the version of XML being used</li>

<li><b class="orange">Document Type Declaration</b>:
    states the Root Element and DTD (Document Type Definition)
</li>

<li>Elements are the building blocks of XML:
    start with &quot;&lt;&quot; then element name
    <ul>
    <li><b class="green">Root Element</b>:
        the tags that hold the XML document (<code>&lt;NFLDSTAT&gt;</code>)
    </li>

    <li><b class="blue">Elements</b>:
        (aka paired elements) have start and end tags, data can be in the
        start-tag's attributes and/or between the tags themselves (<code>&lt;DATE&gt;</code>)
    </li>

    <li><b class="violet">Empty Elements</b>:
        single tag, closed by &quot;/&gt;&quot;, data in
        the attributes (<code>&lt;SOURCE.../&gt;</code>)
    </li>
    </ul>
</li>

<li><b class="pink">Character Data</b>: information between elements (<code>JOHNSONR</code>)</li>

<li><b class="maroon">Attributes</b>: name/value pairs in start-tags (<code>gender=&quot;F&quot;</code>)</li>

</ul>

<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
