<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<ul>

<li class="main">Stands for E<u>x</u>tensible <u>M</u>arkup <u>L</u>anguage</li>

<li class="main">Similar to HTML: &nbsp; plain text using
    &quot;&lt;&quot; and &quot;&gt;&quot; to delimit markup</li>

<li class="main">Markup components are named for the data they contain</li>

<li class="main">Became popular because it's a self explanatory way to transmit data</li>

<li class="main">More info: <a href="http://www.w3.org/XML/">www.w3.org/XML/</a></li>

</ul>

<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*
<li class="main">Originally designed for the electronic publishing industry</li>

<li class="main">Markup tags tell what data contained</li>

<li class="main">The beauty is how elements &amp; attributes are named for the data they contain</li>

<li class="main">Derived from SGML (Standard Generalized Markup Language).</li>

// http://www.devshed.com/Server_Side/XML


*/

$Layout->Foot();
?>
