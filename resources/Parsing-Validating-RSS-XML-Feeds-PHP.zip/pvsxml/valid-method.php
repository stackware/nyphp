<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>/**
 * Validates data under the current element using the DataFields array.
 *
 * @param   string   $Elem  the current element name
 * @return  integer  1 if valid, 0 if not
 */
function validateDataFields($Elem) {
    //  Ensure $DataFields array has validation types ready for this element.
    if ( empty(<a href="array-fields.php" class="orange">$this-&gt;DataFields[<tt class="blue">$this-&gt;ParentElements[0]</tt>][$Elem]</a>) ) {
        $this-&gt;Probs[] = &quot;$Elem: DataFields[{<tt class="blue">$this-&gt;ParentElements[0]</tt>}][$Elem] is empty&quot;;
        <tt class="red">$this-&gt;IgnoreTheRest = 'Y';</tt>
        return 0;
    }

    $Problems = 0;
    reset(<a href="array-fields.php" class="orange">$this-&gt;DataFields[<tt class="blue">$this-&gt;ParentElements[0]</tt>][$Elem]</a>);

    // &gt; &gt;  GO THROUGH EACH FIELD NEEDED FROM THIS PARENT ELEMENT.  &lt; &lt;
    foreach (<b><a href="array-fields.php" class="orange">$this-&gt;DataFields[<tt class="blue">$this-&gt;ParentElements[0]</tt>][$Elem]</a></b> AS $Field =&gt; $Type) {

        //  Ensure $DataTypes array has validation types ready for this type.
        if ( empty(<a href="array-types.php" class="maroon">$this-&gt;DataTypes[$Type]</a>) ) {
            $this-&gt;Probs[] = &quot;$Elem: DataTypes[$Type] is empty&quot;;
            $Problems++;
            continue;
        }

        //  If this field isn't set, don't even bother checking type.
        if ( !isset($this-&gt;Data[$Field]) ) {
            $this-&gt;Probs[] = &quot;$Elem: $Field isn't set&quot;;
            $Problems++;
            continue;
        }

        // &gt; &gt;  DOES THE DATA IN THIS FIELD MATCH THE EXPECTED TYPE?  &lt; &lt;
        if ( !preg_match(<b><a href="array-types.php" class="maroon">$this-&gt;DataTypes[$Type]</a></b>, $this-&gt;Data[$Field]) ) {
            $this-&gt;Probs[] = &quot;$Elem: $Field does not match $Type: {$this-&gt;Data[$Field]}&quot;;
            $Problems++;
        }
    }

    if ( !empty($Problems) ) {
        <tt class="red">$this-&gt;IgnoreTheRest = 'Y';</tt>
        return 0;
    }
    
    return 1;
}</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
