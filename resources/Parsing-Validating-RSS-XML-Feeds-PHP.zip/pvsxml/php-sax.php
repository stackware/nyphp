<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();


#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<ul>
<li class="main">PHP 4 uses the Expat libarary: <a href="http://www.jclark.com/xml/expat.html">www.jclark.com/xml/expat.html</a></li>
<li class="main">PHP 5 uses the Libxml2 library: <a href="http://www.xmlsoft.org/">www.xmlsoft.org/</a></li>
<li class="main">Changes from PHP 4 to 5 are just in the back end. Don't need to modify your code.</li>
<li class="main">Documentation: <a href="http://php.net/ref.xml">php.net/ref.xml</a></li>
</ul>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
$Layout->Foot();
?>
