<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '
 table.courier {font-size: 10pt; font-family: "courier new", courier, monospace; margin-bottom: 2em}
 caption {font-size: 15pt; font-family: sans-serif; font-weight: bold; margin-bottom: 0.5em}
 p {margin-bottom: -1em}
';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<table class="courier" border="4" cellpadding="4">
 <caption class="orange">STP_DataFields</caption>
 <tr><th>RootElement</th><th>ParentElement</th><th>DataField</th><th>DataTypeID</th></tr>
 <tr><td>NFLDSTAT</td><td>PRECORD</td><td>P_CODE</td><td>Alpha10</td></tr>
 <tr><td>NFLDSTAT</td><td>PRECORD</td><td>P_PUNTYDS</td><td>Int3Neg</td></tr>
 <tr><td>NFLBOXSCORE</td><td>LINESCORE</td><td>LINESCORE:QTR4</td><td>Int2</td></tr>
 <tr><td>NFLBOXSCORE</td><td>LINESCORE</td><td>LINESCORE:TEAMCODE</td><td>Alpha10</td></tr>
</table>

<p class="orange"><a name="fields" id="fields">$DataFields</a></p>
<pre>    [NFLDSTAT] =&gt; Array
        (
            [PRECORD] =&gt; Array
                (
                    [P_CODE] =&gt; Alpha10
                    [P_PUNTYDS] =&gt; Int3Neg
                )
        )
    [NFLBOXSCORE] =&gt; Array
        (
            [LINESCORE] =&gt; Array
                (
                    [LINESCORE:QTR4] =&gt; Int2
                    [LINESCORE:TEAMCODE] =&gt; Alpha10
                )
        )
</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
