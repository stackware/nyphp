<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>/**
 * Processes XML start tags.
 *
 * &lt;p&gt;Activated when an XML element opening tag is reached. The XML parser
 * automatically calls this function. Don't call this manually.&lt;/p&gt;
 *
 * @param   mixed    $Parser  variable to contain the current parser's reference id
 * @param   mixed    <tt class="pink">$Elem</tt>    variable to contain the current element's name
 * @param   mixed    <tt class="violet">$Attr</tt>    array to contain the current element's attributes
 */
function saxStartHandler(&amp;$Parser, &amp;<tt class="pink">$Elem</tt>, &amp;<tt class="violet">$Attr</tt>) {

    <tt class="red">if ($this-&gt;IgnoreTheRest == 'Y') {
        return;
    }</tt>

    <tt class="blue">array_push($this-&gt;ParentElements, <tt class="pink">$Elem</tt>);</tt>

    //  Is this a root element?
    if ( count(<tt class="blue">$this-&gt;ParentElements</tt>) == 1 ) {
        //  If don't care about this file type, ignore the rest of it.
        <tt class="red">if ( !isset(<a href="array-elements.php" class="red">$this-&gt;RootElements[<tt class="pink">$Elem</tt>]</a>) ) {
            $this-&gt;IgnoreTheRest = 'Y';
            return;
        }</tt>
    }

    <tt class="green">foreach (<tt class="violet">$Attr</tt> AS $Key =&gt; $Value) {
        $this-&gt;Data[&quot;<tt class="pink">$Elem</tt>:$Key&quot;] = trim($Value);
    }</tt>

    <tt class="maroon">$this-&gt;CData = array();</tt>
}</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
