<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>/**
 * Updates the NFL team stats table with the linescore tag info
 *
 * @param   string   $TeamCode          the ST team id code
 * @param   integer  $Qtr4              Points Team Scored During 4th Quarter
 * @return  string   update query
 */
function qsStatNflLinescore($TeamCode, $Qtr4) {
    return &quot;UPDATE STP_StatsNFLTeam SET Scored4Q=$Qtr4 &quot;
           . &quot;WHERE TeamCode=$TeamCode&quot;;
}


/**
 * Updates NFL player stats with recovered dstat info
 *
 * @param   string   $PlayerCode        the ST player id code
 * @param   integer  $P_PuntYds         Total Punting Yards
 * @return  string   update query
 */
function qsStatNflGamePlayerD($PlayerCode, $P_PuntYds) {
    return &quot;UPDATE STP_StatsNFLPlayer SET PuntYard=$P_PuntYds &quot;
           . &quot;WHERE PlayerCode=$PlayerCode&quot;;
}</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
