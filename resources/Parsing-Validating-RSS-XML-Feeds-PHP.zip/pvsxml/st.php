<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>


<ul>

<li class="main">Provides real time sports information: scores, boxscores, news, etc</li>

<li class="main">Covers all popular US leagues in great detail. Less popular sports
and foreign leagues get text based notes.</li>

<li class="main">Pushes XML data over a Kerberos authenticated socket</li>

<li class="main">60 DTD's</li>

<li class="main">Volume: Thursday in July received 10,000 messages</li>

<li class="main">NFL stats came through two DTD's with a total of 268 fields</li>

<li class="main">Sunday in the real world: stats from the 14 NFL games found in
22&nbsp;transmissions, 59,000&nbsp;elements, 9,000&nbsp;attributes</li>

<li class="main">More info: <a href="http://www.sportsticker.com/ticker/">www.sportsticker.com/ticker/</a></li>

</ul>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
