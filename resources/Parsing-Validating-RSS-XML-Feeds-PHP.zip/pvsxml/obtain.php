<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>/**
 * Processes the XML stream from STDIN.
 *
 * &lt;p&gt;Reads STDIN.  The data is accumulated in the class' &lt;var&gt;$ContentsRaw&lt;/var&gt;
 * variable.  When the transmission separation character is reached this method
 * executes the &lt;code&gt;runParser()&lt;/code&gt; method.&lt;/p&gt;
 *
 * &lt;p&gt;If the connection to the WireParserClient is severed, even
 * if intentionally by you, an error message will be generated
 * that says &quot;SportsTicker connection lost...&quot;&lt;/p&gt;
 */
function readStdinStream() {
    $In = fopen('php://stdin', 'r');

    while ( !feof($In) ) {
        $Line = fgets($In, 5000);
        $this-&gt;ContentsRaw .= $Line;

        if ( preg_match('/\x04/', $Line) ) {
            //  Last line of transmission.  Parse it.
            <a href="parse-define.php">$this-&gt;runParser();</a>
        }
    }

    $this-&gt;killProcess('SportsTicker connection lost: ' . date('Y-m-d H:i:s') );
}</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
