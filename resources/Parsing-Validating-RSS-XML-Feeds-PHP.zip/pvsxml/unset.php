<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>/**
 * Unsets data under the current element using the DataFields array.
 *
 * @param  string    $Elem  the current element name
 */
function unsetFields($Elem) {
    foreach (<b><a href="array-fields.php" class="orange">$this-&gt;DataFields[<tt class="blue">$this-&gt;ParentElements[0]</tt>][$Elem]</a></b> AS $Field =&gt; $Type) {
        unset($this-&gt;Data[$Field]);
    }
}</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
