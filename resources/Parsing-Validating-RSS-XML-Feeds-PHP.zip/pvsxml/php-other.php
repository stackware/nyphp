<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<ul>
<li class="main">DOM XML
    <ul>
    <li class="main">Experimental in PHP 4</li>
    <li class="main">Stable in PHP 5</li>
    <li class="main">But, your code will probably need to be modified</li>
    <li class="main">Documentation: <a href="http://php.net/ref.domxml">php.net/ref.domxml</a></li>
    </ul>
</li>
</ul>

<ul>
<li class="main">XSLT
    <ul>
    <li class="main">API completely changed for PHP 5</li>
    </ul>
</li>
</ul>

<ul>
<li class="main">Other Stable Extensions for PHP 5
    <ul>
    <li class="main">SimpleXML</li>
    <li class="main">XPath</li>
    <li class="main">Schema</li>
    </ul>
</li>
</ul>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...

//DOM XML
//http://www.derickrethans.nl/php5intro/domxml-load.html
//
//$doc = domxml_open_file('book.xml');
//$root = $doc->child_nodes();
//$root = $root[0];
//$books = $root->child_nodes();
//
//
//foreach ($books as $book) {
//    if (@$book->tagname == 'book') {
//        $content = $book->child_nodes();
//        foreach ($content as $elem) {
//            if (@$elem->tagname == 'author') {
//                $author = $elem->get_content();
//            }
//            if (@$elem->tagname == 'title') {
//                $title = $elem->get_content();
//            }
//        }
//        echo "{$title} was written by {$author}\n";
//    }
//}
//
//
//SimpleXML
//http://www.derickrethans.nl/php5intro/simplexml-load.html
//
//$books = simplexml_load_file('book.xml')->book;
//foreach ($books as $book) {
//    echo "{$book->title} was written by {$book->author}\n";
//}
//

$Layout->Foot();
?>
