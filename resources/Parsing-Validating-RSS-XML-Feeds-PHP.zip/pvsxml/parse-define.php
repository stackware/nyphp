<?php

#  FILL IN THESE VARIABLES FOR EACH PAGE  -------------------------
$Title = '';
$Description = '';
$Keywords = '';
$Robots = '';
$Style = '';
#  ----------------------------------------------------------------


#  LEAVE THIS STUFF ALONE  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$File = __FILE__;
require('./directory.inc');
#  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# You may, or may not, want the header to be printed automatically.
# If you do, leave this here.  If not, remove it.
$Layout->Head();

#  BEGIN YOUR PAGE SPECIFIC LAYOUT BELOW HERE .................. ?>

<pre>/**
 * Parses the data.
 *
 * &lt;p&gt;Sets up the requisite sax XML parsing functions then passes
 * the XML data accumulated in &lt;var&gt;$ContentsRaw&lt;/var&gt; to the parser.
 * Once done, reset several class variables to their default values.&lt;/p&gt;
 *
 * @return  boolean  true if no problems, false if problems
 */
function runParser() {
    /*
     * Replace all non-visible characters (except SP, TAB, LF and CR)
     * with LF to keep the sax parser from choking.
     */
    <tt class="red">$this-&gt;Contents = trim( preg_replace('/[^\x20-\x7E\x09\x0A\x0D]/', &quot;\n&quot;,
            <a href="obtain.php" class="red">$this-&gt;ContentsRaw</a>) );

    $this-&gt;Contents = preg_replace('/&amp;amp;|&amp;/i', '&amp;amp;', $this-&gt;Contents);</tt>

    <tt class="orange">$this-&gt;Parser = xml_parser_create('UTF-8');</tt>
    <tt class="violet">xml_set_object(<tt class="orange">$this-&gt;Parser</tt>, $this);</tt>
    <tt class="blue">xml_set_element_handler(<tt class="orange">$this-&gt;Parser</tt>, '<a href="parse-start.php" class="blue">saxStartHandler</a>', '<a href="parse-end.php" class="blue">saxEndHandler</a>');
    xml_set_character_data_handler(<tt class="orange">$this-&gt;Parser</tt>, '<a href="parse-char.php" class="blue">saxCharacterHandler</a>');</tt>

    if ( !<tt class="green">xml_parse(<tt class="orange">$this-&gt;Parser</tt>, $this-&gt;Contents, TRUE)</tt> ) {
        $this-&gt;Probs[] = &quot;File rejected by parser:\n   &quot;
                . xml_error_string( xml_get_error_code(<tt class="orange">$this-&gt;Parser</tt>) );
    }

    xml_parser_free(<tt class="orange">$this-&gt;Parser</tt>);

    $ProbCount = count($this-&gt;Probs);
    if ($ProbCount != 0) {
        //  Error handling omitted for clarity.
    }

    <tt class="maroon">$this-&gt;IgnoreTheRest  = 'N';
    $this-&gt;Contents       = '';
    $this-&gt;ContentsRaw    = '';
    $this-&gt;Data           = array();
    $this-&gt;ParentElements = array();
    $this-&gt;Probs          = array();</tt>

    return ($ProbCount == 0);
}</pre>


<?php  #  END PAGE SPECIFIC LAYOUT ABOVE HERE & PRINT THE FOOTER...
/*

*/

$Layout->Foot();
?>
