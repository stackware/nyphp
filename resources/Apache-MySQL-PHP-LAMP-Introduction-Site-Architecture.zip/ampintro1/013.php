<?php

require_once('ampintro1.inc');

?>

<div class=slidebody>
   <h1>Staying Current</h1>
   <ul>
      <li><a target=_blank href="http://zend.com/zend/week/">Zend's Weekly Mailing List Notes</a></li>
      <li><a target=_blank href="http://zend.com">Zend's Monthly Newsletter</a></li>
      <li><a target=_blank href="http://conf.php.net">PHP Conference Material</a></li>
      <li><a target=_blank href="http://phpclasses.websapp.com">PHP Class Repository</a></li>
      <li><a target=_blank href="http://www.nyphp.org">NYPHP's Projects and Mailing Lists</a></li>
      <li><a target=_blank href="http://www.nyphp.org/training">PHP in Education</a></li>
   </ul>
</div>

<?=slidefooter()?>