<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP and Apache</h1>
   <ul>
      <li>Apache allows a distributed and universal presentation and interaction layer, in addition to native console, ncurses and GTK layers</li>
      <li>PHP is a project of the Apache Software Foundation, allowing for:</li>
      <ul>
         <li>Incredible speed and a dedicated function set</li>
         <li>Extensibility, creating a seamless PHP daemon with the socket, protocol and processing stability of Apache</li>
         <ul>
            <li>mod_php clears CGI permission and structure issues</li>
         </ul>
         <li>Apache_hook and Apache 2 development, providing PHP integration at every level of the Apache request, protocol and filter stacks</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>