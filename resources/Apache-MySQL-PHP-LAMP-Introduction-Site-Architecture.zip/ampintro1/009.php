<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP and MySQL</h1>
   <ul>
      <li>MySQL provides an extremely fast, yet comprehensive, data access mechanism</li>
      <li>MySQL provides an easy to implement &quot;SQL-enabled file system&quot;</li>
      <li>The flexibility of an enterprise RDBMS, including replication, user management, indexing and SQL means:</li>
      <ul>
         <li>Faster and more reliable data access than many local disks</li>
         <li>More development potential than monolithic file systems</li>
      </ul>
      <li>All with the speed and comprehensiveness of native C API calls, in a rapid-development friendly syntax</li>
   </ul>
</div>

<?=slidefooter()?>