<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP Matures</h1>
   <ul>
      <li>Zend forms to create the Zend Engine</li>
      <ul>
         <li>Handles all low-level memory/resource management and interfaces with platforms' native libraries</li>
         <li>Creates a complete API for extension interaction</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>