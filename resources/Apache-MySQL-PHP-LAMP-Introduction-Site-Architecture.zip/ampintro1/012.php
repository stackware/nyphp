<?php

require_once('ampintro1.inc');

?>

<div class=slidebody>
   <h1>PHP and the Future...</h1>
   <ul>
      <li>PEAR (PHP Extension and Application Repository)</li>
      <ul>
         <li>OO framework for modules written in PHP</li>
      </ul>
      <li>PECL (PHP Extension C Library)</li>
      <ul>
         <li>Interface to PHP/Zend API for modules written in C</li>
         <li>Audio manipulation</li>
      </ul>
      <li>On-demand network distribution of modules, including certificate and security regulation</li>
   </ul>
</div>

<?=slidefooter()?>