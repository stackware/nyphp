<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP Extends</h1>
   <ul>
      <li>Many extensions can easily be compiled or loaded dynamically to extend functionality</li>
      <li>Performance and flexibility come from extensions being wrappers of native C libraries</li>
      <li>Pertinent garbage-collection, resource management, and continuity maintained by the Zend Engine</li>
   </ul>
</div>

<?=slidefooter()?>