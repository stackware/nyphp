<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP and the Future...</h1>
   <ul>
      <li>PHP joins forces with other languages</li>
      <ul>
         <li>Java Servlet SAPI and embedded Java support</li>
         <li>Load Microsoft .NET modules</li>
         <li>Interact with DOM, COM and Windows DLLs</li>
         <li>ActiveScript bindings for browser interaction</li>
         <li>GTK support for local GUI PHP applications</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>