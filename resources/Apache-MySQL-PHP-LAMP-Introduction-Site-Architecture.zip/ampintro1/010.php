<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP and the Future</h1>
   <ul>
      <li>Zend Engine 2</li>
      <ul>
         <li>Complete OO pragmatics, modeled after Java</li>
         <li>Continuing performance, resource management and garbage collection enhancements</li>
         <li>ZE2 RPC</li>
      </ul>
      <li>Apache_hooks and Apache 2 will give PHP full control over protocol request, filtering, and response stages</li>
   </ul>
</div>

<?=slidefooter()?>