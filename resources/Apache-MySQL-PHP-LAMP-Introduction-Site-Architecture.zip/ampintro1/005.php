<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP Enhances</h1>
   <ul>
      <li>Wrappers allow quick access to higher-level and enhanced functionality</li>
      <li>Including:</li>
      <ul>
         <li>Directory and file management</li>
         <li>Sockets and remote FTP/HTTP URLs as local files</li>
         <li>Error handling/logging</li>
         <li>Flash, PDF, images, fonts, encoding, zlib, Perl regex, sound</li>
         <li>IMAP/POP3/NTTP, XML, XSLT, SOAP, WDDX, WebDAV</li>
      </ul>
      <li>More every day</li>
   </ul>
</div>

<?=slidefooter()?>