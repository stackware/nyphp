<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP AMPlified</h1>
   <ul>
      <li>Apache, MySQL and PHP integrate to develop a new paradigm in application construction, flexibility and delivery</li>
      <li>Apache provides the de-facto daemon for the standard user interface</li>
      <li>MySQL provides unmatched efficiency for data storage and retrieval</li>
      <li>Core developers from each camp tightly integrate the packages with unparalleled know-how</li>
   </ul>
</div>

<?=slidefooter()?>