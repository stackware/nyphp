<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP Expands</h1>
   <ul>
      <li>Native calls to MySQL, Oracle, COM, Java, LDAP, IMAP, SSL and other libraries</li>
      <li>Native calls to uncommon low-level functionality, including sockets, streams, direct IO, POSIX, processes, shared memory/semaphore/IPC, terminals, et al</li>
      <li>All with the familiar, yet streamlined, C syntax and structure</li>
   </ul>
</div>

<?=slidefooter()?>