<?php

require_once('ampintro1.inc');

?>


<div class=slidebody>
   <h1>PHP Interfaces</h1>
   <ul>
      <li>Numerous Server Application Programming Interfaces allow PHP native interfaces to multiple presentation layers</li>
      <li>SAPIs include:</li>
      <ul>
         <li>Web daemons Apache, IIS, Zeus, et al</li>
         <li>Command Line Interface (CLI), including ncurses, readline, etc.</li>
         <li>GTK</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>