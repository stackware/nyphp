<?php
// javascript:window.alert('Width: ' + window.innerWidth + ' Height: ' + window.innerHeight);

require_once('ampintro1.inc');

?>

<div class=slidebody>
   <h1>What is PHP?</h1>
   <ul>
      <li>Another clever recursive acronym: PHP Hypertext Preprocessor</li>
      <li>Originally designed to complement C and Perl as CGI languages</li>
      <li>PHP started life as an HTML-embedded server-side language</li>
   </ul>
</div>

<?=slidefooter()?>