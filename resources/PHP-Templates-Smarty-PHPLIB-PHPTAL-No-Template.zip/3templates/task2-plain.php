<html>
<head>
   <title>Task 2: Display the results of a mysql query</title>
</head>

<body>

<h2>Display the results of a mysql query</h2>

<p>The goal here is to use PHP to parse and display the results of a database query.</p>
<?php

// TASK: display results of a MySQL query

// get database connection info
include('task2-config.php');

/* Dataset:  --- with apologies to boingboing.net see task2-sql.txt */

$db= @mysql_connect(MYDBHOST, MYDBUSERNAME, MYDBPASSWORD);
if (!$db) {
	exit("Database error, could not connect to server.");
}

if (!$database= @mysql_select_db(MYDBNAME)) {
	exit("Database error, could not connect to database.");
}

?>

<p>And here are the results, unprocessed and in a simple bulleted list:</p>

<ul>

<?php

$query = "SELECT * FROM presentations.3templates ";
$result = mysql_query($query);

if ($result) {

	while ($array= mysql_fetch_assoc($result)) {
		print "<li><h4>$array[title]</h4>$array[content] <i>($array[created])</i></li>\n";
	}

} else {

	print "<li>No results.</li>";

}

?>

</ul>

<p>&nbsp;</p>

<h3>Attribution</h3>

<p>Content by Cory Doctorow and Xeni Jardin of <a href="http://boingboing.net">BoingBoing.net</a>, subject to Creative Commons <a href="http://creativecommons.org/licenses/by-nc/1.0">attribution/non-commercial license</a>.</p>
<p>SQL Data Available: <a href="task2-sql.txt">task2-sql.txt</a></p>


<hr width="100%">

<h2>Source of this script</h2>

<?php

   $output= highlight_file($_SERVER['SCRIPT_FILENAME'],1);
   print $output;

?>

</body>
</html>

