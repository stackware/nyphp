<html>
<head>
   <title>Task 3: Display a directory listing</title>
</head>

<body>

<h2>Display a directory listing</h2>

<p>This is an example of how one might display a list of files in the local directory, complete with image thumbnails and human-readable filesizes.</p>

<?php

// TASK: display a directory listing with thumbnails for images and human-readable filesizes

// handy humansize function:
// input is number of bytes, output is a "human-readable" filesize string
function humansize($size) {

        // Setup some common file size measurements.
	$kb = 1024;         // Kilobyte
	$mb = 1024 * $kb;   // Megabyte
	$gb = 1024 * $mb;   // Gigabyte
	$tb = 1024 * $gb;   // Terabyte

        if($size < $kb) return $size."B";
	else if($size < $mb) return round($size/$kb,0)."KB";
	else if($size < $gb) return round($size/$mb,0)."MB";
	else if($size < $tb) return round($size/$gb,0)."GB";
	else return round($size/$tb,2)."TB";
}

// get local directory path
$path= dirname($_SERVER['SCRIPT_FILENAME']);

?>

<h3>Files in <?php print $path; ?>:</h3>

<ul>

<?php

$d = dir($path);
$icon = '';

while (false !== ($entry = $d->read())) {

	if ( substr($entry, 0, 1)=='.' ) continue;

	// get size
	$size = filesize($path.'/'.$entry);
	$humansize = humansize($size);

	// find filename extension
	$dotpos = strrpos($entry, '.');

	if ($dotpos) {
		$ext = substr($entry, $dotpos+1);
		if ($ext === 'jpeg' || $ext === 'gif' || $ext === 'png') {
			$icon = "<img src='$entry' style='width: 48px; height: auto; vertical-align: text-top;' alt='icon' title='$entry' />";
		}
	}

	print "<li><a href='$entry'>$entry</a> ($humansize) $icon</li>\n";

	$icon= '';
}

$d->close();

?>

</ul>


<hr width="100%">

<h2>Source of this script</h2>

<?php

   $output= highlight_file($_SERVER['SCRIPT_FILENAME'],1);
   print $output;

?>
