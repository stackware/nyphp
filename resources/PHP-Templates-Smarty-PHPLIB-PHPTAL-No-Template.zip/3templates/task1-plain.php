<html>
<head>
   <title>Task 1: Display and/or process a form</title>
</head>

<body>

<h2>Display and/or process a form</h2>

<p>The goal here is to use PHP to build a form with either default or user-submitted values.</p>

<?php

// TASK: display and/or process a form
$comment= 'Default comment.';
$option= 0;

// process
if ( isset ( $_REQUEST['submit'] ) ) {
	$comment= $_REQUEST['comment'];
	$option= $_REQUEST['option'];
}

// display comment
print "<em>Comment:</em><blockquote>".htmlentities($comment)."</blockquote>";

// display option
if ($option==1) {
	print "<p>Option was selected</p>";
}

?>

<form action="" method="post">
   <h3>The form:</h3>
   <table>
      <tr>
         <td>comment</td>
         <td><input type="text" name="comment" size="56" /></td>
      </tr>
      <tr>
         <td>option</td>
         <td><input type="checkbox" name="option" value="1" /> use option if checked.</td>
      </tr>
      <tr>
         <td>&nbsp;</td>
         <td><input type="submit" name="submit" value="submit" /></td>
      </tr>
   </table>
</form>


<hr width="100%">

<h2>Source of this script</h2>

<?php

   $output= highlight_file($_SERVER['SCRIPT_FILENAME'],1);
   print $output;

?>

</body>
</html>
