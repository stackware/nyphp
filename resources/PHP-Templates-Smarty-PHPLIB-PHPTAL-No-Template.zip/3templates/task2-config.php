<?php
// task2-config

// DATABASE INFO
define( 'MYDBHOST',$ORGHOST);
define( 'MYDBNAME',$PRESENTATION_DB);
define( 'MYDBUSERNAME',$ORGUSER);
define( 'MYDBPASSWORD',$ORGPASS);

