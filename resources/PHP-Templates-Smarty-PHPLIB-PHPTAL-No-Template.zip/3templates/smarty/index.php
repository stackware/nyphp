<?php
// initialize template
include_once('libs/Smarty.class.php');
$template= new Smarty;
$template->assign('title', 'Introducting Smarty Templates');
$template->assign('next', 'helloworld.php');


// display the template
$template->display('header.tpl');
?>

<h2><a href="http://smarty.php.net/"><img src="smarty-logo-orange.gif"
 title="" alt="smarty logo"
 style="border: 0px solid ; width: 250px; height: 64px;" align="right"></a>What
Is Smarty?</h2>
Smarty is a is PHP template engine with an extensible architecture,
built-in template compiling, and optional output caching. <br>
<br>
The project was started in late 2000 by Monte Ohrt and Andrei Zmievski,
and was the result of a failed attempt at writing an all-purpose
template extension for PHP in C. They decided to start from scratch and
rewrite it as a PHP class. <br>
<br>
Recent development has been done by Monte and Messju Mohr, and involved
adding object support, optimizing the compiler, and enhancing custom
function&nbsp; support.<br>
<br>
Code and notes in this presentation apply to version 2.6, at RC1 as of
August 11, 2003.<br>
<br>
<h3>So What Does It Look Like?</h3>
Here is a <a href="helloworld.php">hello world</a> example.<br>
<br>
<h3>Three Tasks Shortcut:</h3>
<ol>
  <li><a href="task1-smarty.php">Process posted vars and display a form.</a><br>
    <br>
  </li>
  <li><a href="task2-smarty.php">Display the results of a MySQL query.</a><br>
    <br>
  </li>
  <li><a href="task3-smarty.php">Display a directory listing</a> with
image
thumbnails and human-readable filesizes.</li>
</ol>

<?php
$template->display('footer.tpl');
?>
