<?php
// initialize template
include_once('libs/Smarty.class.php');
$template= new Smarty;
$template->assign('title', 'Task 3: Print a directory listing');
$template->assign('next', 'index.php');

// TASK: display a directory listing with thumbnails for images and human-readable filesizes

// handy humansize function:
// input is number of bytes, output is a "human-readable" filesize string
function humansize($size) {
	// only take numbers
	if ( !is_numeric($size) ) return $size;
	
        // Setup some common file size measurements.
	$kb = 1024;         // Kilobyte
	$mb = 1024 * $kb;   // Megabyte
	$gb = 1024 * $mb;   // Gigabyte
	$tb = 1024 * $gb;   // Terabyte

        if($size < $kb) return $size."B";
	else if($size < $mb) return round($size/$kb,0)."KB";
	else if($size < $gb) return round($size/$mb,0)."MB";
	else if($size < $tb) return round($size/$gb,0)."GB";
	else return round($size/$tb,2)."TB";
}
// register humansize as a custom modifier
$template->register_modifier('humansize','humansize');

// get local directory path
$path= dirname(dirname($_SERVER['SCRIPT_FILENAME']));
$template->assign('path', $path);

// get the directory contents into $files array
$d = dir($path);
$files= array();
$index= 0;
while (false !== ($entry = $d->read())) {
	if ( substr($entry, 0, 1)=='.' ) continue;
	$files[]= $entry;
}
$d->close();

// natsort the entries
usort($files, 'strnatcmp');

// get sizes and extensions
$extensions= array();
$sizes= array();
foreach( $files AS $entry ) {
	// get size
	if ( is_dir($path.'/'.$entry) ) {
		$sizes[]= 'dir';
	}
	else {
		$sizes[]= filesize($path.'/'.$entry);
	}

	// find filename extension
	$dotpos= strrpos($entry, '.');
	if ($dotpos) {
		$extensions[]= substr($entry, $dotpos+1);
	}
	else {
		$extensions[]= '';
	}
}

// assign the files, extensions, and sizes arrays to the template
$template->assign('files', $files);
$template->assign('extensions', $extensions);
$template->assign('sizes', $sizes);

// display the template
$template->display('task3.tpl');
?>

<h3>Source of this script</h3>
<?php
$output= highlight_file($_SERVER['SCRIPT_FILENAME'],1);
print $output;
?>

<h3>Source of the template</h3>
<?php
$output= highlight_file(dirname($_SERVER['SCRIPT_FILENAME']).'/templates/task3.tpl',1);
print $output;
?>
