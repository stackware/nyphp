<?php
// initialize template
include_once('libs/Smarty.class.php');
$template= new Smarty;
$template->assign('title', 'Process a form (alt)');
$template->assign('next', 'task2-smarty.php');

// use HTML comments as delimiters instead of {}
$template->left_delimiter= '<!--';
$template->right_delimiter= '-->';

// TASK: display and/or process a form
$comment= 'Default comment.';
$option= 0;

// process
if ( isset ( $_REQUEST['submit'] ) ) {
	$comment= $_REQUEST['comment'];
	$option= $_REQUEST['option'];
}

// assign the values to the template
$template->assign('comment', $comment);
$template->assign('option', $option);

// display the template
$template->display('task1-alt.tpl');
?>

<h3>Source of this script</h3>
<?php
$output= highlight_file($_SERVER['SCRIPT_FILENAME'],1);
print $output;
?>

<h3>Source of the template</h3>
<?php
$output= highlight_file(dirname($_SERVER['SCRIPT_FILENAME']).'/templates/task1-alt.tpl',1);
print $output;
?>
