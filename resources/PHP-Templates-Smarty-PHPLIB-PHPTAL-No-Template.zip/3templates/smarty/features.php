<?php
// initialize template
include_once('libs/Smarty.class.php');
$template= new Smarty;
$template->assign('title', 'Smarty Features');
$template->assign('next', 'task1-smarty.php');


// display the template
$template->display('header.tpl');
?>
<h3>Highlights:</h3>
<ul>
  <li>
    <p>Smarty parses your template into a compiled PHP script which is
used for subsequent requests<br>
    </p>
  </li>
  <li>
    <p>It can be extended with your own <a
 href="http://smarty.php.net/manual/en/language.custom.functions.php">functions</a>
and <a href="http://smarty.php.net/manual/en/language.modifiers.php">variable
modifiers</a></p>
  </li>
  <li>
    <p>Display-logic is allowed, and can be as complex as you like<br>
    </p>
  </li>
  <li>
    <p>Unlimited nesting of looping sections and/or logic are allowed.</p>
  </li>
  <li>
    <p>In a pinch, it is possible to embed PHP code right in your
template files.</p>
  </li>
  <li>
    <p>Built-in, extensible caching support</p>
  </li>
  <li>
    <p>Arbitrary template sources: build them on the fly or load from a
database<br>
    </p>
  </li>
  <li>
    <p>Custom cache handling functions</p>
  </li>
  <li>Configurable template delimiter tag syntax, so you can use {},
{{}}, &lt;!--{}--&gt;, etc.<br>
    <br>
  </li>
</ul>
<h3>Security Considerations</h3>
Smarty has a "safe mode" for use in a semi-trusted environment:<br>
<ul>
  <li>
    <p>templates can only be included from directories listed in the
$secure_dir array</p>
  </li>
  <li>
    <p>local files can only be fetched from directories listed in the
$secure_dir array using {fetch}</p>
  </li>
  <li>
    <p>{php}{/php} tags are not allowed</p>
  </li>
  <li>
    <p>PHP functions are not allowed as modifiers, or in IF statements,
except those specified in the $security_settings</p>
  </li>
</ul>
A potential security risk is the web-writeable compiled template
cache. If this is world-writeable, then other users may be able to
insert their own PHP code in your scripts (or at least, I was able to--
maybe this is a bug). <br>
<br>
One solution would be a central templates_c directory, owned and
writeable by the webserver user only<br>
.<br>

<?php
$template->display('footer.tpl');
?>
