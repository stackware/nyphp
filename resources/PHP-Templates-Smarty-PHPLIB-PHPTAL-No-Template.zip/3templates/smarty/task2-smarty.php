<?php
// initialize template
include_once('libs/Smarty.class.php');
$template= new Smarty;
$template->assign('title', 'Task 2: Results of a MySQL query');
$template->assign('next', 'task3-smarty.php');

// TASK: display results of a MySQL query
// get database connection info
include('../task2-config.inc');

$db= @mysql_connect($ORGHOST,$ORGUSER,$ORGPASS);
if (!$db) {
	exit("Database error, could not connect to server.");
}
if (!$database= @mysql_select_db($PRESENTATION_DB)) {
	exit("Database error, could not connect to database.");
}

// query database and dump results into $articles array
$query= "SELECT * FROM presentations.3templates ";
$result= mysql_query($query);
$articles= array();
if ($result) {
	while ($array= mysql_fetch_assoc($result)) {
		$articles[]= $array;
	}
}

// assign the articles array to the template
$template->assign('articles', $articles);

// display the template
$template->display('task2.tpl');
?>

<h3>Source of this script</h3>
<?php
$output= highlight_file($_SERVER['SCRIPT_FILENAME'],1);
print $output;
?>

<h3>Source of the template</h3>
<?php
$output= highlight_file(dirname($_SERVER['SCRIPT_FILENAME']).'/templates/task2.tpl',1);
print $output;
?>
