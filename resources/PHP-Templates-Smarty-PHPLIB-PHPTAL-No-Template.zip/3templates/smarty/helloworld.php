<?php
// initialize template
include_once('libs/Smarty.class.php');
$template= new Smarty;

// assign the values to the template
$template->assign('date', date("r"));
$template->assign('title', 'A Sample');
$template->assign('next', 'works.php');

// display the template
$template->display('helloworld.tpl');
?>

<h3>Source of this script</h3>
<?php
$output= highlight_file($_SERVER['SCRIPT_FILENAME'],1);
print $output;
?>

<h3>Source of the template</h3>
<?php
$output= highlight_file(dirname($_SERVER['SCRIPT_FILENAME']).'/templates/helloworld.tpl',1);
print $output;
?>
