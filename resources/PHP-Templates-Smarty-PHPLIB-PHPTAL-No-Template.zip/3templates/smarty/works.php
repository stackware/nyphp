<?php
// initialize template
include_once('libs/Smarty.class.php');
$template= new Smarty;
$template->assign('title', 'How Does Smarty Work?');
$template->assign('next', 'features.php');


// display the template
$template->display('header.tpl');
?>

The first time a modified template is requested, Smarty compiles it
into a PHP script and saves it in a webserver-writeable directory.<br>
<br>
<h3>The compiled PHP of helloworld.tpl:</h3>
<div style="margin-left: 20px; background-color: white; padding: 10px;"><code><font color="#000000"><font
 color="#0000cc">&lt;?php </font><font color="#ff9900">/* Smarty
version 2.6.0-RC1, created on 2003-09-23 10:42:32</font></font></code><br>
<code><font color="#000000"><font color="#ff9900">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;compiled
from helloworld.tpl */ </font><font color="#0000cc">?&gt;</font></font></code><br>
<code><font color="#000000"><font color="#0000cc">&lt;?php </font><font
 color="#006600">require_once(</font><font color="#0000cc">SMARTY_DIR </font><font
 color="#006600">. </font><font color="#cc0000">'core' </font><font
 color="#006600">. </font><font color="#0000cc">DIRECTORY_SEPARATOR </font><font
 color="#006600">. </font><font color="#cc0000">'core.load_plugins.php'</font><font
 color="#006600">);</font></font></code><br>
<code><font color="#000000"><font color="#0000cc">smarty_core_load_plugins</font><font
 color="#006600">(array(</font><font color="#cc0000">'plugins' </font><font
 color="#006600">=&gt; array(</font></font></code><br>
<code><font color="#000000"><font color="#006600">&nbsp;&nbsp;&nbsp;&nbsp;
array(</font><font color="#cc0000">'modifier'</font><font
 color="#006600">, </font><font color="#cc0000">'date_format'</font><font
 color="#006600">, </font><font color="#cc0000">'helloworld.tpl'</font><font
 color="#006600">, </font><font color="#0000cc">5</font><font
 color="#006600">, </font><font color="#0000cc">false</font><font
 color="#006600">),)), </font><font color="#0000cc">$this</font><font
 color="#006600">); </font><font color="#0000cc">?&gt;</font></font></code><br>
<code><font color="#000000"><font color="#0000cc">&lt;?php
$_smarty_tpl_vars </font><font color="#006600">= </font><font
 color="#0000cc">$this</font><font color="#006600">-&gt;</font><font
 color="#0000cc">_tpl_vars</font><font color="#006600">;</font></font></code><br>
<code><font color="#000000"><font color="#0000cc">$this</font><font
 color="#006600">-&gt;</font><font color="#0000cc">_smarty_include</font><font
 color="#006600">(array(</font><font color="#cc0000">'smarty_include_tpl_file'
</font><font color="#006600">=&gt; </font><font color="#cc0000">"header.tpl"</font><font
 color="#006600">, </font></font></code><br>
<code><font color="#000000"><font color="#cc0000">
'smarty_include_vars' </font><font color="#006600">=&gt; array()));</font></font></code><br>
<code><font color="#000000"><font color="#0000cc">$this</font><font
 color="#006600">-&gt;</font><font color="#0000cc">_tpl_vars </font><font
 color="#006600">= </font><font color="#0000cc">$_smarty_tpl_vars</font><font
 color="#006600">;</font></font></code><br>
<code><font color="#000000"><font color="#006600">unset(</font><font
 color="#0000cc">$_smarty_tpl_vars</font><font color="#006600">);</font></font></code><br>
<code><font color="#000000"><font color="#006600"> </font><font
 color="#0000cc">?&gt;</font></font></code><br>
<code></code><br>
<code><font color="#000000">&lt;h2&gt;Hello World&lt;/h2&gt;</font></code><br>
<code><font color="#000000">&lt;p&gt;How are you on this <font
 color="#0000cc">&lt;?php </font><font color="#006600">echo ((</font><font
 color="#0000cc">is_array</font><font color="#006600">(</font><font
 color="#0000cc">$_tmp</font><font color="#006600">=</font><font
 color="#0000cc">$this</font><font color="#006600">-&gt;</font><font
 color="#0000cc">_tpl_vars</font><font color="#006600">[</font><font
 color="#cc0000">'date'</font><font color="#006600">])) ? </font></font></code><br>
<code><font color="#000000"><font color="#0000cc">&nbsp;&nbsp;&nbsp;
$this</font><font color="#006600">-&gt;</font><font color="#0000cc">_run_mod_handler</font><font
 color="#006600">(</font><font color="#cc0000">'date_format'</font><font
 color="#006600">, </font><font color="#0000cc">true</font><font
 color="#006600">, </font><font color="#0000cc">$_tmp</font><font
 color="#006600">, </font><font color="#cc0000">"%A, %B %e, %Y at
%I:%M%p"</font><font color="#006600">) : </font></font></code><br>
<code><font color="#000000"><font color="#0000cc">&nbsp;&nbsp;&nbsp;
smarty_modifier_date_format</font><font color="#006600">(</font><font
 color="#0000cc">$_tmp</font><font color="#006600">, </font><font
 color="#cc0000">"%A, %B %e, %Y at %I:%M%p"</font><font color="#006600">));
</font><font color="#0000cc">?&gt;</font></font></code><br>
<code><font color="#000000">?</font></code><br>
<code></code><br>
<code><font color="#000000"><font color="#0000cc">&lt;?php
$_smarty_tpl_vars </font><font color="#006600">= </font><font
 color="#0000cc">$this</font><font color="#006600">-&gt;</font><font
 color="#0000cc">_tpl_vars</font><font color="#006600">;</font></font></code><br>
<code><font color="#000000"><font color="#0000cc">$this</font><font
 color="#006600">-&gt;</font><font color="#0000cc">_smarty_include</font><font
 color="#006600">(array(</font><font color="#cc0000">'smarty_include_tpl_file'
</font><font color="#006600">=&gt; </font><font color="#cc0000">"footer.tpl"</font><font
 color="#006600">, </font></font></code><br>
<code><font color="#000000"><font color="#cc0000">&nbsp;&nbsp;&nbsp;&nbsp;
'smarty_include_vars' </font><font color="#006600">=&gt; array()));</font></font></code><br>
<code><font color="#000000"><font color="#0000cc">$this</font><font
 color="#006600">-&gt;</font><font color="#0000cc">_tpl_vars </font><font
 color="#006600">= </font><font color="#0000cc">$_smarty_tpl_vars</font><font
 color="#006600">;</font></font></code><br>
<code><font color="#000000"><font color="#006600">unset(</font><font
 color="#0000cc">$_smarty_tpl_vars</font><font color="#006600">);</font></font></code><br>
<code><font color="#000000"><font color="#006600"> </font><font
 color="#0000cc">?&gt;</font></font></code><br>
<code></code></div>
<pre><code></code></pre>
Smarty writes all of the messy code for you, which frees you up to just
write the tidy stuff.<br>
<br>

<?php
$template->display('footer.tpl');
?>
