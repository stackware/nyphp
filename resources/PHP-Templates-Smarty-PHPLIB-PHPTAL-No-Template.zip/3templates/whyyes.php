
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>New York PHP - Why use templates?</title>
<meta name="robots" content="index,follow" />
<meta name="revisit-after" content="4 weeks" />
<meta name="Keywords" content="New, York, City, PHP, Apache, MySQL, Linux, FreeBSD, Windows, Oracle, PostgreSQL, AMP, LAMP, Technology, Training, Certification, Zend, Classroom, User, Group, Programming, Development, Web, Design, Application, Resource, Email, Mailing, List" />
<meta name="Description" content="New York PHP, AMP Technology, PHP Development, PHP Training, Zend Training, PHP Classroom, Zend Classroom, PHP Certification, Zend Certification, New York City" />
<?php nyphpcss(); ?>
</head>
<body>

<br />
<br />
<div style="margin: 10px;">
<a href="http://www.nyphp.org"><img src="/img/nyphp.gif" style="border: 0; float: right;"></a>
<h2>Why Use Templates?</h2>

<div align="left" style="margin: 35px;">

   <p>
      A reasonable question, but the answer is usually something like "Just try it."
   </p>

   <p>
      Every project is different. The most compelling application of templates is on a
      project where the programmer is not the same person as the interface designer.
   </p>

   <p>
      But let's think that through, from the standpoint of intelligent laziness.
   </p>
   <ul style="padding: 5px;">
      <li>
         The programmer wants to use templates because that way the interface designer can make
         all the changes she wants, without the programmer having to touch the code.
      </li>
      <li style="padding-top: 10px;">
         The interface designer wants to use templates because then she doesn't need to rely on
         the programmer, or learn PHP, in order to get the site looking the way she wants.
      </li>
      <li style="padding-top: 10px;">
         When the boss wants a new look to the site in six months, the programmer will merely
         have to sit back and look busy while the interface designer creates a new set of
         templates (or maybe just a newstylesheet if she used XHTML in the first place).
      </li>

      <li style="padding-top: 10px;">
         In essence
      </li>
      <ul>
         <li>Display tweaks don't involve code hacks.</li>
         <li>The designer doesn't need PHP expertise; the programmer doesn't need design expertise.</li>
         <li>The same code can be used under multiple interfaces.</li>
      </ul>
   </ul>

   <p>
      But what if you work on a small project, where you are both the programmer and designer?
   </p>
   <p>
      The fact is that you are rarely ever programmer and designer at the same time for the life
      of a project. By using templates, you make your separate lives easier.
   </p>
   <p>
      And consider the third fundamental reason to separate application logic from display: code
      reuse. If the underlying code is truly brilliant, and you know it will be, you'll want to use
      it again and again on different sites -- either for different clients, or over time. Humans
      are much more fickle about how things look than they are about how things work-- in fact,
      they rarely get tired of something that works correctly, but they often want to freshen or
      customize its look.
   </p>
   <p>
      If you are selling the same code to multiple clients, and you are intelligently lazy, your
      ultimate goal is to convince your clients to pay you for code that you've already written,
      and have their in-house art department do the design and build the templates.
   </p>
   <p>
      How nice it would be to say, "This code uses a robust, well-documented template language.
      Here is a website with everything you need to know to build your templates."
   </p>

   This brings us to <a href="smarty/">Smarty</a>.<br>

</div>
</div>


</body>
</html>


