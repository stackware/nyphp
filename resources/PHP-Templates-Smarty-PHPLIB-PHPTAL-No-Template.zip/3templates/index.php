<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>New York PHP - A Tale of Three Templates</title>
<meta name="robots" content="index,follow" />
<meta name="revisit-after" content="4 weeks" />
<meta name="Keywords" content="New, York, City, PHP, Apache, MySQL, Linux, FreeBSD, Windows, Oracle, PostgreSQL, AMP, LAMP, Technology, Training, Certification, Zend, Classroom, User, Group, Programming, Development, Web, Design, Application, Resource, Email, Mailing, List" />
<meta name="Description" content="New York PHP, AMP Technology, PHP Development, PHP Training, Zend Training, PHP Classroom, Zend Classroom, PHP Certification, Zend Certification, New York City" />
<?php nyphpcss(); ?>
</head>
<body>

<br />
<br />

<div style="margin: 10px;">
<a href="http://www.nyphp.org"><img src="/img/nyphp.gif" style="border: 0; float: right;"></a>
<h2>A Tale of Three Templates</h2>

<div align="left" style="margin: 35px;">
   <p>Lead by NYPHP members Chris Snyder, Daniel Kushner and Hans Zaunere, see how the different
      templating solutions compare. Chris looks at the powerful Smarty engine, Daniel examines the pure
      PHPLIB implementation, and Hans maintains that PHP is a templating engine itself! The panel will
      examine three identical tasks, and compare each solution for performance, maintainability and
      development lifecycle.
   </p>
   <p>
      And now, thanks to Andrew Yochum, a fourth method for templating, 
      <a target="_blank" href="http://phptal.sourceforge.net/">PHPTAL</a> is
      <a href="/content/presentations/3templates/phptal">available</a>.
   </p>
   <br />
   <br />

   <h3>Basic Tasks</h3>
   <ul>
      <li><a href="task1-plain.php">Process posted vars and display a form.</a></li>
      <li><a href="task2-plain.php">Display the results of a MySQL query.</a></li>
      <li>
         <a href="task3-plain.php">Display a directory listing</a> with image thumbnails and
         human-readable filesizes.
      </li>
   </ul>

   <br />
   <br />

   <h3>Topics</h3>

   <table style="margin-left: 25px;">

      <tr>
         <td><b>Chris</b></td>
      </tr>
      <tr>
         <td style="padding-left: 15px;">
            <a href="whyyes.php">Why use a template engine?</a>
            <br />
            <a href="smarty/">What is Smarty and what does it do?</a>
            <br />
            <a href="smarty/task1-smarty.php">Task 1</a>
            <a href="smarty/task2-smarty.php">Task 2</a>
            <a href="smarty/task3-smarty.php">Task 3</a>
         </td>
      </tr>

      <tr>
         <td style="padding-top: 15px;"><b>Daniel</b></td>
      </tr>
      <tr>
         <td style="padding-left: 15px;">
            <a href="phplib/">What is PHPLib and what does it do?</a>
            <br />
            How does the PHPLib approach differ from Smarty's?
            <br />
            Three tasks
         </td>
      </tr>

      <tr>
         <td style="padding-top: 15px;"><b>Andrew</b></td>
      </tr>
      <tr>
         <td style="padding-left: 15px;">
            <a href="phptal/">What is PHPTAL and what does it do?</a>
            <br />
            <a href="phptal/task_1.php">Task 1</a> |
            <a href="phptal/task_2.php">Task 2</a> |
            <a href="phptal/task_3.php">Task 3</a>
         </td>
      </tr>

      <tr>
         <td style="padding-top: 15px;"><b>Hans</b></td>
      </tr>
      <tr>
         <td style="padding-left: 15px;">
            <a href="whynot/">Why not to use a template engine?</a>  (or: why PHP is a template engine)
            <br />
            <a href="whynot/task1.php">Task 1</a> |
            <a href="whynot/task2.php">Task 2</a> |
            <a href="whynot/task3.php">Task 3</a>
         </td>
      </tr>
   </table>

</div>
</div>
</body>
</html>

