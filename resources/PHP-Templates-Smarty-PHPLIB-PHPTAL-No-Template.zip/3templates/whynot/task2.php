<?php

require_once('task2.inc');

$data = fetchdata();

?>

<?php htmlheader('Task 2: Results of a MySQL query'); ?>

<div style="margin-bottom: 35px; text-align: center;">
   <a href="..">Index</a>
   <a href="task1.php">Task 1</a>
   <a href="task2.php">Task 2</a>
   <a href="task3.php">Task 3</a>
</div>

<h2>Task 2: Results of a MySQL query</h2>

<div id="demo">

<h3>The Articles from the Database:</h3>

<table style="width: 600px;">
	<tr class="header">
		<td>title</td>
		<td>date</td>
	</tr>

  <?php if( !$data ): ?>

   <tr class="header">
      <td>No Results!</td>
   </tr>

  <?php else: ?>

     <?php foreach( $data as $key => $story ): ?>

   	<tr <?=hiLine($key)?> >
   		<td><h4><?=$story['title']?></h4></td>
   		<td><?=$story['created']?></td>
   	</tr>

   	<tr <?=hiLine($key)?> >
         <td colspan="2"><?=$story['content']?></td>
      </tr>
     <?php endforeach; ?>

   <?php endif; ?>

</table>

<h3>Attribution</h3>
<p>Content by Cory Doctorow and Xeni Jardin of <a href="http://boingboing.net">BoingBoing.net</a>, subject to Creative Commons <a href="http://creativecommons.org/licenses/by-nc/1.0">attribution/non-commercial license</a>.</p>

</div>

<h3>Source of this script</h3>
<?php highlight_file($_SERVER['SCRIPT_FILENAME']); ?>

</body>
</html>

