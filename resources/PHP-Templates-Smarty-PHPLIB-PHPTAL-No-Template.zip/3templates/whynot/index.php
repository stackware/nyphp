<?php

require_once('php-templates.inc');

?>

<?php htmlheader('Why not?'); ?>

<div style="margin-bottom: 35px; text-align: center;">
   <a href="..">Index</a>
   <a href="task1.php">Task 1</a>
   <a href="task2.php">Task 2</a>
   <a href="task3.php">Task 3</a>
</div>

<h2>Why PHP is a template engine?</h2>
<h3>(or: why an additional engine is superfluous)</h3>

<div id="demo">

<a href="http://php.net/"><img src="http://www.nyphp.org/img/php.logo.gif" style="border: 0px solid;" align="right"></a>

<ul>
   <li>
      PHP was originally developed to address the need for dynamic content generation
      and management.  This basic syntax and architecture remains.
      <ul>
         <li>Short open tag <b><?=htmlentities('<?=')?></b> dynamically process values in text.</li>
         <li>Alternative control structure syntax (using the colon).</li>
         <li>
            The requirement to have opening/closing tags, thus making the default behavior to
            pass through text while parsing instructions within it (ie, a template!).
         </li>
      </ul>
   </li>

   <li>
      Web pages have become so complex that a certain level of logic is required within HTML, which
      is underscored by the fact that the external templating engines have this functionality.
      <ul>
         <li>
            Templating engines were created to reduce the bad practice of putting business logic,
            database queries, and other complex operations, directly inline with HTML.
         </li>
         <li>
            Proper page architecture, and the separation of <b>presentation logic</b> from
            <b>complex logic</b> make external engines superfluous.
         </li>
      </ul>
   </li>

   <li>
      "Designers don't have to learn PHP" is a myth.  With the complexity of web pages, to the point
      of being applications themselves, <b>interface designers</b> need to have some notion of program
      operation and flow.
      <ul>
         <li>
            External template engines have their own syntax that needs to be learned by interface
            designers.  Preparing a small library of native PHP functions for your project's front-end
            needs, and then teaching designers this basic syntax, is no different from learning
            an external engine's syntax.
         </li>
         <li>
            Complex web application development will always require someone "in the middle" to
            integrate front and back technologies.  Even the premier commercial development platforms
            require someone to mesh all the piece.
         </li>
      </ul>
   </li>

   <li>
      External template engines are superfluous and add their own layer of complexity, performance
      overhead, and development overhead.
      <ul>
         <li>Why learn <b>another</b> syntax that has it's own quirks and limitations?</li>
         <li>Processing and parsing templates require additional resources.</li>
         <li>
            Maintaining another set of files, for instance .tpl, requires additional development
            and tracking.
         </li>
         <li>
            An external engine is an additional set of software to patch, maintain and track bugs
            and changes in.
         </li>
      </ul>
   </li>

   <li>
      Templating is good; PHP has known that from it's inception.
      <ul>
         <li>Templating is easily accomplished without an external engine.</li>
         <li>
            Templating is a development style and architectural decision; not an additional
            piece of software.
         </li>
      </ul>
   </li>
</ul>

</div>

