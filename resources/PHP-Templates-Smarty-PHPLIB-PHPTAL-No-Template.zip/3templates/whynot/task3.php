<?php

require_once('task3.inc');

list($realpath,$listing) = fetchlisting('..');

?>

<?php htmlheader('Task 3: Print a directory listing'); ?>

<div style="margin-bottom: 35px; text-align: center;">
   <a href="..">Index</a>
   <a href="task1.php">Task 1</a>
   <a href="task2.php">Task 2</a>
   <a href="task3.php">Task 3</a>
</div>

<h2>Task 3: Print a directory listing</h2>

<div id="demo">

<h3>Contents of /var/www/...:</h3>

<table>
	<tr class="header">
		<td>icon</td><td>name</td><td>size &nbsp;</td>
	</tr>

  <?php foreach( $listing as $key => $file ): ?>

	<tr <?=hiLine($key)?> >
		<td><?=formicon($file['path'])?></td>
		<td><a href="<?=$file['path']?>"><?=$file['filename']?></a></td>
		<td><?=size2human($file['size'])?></td>
	</tr>

  <?php endforeach; ?>

</table>

</div>

<h3>Source of this script</h3>
<?php highlight_file($_SERVER['SCRIPT_FILENAME']); ?>

</body>
</html>

