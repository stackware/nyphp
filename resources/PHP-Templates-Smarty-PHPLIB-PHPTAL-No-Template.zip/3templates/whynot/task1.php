<?php

require_once('php-templates.inc');

if( empty($_POST['comment']) )
   $_POST['comment'] = 'Default comment.';

?>

<?php htmlheader('Task 1: Process a form'); ?>

<div style="margin-bottom: 35px; text-align: center;">
   <a href="..">Index</a>
   <a href="task1.php">Task 1</a>
   <a href="task2.php">Task 2</a>
   <a href="task3.php">Task 3</a>
</div>
   
<h2>Task 1: Process a form</h2>

<form action="<?=$_SERVER['PHP_SELF']?>" method="post">
<div id="demo">

   <h3>Comment was:</h3>
   <blockquote><?=htmlentities($_POST['comment'])?></blockquote>

   <h3>The form:</h3>

   <table class="edit">
   	<tr>
   		<td class="label">comment</td>
   		<td><input type="text" name="comment" size="56" value="<?=htmlentities($_POST['comment'])?>" style="padding: 3px;" /></td>
   	</tr>
   	<tr>
   		<td class="label">option</td>
   		<td><input type="checkbox" name="option" <?=is_value(@$_POST['option'],'iamchecked')?> value="iamchecked" /> use option if checked.</td>
   	</tr>
   	<tr>
   		<td>&nbsp;</td>
   		<td><input type="submit" name="submit" value="submit" /></td>
   	</tr>
   </table>

</div>
</form>

<h3>Source of this script</h3>
<?php highlight_file($_SERVER['SCRIPT_FILENAME']); ?>

</body>
</html>
