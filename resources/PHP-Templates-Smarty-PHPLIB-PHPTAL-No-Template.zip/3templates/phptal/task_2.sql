-- MySQL dump 9.09
--
-- Host: localhost    Database: idlingus_nyphp
---------------------------------------------------------
-- Server version	4.0.15-standard

--
-- Table structure for table `nyphp_test`
--

CREATE TABLE nyphp_test (
  id int(10) unsigned NOT NULL auto_increment,
  created datetime default NULL,
  title varchar(255) default NULL,
  content text,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `nyphp_test`
--

INSERT INTO nyphp_test VALUES (1,'2003-09-17 04:41:42','Verisign is damage: route around it','Yesterday, Verisign (the company I\'d like to see <a href=\"http://boingboing.net/2002_04_01_archive.html#85002203\">put to death</a>) broke the Internet by redirecting all unregistered .COM and .NET addresses to a page on their site where they run a search-engine. For a lot of good technical reasons, this is a bad idea, and it makes a savage mockery of Verisign\'s (unbelievably lucrative) monopoly on critical pieces of the Internet\'s infrastructure. <p> Today, the makers of the BIND DNS software responded by announcing a patch that will interpret Verisign as damage and route around them.\r\n<blockquote> <a href=\"http://ars.userfriendly.org/cartoons/?id=20030917\"><img src=\"http://craphound.com/images/ufonverisign.jpg\" width=\"160\" height=\"175\" align=\"left\"></a> However, the ISC is about to undercut the Site Finder service with a patch to its BIND software. <p> BIND runs on about 80 percent of the Internet\'s domain name servers -- the machines that translate human-readable Web addresses like www.wired.com into machine-readable Internet addresses used by the Internet\'s vast network of computers. <p> The patch will be released by the end of Tuesday, said Paul Vixie, ISC\'s president. <br clear=\"all\"> </blockquote>\r\n<a href=\"http://www.wired.com/news/technology/0,1282,60473,00.html\">Link</a>');
INSERT INTO nyphp_test VALUES (2,'2003-09-17 05:16:40','NYT cartoon: The Copyright Cops','Hilarious and instructive cartoon in today\'s <em>New York Times </em>about copyright crackdowns and the RIAA lawsuits, with guest cameos by the EFF\'s Fred Von Lohmann and the RIAA\'s Amy Weiss. <a href=\"http://www.nytimes.com/imagepages/2003/09/16/arts/20030916_POPLIFE_IMAGE.html?8hpib\">Link</a> <em>(registration required)</em>');
INSERT INTO nyphp_test VALUES (3,'2003-09-16 15:09:20','Virtual Museum of Bacteria',' The subject line says it all, folks. An online tribute to the glory that is, um, bacteria. <a href=\"http://www.bacteriamuseum.org/map.shtml\">Link</a> <em>(via <a href=\"http://www.viridiandesign.org/\">Viridian </a>list)</em>');
INSERT INTO nyphp_test VALUES (4,'2003-09-17 03:18:31','Translate gangsta to pirate',' Nice Gangsta-Pirate translation table:\r\n<blockquote> <table> <tr> <td><b>Gangstah</b></td> <td><b>Pirate</b></td> </tr> <td>fo\'ties</td> <td>bottles o\' rum</td> </tr> <tr> <td>bling bling</td> <td>booty</td> </tr> <tr> <td>Yo!</td> <td>Avast!</td> </tr> <tr> <td>Homey</td> <td>Matey</td> </tr> <tr> <td>Bee-atch</td> <td>Scurvey dog </td> </tr> </table> </blockquote>\r\n<a href=\"http://www.thepoorman.net/archives/001218.html\">Link</a> (<i>via <a href=\"http://www.nielsenhayden.com/makinglight/\">Making Light</a></i>)');

