<?php

set_Include_Path('/var/www/www.nyphp.org/content/presentations/3templates/phptal/libs:' . Get_Include_Path());

require_once '/var/www/www.nyphp.org/content/presentations/3templates/phptal/libs/PHPTAL.php';

Define('PHPTAL_CACHE_DIR', '/tmp/');


Define('DB_NAME',$PRESENTATION_DB);
Define('DB_HOST',$ORGHOST);
Define('DB_USER',$ORGUSER);
Define('DB_PASS',$ORGPASS);



