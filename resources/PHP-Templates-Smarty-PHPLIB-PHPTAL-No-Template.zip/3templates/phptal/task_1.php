<?php 

require_once 'config.php';

/******************************************************************************/
//  Create a new Template object
/******************************************************************************/
$Template = New PHPTAL('task_1.html');
$Template->_Prepare();


/******************************************************************************/
//  Provide some metadata about the document we're displaying
/******************************************************************************/
$Metadata = Array(
				'Title' => 'Task 1: Process a form',
				'Template' => 'task_1.html',
				'Script' => __FILE__,
				'Cached_Template' => $Template->_codeFile
			);
$Template->SetRef('Metadata', $Metadata);


/******************************************************************************/
//  Drop the _REQUEST and _SERVER hashes into the namespace of the template
/******************************************************************************/
$Template->SetRef('_REQUEST', $_REQUEST);
$Template->SetRef('_SERVER', $_SERVER);


/******************************************************************************/
//  Execute the template
/******************************************************************************/
$Result = $Template->Execute();


/******************************************************************************/
//  Check the result & display it
/******************************************************************************/
if (PEAR::isError($Result)) {
	Echo $Result->toString(), '<br>';
} else {
	Echo $Result;
}


?>
