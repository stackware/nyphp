<?php 

require_once 'config.php';

/******************************************************************************/
//  Create a new Template object
/******************************************************************************/
$Template = New PHPTAL('task_2.html');
$Template->_Prepare();


/******************************************************************************/
//  Provide some metadata about the document we're displaying
/******************************************************************************/
$Metadata = Array(
				'Title' => 'Task 2: Results of a MySQL query',
				'Template' => 'task_2.html',
				'Script' => __FILE__,
				'Cached_Template' => $Template->_codeFile
			);
$Template->SetRef('Metadata', $Metadata);


/******************************************************************************/
//  Create Test function that we really shouldn't need ..
/******************************************************************************/
function Test($Test, $True_Value, $False_Value) {
	return ($Test ? $True_Value : $False_Value);
}


/******************************************************************************/
//  Setup a database connection
/******************************************************************************/
if (! ($DB = @MySQL_Connect(DB_HOST,DB_USER,DB_PASS)) )
	Exit('Could not connect to database server');
if (! @MySQL_Select_DB(DB_NAME))
	Exit('Could not select database');


/******************************************************************************/
// Query the database and populate $Articles array with the resulting rows
/******************************************************************************/
$SQL = 'SELECT * FROM 3templates';
$Result = MySQL_Query($SQL);
$Articles = NULL;
if ($Result) {
	$Articles = Array();
	while ($Articles[] = MySQL_Fetch_Assoc($Result));
	Array_Pop($Articles);
}


/******************************************************************************/
//  Drop the Articles array into the namespace of the template
/******************************************************************************/
$Template->SetRef('Articles', $Articles);


/******************************************************************************/
//  Execute the template
/******************************************************************************/
$Result = $Template->Execute();


/******************************************************************************/
//  Check the result & display it
/******************************************************************************/
if (PEAR::isError($Result)) {
	Echo $Result->toString(), '<br>';
} else {
	Echo $Result;
}


?>
