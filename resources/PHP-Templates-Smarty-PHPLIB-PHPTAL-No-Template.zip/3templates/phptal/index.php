<?php 

require_once 'config.php';

/******************************************************************************/
//  Create a new Template object
/******************************************************************************/
$Template = New PHPTAL('index_html');
$Template->_Prepare();


/******************************************************************************/
//  Provide some metadata about the document we're displaying
/******************************************************************************/
$Metadata = Array(
				'Title' => 'PHPTAL - PHP Template Attribute Language',
				'Template' => 'index_html',
				'Script' => __FILE__,
				'Cached_Template' => $Template->_codeFile
			);
$Template->SetRef('Metadata', $Metadata);

/******************************************************************************/
//  Execute the template
/******************************************************************************/
$Result = $Template->Execute();


/******************************************************************************/
//  Check the result & display it
/******************************************************************************/
if (PEAR::isError($Result)) {
	Echo $Result->toString(), '<br>';
} else {
	Echo $Result;
}


?>
