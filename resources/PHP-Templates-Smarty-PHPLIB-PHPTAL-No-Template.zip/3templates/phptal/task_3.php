<?php 

require_once 'config.php';

/******************************************************************************/
//  Create a new Template object
/******************************************************************************/
$Template = New PHPTAL("task_3.html");
$Template->_Prepare();


/******************************************************************************/
//  Provide some metadata about the document we're displaying
/******************************************************************************/
$Metadata = Array(
				'Title' => 'Task 3: Print a directory listing',
				'Template' => 'task_3.html',
				'Script' => __FILE__,
				'Cached_Template' => $Template->_codeFile
			);
$Template->SetRef('Metadata', $Metadata);


/******************************************************************************/
//  Create Test function that we really shouldn't need ..
/******************************************************************************/
function Test($Test, $True_Value, $False_Value) {
	return ($Test ? $True_Value : $False_Value);
}


/******************************************************************************/
//  Create HumanSize function for file sizes
/******************************************************************************/
function HumanSize($Size) {
	// only take numbers
	if ( !Is_Numeric($Size) ) return $Size;
	
	// Setup some common file size measurements.
	$KB = 1024;         // Kilobyte
	$MB = 1024 * $KB;   // Megabyte
	$GB = 1024 * $MB;   // Gigabyte
	$TB = 1024 * $GB;   // Terabyte

        if($Size < $KB) return $Size."B";
	else if($Size < $MB) return Round($Size/$KB,0)."KB";
	else if($Size < $GB) return Round($Size/$MB,0)."MB";
	else if($Size < $TB) return Round($Size/$GB,0)."GB";
	else return Round($Size/$TB,2)."TB";
}


$Path = DirName($_SERVER['SCRIPT_FILENAME']);

// get the directory contents into $files array
$D = Dir($Path);
$Files = Array();
$Image_Extensions = Array('gif','jpg','png','jpeg');
while (FALSE !== ($Entry = $D->Read())) {
	// Skip over dot files
	if ( SubStr($Entry, 0, 1) == '.' ) continue;

	// Get the file size, if it is a file
	if ( Is_Dir($Path . '/' . $Entry) ) {
		$Size = 'dir';
	} else {
		$Size = FileSize($Path . '/' . $Entry);
	}

	// Determine if the file is an image
	$DotPos= StrRPos($Entry, '.');
	$Is_Image = FALSE;
	if ($DotPos) {
		$Extension = SubStr($Entry, $DotPos + 1);
		if (In_Array($Extension,$Image_Extensions))
			$Is_Image = TRUE;
	}

	// Pop the entry on our data structure
	$Files[] = Array(
				'Filename' => $Entry,
				'Size' => $Size,
				'Is_Image' => $Is_Image
				);
}
$D->Close();

// Sort the entries
function File_Sort($A, $B) {
	return StrNatCmp($A['Filename'], $B['Filename']);
}
USort($Files, 'File_Sort');


/******************************************************************************/
//  Drop the Path variable & Files array into the namespace of the template
/******************************************************************************/
$Template->Set('Path', $Path);
$Template->SetRef('Files', $Files);


/******************************************************************************/
//  Execute the template
/******************************************************************************/
$Result = $Template->Execute();


/******************************************************************************/
//  Check the result & display it
/******************************************************************************/
if (PEAR::isError($Result)) {
	Echo $Result->toString(), "<br>";
} else {
	Echo $Result;
}


?>
