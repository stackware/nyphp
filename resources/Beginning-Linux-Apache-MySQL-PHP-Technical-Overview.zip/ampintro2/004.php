<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>MySQL 3.23.52</h1>
   <h2>Configuration and Compilation</h2>
   <ul>
      <li>/demo/mysql/bin/mysql_install_db</li>
      <ul>
         <li>Prepare and install the 'mysql' database</li>
         <ul>
            <li>User and permission data dictionary used internally by MySQL</li>
         </ul>
      </ul>
      <li>/demo/mysql/bin/safe_mysqld &</li>
      <ul>
         <li>Start mysqld wrapped in a monitoring script</li>
      </ul>
      <li>/demo/mysql/bin/mysqladmin -u root �p 'demo'</li>
      <ul>
         <li>Set root (superuser) password for MySQL</li>
         <li>Has no bearing on operating system accounts</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>