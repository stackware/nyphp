<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>Resources</h1>
   <ul>
      <li><a target=_blank href="http://zend.com">Zend - The PHP Company</a></li>
      <li><a target=_blank href="http://phpbuilder.com">PHPBuilder Tutorials, Articles and Code</a></li>
      <li><a target=_blank href="http://sourceforge.net/projects/phptriad/">PHP Triad - AMP Technology Installer for Windows</a></li>
      <li><a target=_blank href="http://developer.ez.no">AMP Based Professional CMS</a></li>
      <li><a target=_blank href="http://www.phpwizard.net">phpMyAdmin, phpPgAdmin, Tutorials and more</a></li>
      <li><a target=_blank href="http://dmoz.org/Computers/Programming/Languages/PHP/Tutorials/">DMOZ Open Directory PHP Tutorials</a></li>
      <li><a target=_blank href="http://www.nyphp.org">New York PHP Projects and Knowledge Base</a></li>
   </ul>
</div>

<?=slidefooter()?>