<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>PHP 4.2.3</h1>
   <h2>Configuration and Compilation</h2>
   <ul>
      <li>--prefix=/demo/php</li>
      <ul>
         <li>PHP's tree top</li>
      </ul>
      <li>--with-apxs=/demo/apache/bin/apxs</li>
      <ul>
         <li>Compile PHP as an Apache DSO</li>
      </ul>
      <li>--with-mysql=/demo/mysql</li>
      <ul>
         <li>Point to MySQL's native client libraries</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>