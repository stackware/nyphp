<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>Putting AMP to Work</h1>
   <h2><a href="initial.phps">initial.phps</a></h2>
   <ul>
      <li>http://demo.nyphp.org:8000/code/initial.phps</li>
      <li>View source with PHP's built-in highlighting</li>
      <li>GET method checking as a failsafe</li>
      <li>Override php.ini setting</li>
      <ul>
         <li>Show errors in browser (stdout)</li>
      </ul>
      <li>Get MySQL connection online</li>
      <ul>
         <li>localhost connections use UNIX domain sockets</li>
      </ul>
      <li>Create array of queries</li>
      <ul>
         <li>PHP forms a sequential integer-indexed array</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>