<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>Putting AMP to Work...</h1>
   <h2><a href="initial.phps">initial.phps</a></h2>
   <ul>
      <li>Loop through queries, processing and error checking</li>
      <li>Reconnect to MySQL with the same DB resource</li>
      <ul>
         <li>Different username/password implies new connection</li>
         <li>Old resource is dereferenced and freed by garbage collector</li>
      </ul>
      <li>Create nested arrays for member information</li>
      <ul>
         <li>Automatic sequential integer-indexed array</li>
         <li>Each element contains a user-defined associative array</li>
      </ul>
      <li>Loop through members, forming proper query</li>
      <ul>
         <li>INSERT will generate non-zero ID (auto_increment)</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>