<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>PHP 4.2.3</h1>
   <h2>Setup and Integration</h2>
   <ul>
      <li>cp php.ini-recommended /demo/php/lib/php.ini</li>
      <ul>
         <li>Always use php.ini-recommended</li>
         <ul>
            <li>Maintainable configuration for future PHP versions</li>
         </ul>
      </ul>
      <li>Ensure proper httpd.conf directives:</li>
      <ul>
         <li>LoadModule php4_module&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;libexec/libphp4.so</li>
         <ul>
            <li>Load PHP DSO</li>
         </ul>
         <li>AddType application/x-httpd-php .php</li>
         <ul>
            <li>Pass .php files to PHP</li>
         </ul>
         <li>AddType application/x-httpd-php-source .phps</li>
         <ul>
            <li>Pass .phps (source) files to PHP for syntax highlighting</li>
         </ul>
      </ul>
   </ul>
</div>

<?=slidefooter()?>