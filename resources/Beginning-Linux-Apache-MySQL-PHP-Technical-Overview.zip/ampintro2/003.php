<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>MySQL 3.23.52</h1>
   <h2>Configuration and Compilation</h2>
   <ul>
      <li>--prefix=/demo/mysql</li>
      <ul>
         <li>MySQL's tree top</li>
      </ul>
      <li>--with-unix-socket-path=/demo/tmp/mysql.sock</li>
      <ul>
         <li>Needed with multiple MySQL instances per box</li>
      </ul>
      <li>--with-mysqld-user=praxis</li>
      <ul>
         <li>MySQL will completely drop root and run as this user</li>
      </ul>
      <li>MySQL offers many other configuration options:</li>
      <ul>
         <li>DB handlers (InnoDB) provide transactions etc.</li>
         <li>Compilation tweaks for improved performance</li>
      </ul>
      <li>MySQL AB binaries are recommended for production systems (notably on Linux)</li>
   </ul>
</div>

<?=slidefooter()?>