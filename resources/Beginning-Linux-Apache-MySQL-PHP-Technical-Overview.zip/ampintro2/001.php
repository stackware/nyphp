<?php
// javascript:window.alert('Width: ' + window.innerWidth + ' Height: ' + window.innerHeight);

require_once('ampintro2.inc');

?>

<div class=slidebody>
   <h1>AMP Setup and Implementation?</h1>
   <ul>
      <li>Installing and configuring each component</li>
      <ul>
         <li>Apache with Dynamic Shared Object (DSO) Support</li>
         <li>Standard MySQL</li>
         <li>PHP 4 as a DSO with native MySQL support</li>
      </ul>
      <li>Testing the install with phpMyAdmin</li>
      <li>Using AMP</li>
      <ul>
         <li>Setting php.ini values at runtime</li>
         <li>Array manipulation</li>
         <li>Database connections and queries</li>
         <li>Error checking and reporting</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>