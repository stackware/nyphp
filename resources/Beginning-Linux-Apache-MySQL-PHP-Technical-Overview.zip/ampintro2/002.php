<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>Apache 1.3.26</h1>
   <ul>
      <li>--prefix=/demo/apache</li>
      <ul>
         <li>Apahe's tree top</li>
      </ul>
      <li>--enable-module=so</li>
      <ul>
         <li>Enable DSO support (mod_php)</li>
      </ul>
      <li>--with-port=8000</li>
      <li>--server-uid[gid]=praxis</li>
      <ul>
         <li>Only Apache children will run as this user/group</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>