<?php

require_once('ampintro2.inc');

?>


<div class=slidebody>
   <h1>Getting AMP Online</h1>
   <ul>
      <li>The data layer (MySQL) is already started</li>
      <li>Fire up the interface layer:</li>
      <ul>
         <li>/demo/apache/bin/apachectl start</li>
      </ul>
      <li>http://demo.nyphp.org:8000/sql/</li>
      <ul>
         <li>phpMyAdmin is a good test to ensure everything is properly loaded and configured</li>
      </ul>
   </ul>
</div>

<?=slidefooter()?>