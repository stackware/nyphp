<head>
   <META NAME="robots" CONTENT="index,follow">
   <META NAME="revisit-after" CONTENT="4 weeks">
   <META NAME="KEYWORDS" CONTENT="New, York, City, PHP, Apache, MySQL, Linux, FreeBSD, Windows, Oracle, PostgreSQL, AMP, LAMP, Technology, Training, Certification, Zend, Classroom, User, Group, Programming, Development, Web, Design, Application, Resource, Email, Mailing, List">
   <META NAME="DESCRIPTION" CONTENT="New York PHP, AMP Technology, PHP Development, PHP Training, Zend Training, PHP Classroom, Zend Classroom, PHP Certification, Zend Certification, New York City">
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <title>New York PHP - Introduction to AMP Technology</title>
   <style type="text/css">
      <?php include('../presentations.css'); ?>
   </style>
</head>

<div class=hans>
   <table width="100%" cellpadding=0 cellspacing=0>
      <tr>
         <td style="width: 1px;"><a href="/presentations"><img class=nyphplogo src="http://www.nyphp.org/img/nyphp.logo.gif"></a></td>
         <td align=center class=nyphpsplash><a href="/presentations"><img style="margin-left: auto; margin-right: auto;" src="newyorkphp.gif"></a></td>
      </tr>
   </table>
   <table style="margin-top: 5px; width: 100%;" cellpadding=0 cellspacing=0>
      <tr>
         <td style="text-align: left; width: 100%; vertical-align: top; font-family: Arial; font-size: 12px; font-weight: bold;">
            <a href=ampintro2.zip>Download<br>Presentation</a>
         </td>
         <td style="text-align: right; width: 100%; vertical-align: top; font-family: Arial; font-size: 12px; font-weight: bold;">
            <a href=001.php><img alt=Next src="forwardarrow.gif"></a>
         </td>
      </tr>
   </table>
</div>

<h1 style="text-align: center; padding-top: 25px;">Introduction to AMP Technology</h1>
<h2 style="text-align: center;">Technical Overview</h2>

<div style="padding-top: 50px; text-align: center; font-size: 28px; color: blue;">
NYPHP Internal Presentation<br>September 25, 2002
</div>

<div style="padding-top: 25px; text-align: center; font-size: 20px; color: black;">
Presented by Hans Zaunere, Daniel Kushner and Bill Patterson
</div>

<div style="position: absolute; bottom: 5px; padding: 5px; border-top: 1px solid #CCCCCC; border-bottom: 1px solid #333333; border-left: 1px solid #CCCCCC; border-right: 1px solid #333333;">
   <table style="font-family: Arial, sans-serif; font-size: 14px;" cellpadding=0 cellspacing=0>
      <tr>
         <td><a target=_blank href="http://www.nyphp.org">http://www.nyphp.org</a></td>
         <td><a target=_blank href="http://apache.org">http://apache.org</a></td>
         <td><a target=_blank href="http://mysql.com">http://mysql.com</a></td>
         <td><a target=_blank href="http://php.net">http://php.net</a></td>
         <td>9/25/02</td>
      </tr>
   </table>
</div>